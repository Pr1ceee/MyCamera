package com.example.cam

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.TextureView
import android.view.VelocityTracker
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

// The Pro-mode ruler. Slide it with a thumb or flick it: it glides and settles on a value, ticking as it
// passes each one. The value under the yellow cursor is the setting; ticks grow as they near the cursor.
class DialRuler(c: Context, private val accent: Int) : View(c) {
    var lo = 0
    var hi = 100
    var unitDp = 8f                       // distance between two neighbouring values
    var majorEvery = 10                   // a taller tick every n values
    var labelOf: ((Int) -> String)? = null   // text under a value ("" for none)
    var onChange: ((Int) -> Unit)? = null
    var onTick: (() -> Unit)? = null
    var value = 0
        private set
    private var valueF = 0f
    private val d = c.resources.displayMetrics.density
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.6f * d
    }
    private val cursor = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2.6f * d
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 11f * d
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private var downX = 0f
    private var startF = 0f
    private var tracker: VelocityTracker? = null
    private var glide: ValueAnimator? = null

    private fun unit() = unitDp * d

    fun setValue(v: Int) {
        glide?.cancel()
        value = v.coerceIn(lo, hi)
        valueF = value.toFloat()
        invalidate()
    }

    private fun emit() {
        val nv = valueF.roundToInt().coerceIn(lo, hi)
        if (nv != value) {
            value = nv
            onTick?.invoke()
            onChange?.invoke(nv)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val u = unit()
        val span = (cx / u).toInt() + 2
        val base = valueF.roundToInt()
        val mid = height * 0.44f
        for (i in (base - span)..(base + span)) {
            if (i < lo || i > hi) continue
            val x = cx + (i - valueF) * u
            val dist = abs(x - cx)
            val fade = (1f - dist / cx).coerceIn(0f, 1f)
            val near = (1f - dist / (cx * 0.5f)).coerceIn(0f, 1f)      // 1 at the cursor, 0 further out
            val major = majorEvery <= 1 || i % majorEvery == 0
            val half = (if (major) 9f else 5.5f) * d + near * 5f * d
            tick.color = Color.argb((45 + 170 * fade).toInt(), 255, 255, 255)
            canvas.drawLine(x, mid - half, x, mid + half, tick)
            val lab = labelOf?.invoke(i) ?: ""
            if (lab.isNotEmpty()) {
                val on = abs(i - valueF) < 0.5f
                text.color = if (on) accent else Color.argb((80 + 150 * fade).toInt(), 255, 255, 255)
                text.textSize = (if (on) 12.5f else 11f) * d
                canvas.drawText(lab, x, height * 0.92f, text)
            }
        }
        canvas.drawLine(cx, height * 0.04f, cx, height * 0.70f, cursor)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                glide?.cancel()
                tracker?.recycle()
                tracker = VelocityTracker.obtain()
                tracker?.addMovement(e)
                downX = e.x
                startF = valueF
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(e)
                valueF = (startF - (e.x - downX) / unit()).coerceIn(lo.toFloat(), hi.toFloat())
                emit()
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                tracker?.addMovement(e)
                tracker?.computeCurrentVelocity(1000)
                val vx = tracker?.xVelocity ?: 0f
                tracker?.recycle()
                tracker = null
                // a flick carries on for a moment; either way it ends exactly on a value
                val carry = if (abs(vx) > 350f) -vx * 0.16f / unit() else 0f
                val target = (valueF + carry).roundToInt().coerceIn(lo, hi).toFloat()
                glideTo(target)
                return true
            }
        }
        return true
    }

    private fun glideTo(target: Float) {
        glide?.cancel()
        val from = valueF
        if (abs(target - from) < 0.001f) {
            valueF = target
            emit()
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(from, target)
        a.duration = (200 + abs(target - from) * 22f).toLong().coerceIn(200L, 700L)
        a.interpolator = DecelerateInterpolator(1.9f)
        a.addUpdateListener {
            valueF = it.animatedValue as Float
            emit()
            invalidate()
        }
        a.start()
        glide = a
    }
}

// Focus peaking: sharp edges of the live picture glow in the accent colour. It looks at a small copy of the
// preview about nine times a second, only while it is switched on and on screen.
class PeakingView(c: Context, private val color: Int) : View(c) {
    var source: TextureView? = null
    private var active = false
    private val handler = Handler(Looper.getMainLooper())
    private var small: Bitmap? = null
    private var overlay: Bitmap? = null
    private var px = IntArray(0)
    private var lum = IntArray(0)
    private var out = IntArray(0)
    private var grad = IntArray(0)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val loop = object : Runnable {
        override fun run() {
            step()
            if (running()) handler.postDelayed(this, 110)
        }
    }

    fun setActive(on: Boolean) {
        active = on
        refresh()
    }

    private fun running() = active && isShown && windowVisibility == View.VISIBLE && source != null

    private fun refresh() {
        handler.removeCallbacks(loop)
        if (running()) {
            handler.post(loop)
        } else {
            overlay = null
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        refresh()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        refresh()
    }

    private fun step() {
        val src = source ?: return
        if (!src.isAvailable || width < 8 || height < 8) return
        val w = 180
        val h = (w * height.toFloat() / width).roundToInt().coerceIn(60, 400)
        var made = small
        if (made == null || made.width != w || made.height != h) {
            made = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            small = made
            overlay = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            px = IntArray(w * h)
            lum = IntArray(w * h)
            out = IntArray(w * h)
            grad = IntArray(w * h)
        }
        val bm: Bitmap = made ?: return
        try {
            src.getBitmap(bm)
        } catch (e: Exception) {
            return
        }
        bm.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]
            lum[i] = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
        }
        var sum = 0L
        var n = 0
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val g = abs(lum[i + 1] - lum[i - 1]) + abs(lum[i + w] - lum[i - w])
                grad[i] = g
                sum += g
                n++
            }
        }
        val mean = if (n > 0) sum.toFloat() / n else 0f
        val thr = max(56f, mean * 3.4f)
        val mark = (230 shl 24) or (color and 0xFFFFFF)
        java.util.Arrays.fill(out, 0)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                if (grad[i] > thr) {
                    out[i] = mark
                    out[i + 1] = mark
                }
            }
        }
        overlay?.setPixels(out, 0, w, 0, 0, w, h)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val o = overlay ?: return
        canvas.drawBitmap(o, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), paint)
    }
}
