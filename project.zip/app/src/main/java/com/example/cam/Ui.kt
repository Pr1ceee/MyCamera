package com.example.cam

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// A horizontal ruler you slide with a thumb: the tick under the yellow cursor is the value.
// Used for ISO, shutter, white balance and focus in the Pro drawer.
class DialRuler(c: Context, private val accent: Int) : View(c) {
    var lo = 0
    var hi = 100
    var discrete = false                  // few stops, each one wide, with a label under it
    var labelOf: ((Int) -> String)? = null
    var onChange: ((Int) -> Unit)? = null
    var onTick: (() -> Unit)? = null
    var value = 0
        private set
    private var valueF = 0f
    private val d = c.resources.displayMetrics.density
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.5f * d
    }
    private val cursor = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2.5f * d
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 10.5f * d
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private var downX = 0f
    private var startF = 0f

    private fun unit() = if (discrete) 72f * d else 8f * d

    fun setValue(v: Int) {
        value = v.coerceIn(lo, hi)
        valueF = value.toFloat()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val u = unit()
        val span = (cx / u).toInt() + 2
        val base = valueF.roundToInt()
        val top = height * 0.18f
        val bigBottom = height * 0.60f
        val smallBottom = height * 0.48f
        for (i in (base - span)..(base + span)) {
            if (i < lo || i > hi) continue
            val x = cx + (i - valueF) * u
            val major = discrete || i % 10 == 0
            val fade = (1f - abs(x - cx) / cx).coerceIn(0f, 1f)
            tick.color = Color.argb((50 + 160 * fade).toInt(), 255, 255, 255)
            canvas.drawLine(x, top, x, if (major) bigBottom else smallBottom, tick)
            val lab = labelOf?.invoke(i) ?: ""
            if (lab.isNotEmpty()) {
                text.color = Color.argb((90 + 150 * fade).toInt(), 255, 255, 255)
                canvas.drawText(lab, x, height * 0.90f, text)
            }
        }
        canvas.drawLine(cx, height * 0.06f, cx, height * 0.68f, cursor)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                startF = valueF
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                valueF = (startF - (e.x - downX) / unit()).coerceIn(lo.toFloat(), hi.toFloat())
                val nv = valueF.roundToInt()
                if (nv != value) {
                    value = nv
                    onTick?.invoke()
                    onChange?.invoke(nv)
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                valueF = value.toFloat()
                invalidate()
                return true
            }
        }
        return true
    }
}

// Focus peaking: sharp edges of the live picture glow yellow. It looks at a small copy of the preview
// about nine times a second, only while it is switched on and on screen.
class PeakingView(c: Context, private val color: Int) : View(c) {
    var source: TextureView? = null
    private var active = false
    private val handler = Handler(Looper.getMainLooper())
    private var small: Bitmap? = null
    private var overlay: Bitmap? = null
    private var px = IntArray(0)
    private var lum = IntArray(0)
    private var out = IntArray(0)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val loop = object : Runnable {
        override fun run() {
            step()
            if (running()) handler.postDelayed(this, 110)
        }
    }

    fun setActive(on: Boolean) {
        active = on
        refresh()
    }

    private fun running() = active && isShown && windowVisibility == View.VISIBLE && source != null

    private fun refresh() {
        handler.removeCallbacks(loop)
        if (running()) {
            handler.post(loop)
        } else {
            overlay = null
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        refresh()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        refresh()
    }

    private fun step() {
        val src = source ?: return
        if (!src.isAvailable || width < 8 || height < 8) return
        val w = 180
        val h = (w * height.toFloat() / width).roundToInt().coerceIn(60, 400)
        var made = small
        if (made == null || made.width != w || made.height != h) {
            made = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            small = made
            overlay = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            px = IntArray(w * h)
            lum = IntArray(w * h)
            out = IntArray(w * h)
        }
        val bm: Bitmap = made ?: return
        try {
            src.getBitmap(bm)
        } catch (e: Exception) {
            return
        }
        bm.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]
            lum[i] = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
        }
        var sum = 0L
        var n = 0
        val grad = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val g = abs(lum[i + 1] - lum[i - 1]) + abs(lum[i + w] - lum[i - w])
                grad[i] = g
                sum += g
                n++
            }
        }
        val mean = if (n > 0) sum.toFloat() / n else 0f
        val thr = maxOf(56f, mean * 3.4f)
        val mark = (230 shl 24) or (color and 0xFFFFFF)
        java.util.Arrays.fill(out, 0)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                if (grad[i] > thr) {
                    out[i] = mark
                    out[i + 1] = mark
                }
            }
        }
        overlay?.setPixels(out, 0, w, 0, 0, w, h)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val o = overlay ?: return
        canvas.drawBitmap(o, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), paint)
    }
}

// Camera flip: two arrows chasing each other around a circle.
class FlipIconView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.8f
    }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val head = Path()

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        canvas.scale(s, s)
        val r = 7.5f
        val box = RectF(12f - r, 12f - r, 12f + r, 12f + r)
        head.reset()
        head.moveTo(2.4f, 0f)
        head.lineTo(-2.6f, -3f)
        head.lineTo(-2.6f, 3f)
        head.close()
        for (k in 0..1) {
            canvas.save()
            if (k == 1) canvas.rotate(180f, 12f, 12f)
            canvas.drawArc(box, 205f, 120f, false, p)
            val a = Math.toRadians(325.0)
            val ex = 12f + r * cos(a).toFloat()
            val ey = 12f + r * sin(a).toFloat()
            canvas.save()
            canvas.translate(ex, ey)
            canvas.rotate(325f + 90f)
            canvas.drawPath(head, f)
            canvas.restore()
            canvas.restore()
        }
        canvas.restore()
    }
}

private class PlayBadge(c: Context) : View(c) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val tri = Path()

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        canvas.drawCircle(cx, cy, min(width, height) / 2f, bg)
        val s = min(width, height) * 0.22f
        tri.reset()
        tri.moveTo(cx - s * 0.6f, cy - s)
        tri.lineTo(cx + s, cy)
        tri.lineTo(cx - s * 0.6f, cy + s)
        tri.close()
        canvas.drawPath(tri, fg)
    }
}

// Instant photo review: a sheet that slides up over the viewfinder with the latest shot large, a strip
// of recent ones, and the two actions that matter. Drag the top of it down to put it away.
class QuickGallery(c: Context, private val accent: Int, private val onOpenFull: () -> Unit) : FrameLayout(c) {
    private class Item(val uri: Uri, val video: Boolean, val mime: String)

    private val d = c.resources.displayMetrics.density
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val ease = PathInterpolator(0.22f, 1f, 0.36f, 1f)
    private val scrim = View(c)
    private val card = LinearLayout(c)
    private val titleTv = TextView(c)
    private val countTv = TextView(c)
    private val preview = ImageView(c)
    private val badge = PlayBadge(c)
    private val stripRow = LinearLayout(c)
    private val items = ArrayList<Item>()
    private val thumbs = ArrayList<ImageView>()
    private var cur = -1
    private var opened = false
    private var loadGen = 0

    val isOpen get() = opened

    private fun dp(v: Int) = (v * d).toInt()

    private fun pill(label: String, fill: Int, textColor: Int): TextView {
        val t = TextView(context)
        t.text = label
        t.setTextColor(textColor)
        t.textSize = 15f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        t.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.cornerRadius = dp(24).toFloat()
        bg.setColor(fill)
        t.background = bg
        return t
    }

    init {
        visibility = View.GONE
        scrim.setBackgroundColor(Color.parseColor("#99000000"))
        scrim.alpha = 0f
        scrim.setOnClickListener { hide() }
        addView(scrim, LayoutParams(-1, -1))

        card.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#F2161618"))
        val r = dp(28).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        card.background = bg
        card.setPadding(dp(20), dp(10), dp(20), dp(28))
        card.isClickable = true
        addView(card, LayoutParams(-1, -2, Gravity.BOTTOM))

        // the top part is the drag handle
        val head = LinearLayout(context)
        head.orientation = LinearLayout.VERTICAL
        val grab = View(context)
        val gbg = GradientDrawable()
        gbg.cornerRadius = dp(2).toFloat()
        gbg.setColor(Color.parseColor("#59FFFFFF"))
        grab.background = gbg
        val glp = LinearLayout.LayoutParams(dp(36), dp(4))
        glp.gravity = Gravity.CENTER_HORIZONTAL
        head.addView(grab, glp)
        val titleRow = LinearLayout(context)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        titleTv.text = "Recent"
        titleTv.setTextColor(Color.WHITE)
        titleTv.textSize = 22f
        titleTv.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        countTv.setTextColor(Color.parseColor("#99FFFFFF"))
        countTv.textSize = 14f
        titleRow.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(countTv, LinearLayout.LayoutParams(-2, -2))
        val trlp = LinearLayout.LayoutParams(-1, dp(48))
        trlp.topMargin = dp(6)
        head.addView(titleRow, trlp)
        card.addView(head, LinearLayout.LayoutParams(-1, -2))
        var dragStart = 0f
        head.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStart = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    card.translationY = maxOf(0f, ev.rawY - dragStart)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (card.translationY > dp(110)) {
                        hide()
                    } else {
                        card.animate().translationY(0f).setDuration(260).setInterpolator(ease).start()
                    }
                    true
                }
                else -> false
            }
        }

        // big preview
        val holder = FrameLayout(context)
        preview.scaleType = ImageView.ScaleType.CENTER_CROP
        preview.setBackgroundColor(Color.parseColor("#26FFFFFF"))
        preview.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(20).toFloat())
            }
        }
        preview.clipToOutline = true
        preview.setOnClickListener { onOpenFull() }
        holder.addView(preview, FrameLayout.LayoutParams(-1, -1))
        badge.visibility = View.GONE
        holder.addView(badge, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        val screenH = c.resources.displayMetrics.heightPixels
        val screenW = c.resources.displayMetrics.widthPixels
        val ph = min(((screenW - dp(40)) * 4 / 3), (screenH * 0.46f).toInt())
        val plp = LinearLayout.LayoutParams(-1, ph)
        plp.topMargin = dp(4)
        card.addView(holder, plp)

        // strip of recent shots
        val sv = HorizontalScrollView(context)
        sv.isHorizontalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        stripRow.orientation = LinearLayout.HORIZONTAL
        sv.addView(stripRow, FrameLayout.LayoutParams(-2, -2))
        val slp = LinearLayout.LayoutParams(-1, dp(68))
        slp.topMargin = dp(14)
        card.addView(sv, slp)

        // actions
        val actions = LinearLayout(context)
        actions.orientation = LinearLayout.HORIZONTAL
        val share = pill("Share", Color.parseColor("#26FFFFFF"), Color.WHITE)
        share.setOnClickListener { shareCurrent() }
        val open = pill("Open gallery", accent, Color.parseColor("#1C1917"))
        open.setOnClickListener { onOpenFull() }
        val l1 = LinearLayout.LayoutParams(0, dp(52), 1f)
        l1.rightMargin = dp(6)
        val l2 = LinearLayout.LayoutParams(0, dp(52), 1.4f)
        l2.leftMargin = dp(6)
        actions.addView(share, l1)
        actions.addView(open, l2)
        val alp = LinearLayout.LayoutParams(-1, -2)
        alp.topMargin = dp(16)
        card.addView(actions, alp)
    }

    fun show() {
        if (opened) return
        opened = true
        visibility = View.VISIBLE
        scrim.animate().cancel()
        card.animate().cancel()
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(260).start()
        val h = if (card.height > 0) card.height else resources.displayMetrics.heightPixels
        card.translationY = h.toFloat()
        card.animate().translationY(0f).setDuration(380).setInterpolator(ease).start()
        load()
    }

    fun hide() {
        if (!opened) return
        opened = false
        scrim.animate().cancel()
        card.animate().cancel()
        scrim.animate().alpha(0f).setDuration(220).start()
        card.animate().translationY(card.height.toFloat() + dp(20)).setDuration(260).setInterpolator(ease)
            .withEndAction { if (!opened) visibility = View.GONE }.start()
    }

    private fun load() {
        val gen = ++loadGen
        io.execute {
            val found = ArrayList<Item>()
            try {
                val sel = "(" + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ? OR " +
                    MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?) AND (" +
                    MediaStore.Files.FileColumns.MEDIA_TYPE + "=? OR " +
                    MediaStore.Files.FileColumns.MEDIA_TYPE + "=?)"
                val args = arrayOf(
                    "Pictures/MyCam%", "Movies/MyCam%",
                    MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
                    MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
                )
                val q = Bundle()
                q.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel)
                q.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args)
                q.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.MediaColumns.DATE_ADDED))
                q.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
                q.putInt(ContentResolver.QUERY_ARG_LIMIT, 24)
                val proj = arrayOf(
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.MIME_TYPE,
                    MediaStore.Files.FileColumns.MEDIA_TYPE
                )
                context.contentResolver.query(MediaStore.Files.getContentUri("external"), proj, q, null)?.use { cu ->
                    while (cu.moveToNext()) {
                        val id = cu.getLong(0)
                        val mime = cu.getString(1) ?: ""
                        val video = cu.getInt(2) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        found.add(Item(ContentUris.withAppendedId(base, id), video, mime))
                    }
                }
            } catch (e: Exception) {
            }
            ui.post { if (gen == loadGen) populate(found) }
        }
    }

    private fun populate(list: List<Item>) {
        items.clear()
        items.addAll(list)
        stripRow.removeAllViews()
        thumbs.clear()
        countTv.text = if (items.isEmpty()) "" else items.size.toString() + (if (items.size >= 24) "+" else "") + " items"
        titleTv.text = if (items.isEmpty()) "No photos yet" else "Recent"
        for ((i, item) in items.withIndex()) {
            val iv = ImageView(context)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setBackgroundColor(Color.parseColor("#26FFFFFF"))
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            iv.clipToOutline = true
            iv.setOnClickListener { select(i) }
            val lp = LinearLayout.LayoutParams(dp(64), dp(64))
            lp.rightMargin = dp(8)
            stripRow.addView(iv, lp)
            thumbs.add(iv)
            loadInto(iv, item, 220)
        }
        if (items.isNotEmpty()) select(0)
    }

    private fun loadInto(iv: ImageView, item: Item, px: Int) {
        io.execute {
            val bm = try {
                context.contentResolver.loadThumbnail(item.uri, Size(px, px), null)
            } catch (e: Exception) {
                null
            }
            if (bm != null) ui.post { iv.setImageBitmap(bm) }
        }
    }

    private fun select(i: Int) {
        if (i !in items.indices) return
        cur = i
        for ((k, t) in thumbs.withIndex()) {
            val ring = GradientDrawable()
            ring.cornerRadius = dp(12).toFloat()
            ring.setColor(Color.TRANSPARENT)
            if (k == i) ring.setStroke(dp(2), accent)
            t.foreground = ring
            t.animate().alpha(if (k == i) 1f else 0.72f).setDuration(160).start()
        }
        val item = items[i]
        badge.visibility = if (item.video) View.VISIBLE else View.GONE
        val w = preview.width.coerceAtLeast(900)
        io.execute {
            val bm = try {
                context.contentResolver.loadThumbnail(item.uri, Size(w, (w * 4 / 3)), null)
            } catch (e: Exception) {
                null
            }
            if (bm != null) ui.post { if (cur == i) preview.setImageBitmap(bm) }
        }
    }

    private fun shareCurrent() {
        val item = items.getOrNull(cur) ?: return
        try {
            val send = Intent(Intent.ACTION_SEND)
            send.type = if (item.mime.isNotEmpty()) item.mime else if (item.video) "video/*" else "image/*"
            send.putExtra(Intent.EXTRA_STREAM, item.uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(Intent.createChooser(send, null))
        } catch (e: Exception) {
        }
    }
}
