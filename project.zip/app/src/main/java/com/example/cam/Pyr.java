package com.example.cam;

/**
 * Noise removal in a Laplacian pyramid: every band gets its own threshold from the measured noise
 * of that band, so blotchy (spatially clumped) noise is removed as well as fine grain, while the
 * strong coefficients that make up edges and texture are kept.
 */
public final class Pyr {
    private Pyr() {}

    public static final int BANDS = 5;   // bands 0..4 are thresholded, the rest (low-pass) is kept as it is

    // ---------- pyramid tools ----------

    private static final float[] K5 = {1f / 16, 4f / 16, 6f / 16, 4f / 16, 1f / 16};

    /** blur with a 5-tap binomial filter and keep every second sample */
    static float[] blurDown(float[] a, int w, int h, int dw, int dh) {
        float[] t = new float[dw * h];      // horizontal pass, already halved
        for (int y = 0; y < h; y++) {
            int ro = y * w;
            for (int x = 0; x < dw; x++) {
                int cx = x * 2;
                float s = 0;
                for (int k = -2; k <= 2; k++) {
                    int xx = cx + k;
                    if (xx < 0) xx = -xx; else if (xx >= w) xx = 2 * w - 2 - xx;
                    if (xx < 0) xx = 0; else if (xx >= w) xx = w - 1;
                    s += K5[k + 2] * a[ro + xx];
                }
                t[y * dw + x] = s;
            }
        }
        float[] d = new float[dw * dh];
        for (int y = 0; y < dh; y++) {
            int cy = y * 2;
            for (int x = 0; x < dw; x++) {
                float s = 0;
                for (int k = -2; k <= 2; k++) {
                    int yy = cy + k;
                    if (yy < 0) yy = -yy; else if (yy >= h) yy = 2 * h - 2 - yy;
                    if (yy < 0) yy = 0; else if (yy >= h) yy = h - 1;
                    s += K5[k + 2] * t[yy * dw + x];
                }
                d[y * dw + x] = s;
            }
        }
        return d;
    }

    /** bilinear 2x enlargement of a (aw x ah) plane to (w x h) */
    static float[] up(float[] a, int aw, int ah, int w, int h) {
        float[] o = new float[w * h];
        for (int y = 0; y < h; y++) {
            float gy = (y - 0.5f) * 0.5f;
            if (gy < 0) gy = 0;
            int y0 = (int) gy;
            if (y0 > ah - 1) y0 = ah - 1;
            int y1 = Math.min(ah - 1, y0 + 1);
            float fy = gy - y0;
            for (int x = 0; x < w; x++) {
                float gx = (x - 0.5f) * 0.5f;
                if (gx < 0) gx = 0;
                int x0 = (int) gx;
                if (x0 > aw - 1) x0 = aw - 1;
                int x1 = Math.min(aw - 1, x0 + 1);
                float fx = gx - x0;
                float top = a[y0 * aw + x0] + (a[y0 * aw + x1] - a[y0 * aw + x0]) * fx;
                float bot = a[y1 * aw + x0] + (a[y1 * aw + x1] - a[y1 * aw + x0]) * fx;
                o[y * w + x] = top + (bot - top) * fy;
            }
        }
        return o;
    }

    // ---------- noise of every band, from a plane that holds nothing but noise ----------

    /** sd of the noise in each band (robust, from the median absolute coefficient) */
    public static float[] bandNoise(float[] noisePlane, int w, int h) {
        float[] sig = new float[BANDS];
        float[] g = noisePlane;
        int gw = w, gh = h;
        for (int k = 0; k < BANDS; k++) {
            int dw = (gw + 1) / 2, dh = (gh + 1) / 2;
            if (dw < 4 || dh < 4) { sig[k] = k > 0 ? sig[k - 1] : 1f; continue; }
            float[] d = blurDown(g, gw, gh, dw, dh);
            float[] u = up(d, dw, dh, gw, gh);
            int[] hist = new int[512];
            long total = 0;
            for (int y = 2; y < gh - 2; y += 2) {
                for (int x = 2; x < gw - 2; x += 2) {
                    float c = g[y * gw + x] - u[y * gw + x];
                    int a = (int) (Math.abs(c) * 8f);
                    hist[a > 511 ? 511 : a]++;
                    total++;
                }
            }
            // the 25th percentile of |coefficient| (0.3186 sd for Gaussian noise) is hardly touched by
            // structure that the aligned frames still disagree on, unlike the median
            long q = total / 4, acc = 0;
            int med = 0;
            for (int i = 0; i < 512; i++) { acc += hist[i]; if (acc > q) { med = i; break; } }
            sig[k] = Math.max(0.2f, (med + 0.5f) / 8f / 0.3186f);
            g = d; gw = dw; gh = dh;
        }
        return sig;
    }

    // ---------- the shrinkage ----------

    // mean of a plane over a 3x3 window
    private static float[] box3(float[] a, int w, int h) {
        float[] t = new float[a.length];
        for (int y = 0; y < h; y++) {
            int ro = y * w;
            for (int x = 0; x < w; x++) {
                int xm = x > 0 ? x - 1 : 0, xp = x < w - 1 ? x + 1 : w - 1;
                t[ro + x] = (a[ro + xm] + a[ro + x] + a[ro + xp]) * (1f / 3f);
            }
        }
        float[] o = new float[a.length];
        for (int y = 0; y < h; y++) {
            int ym = (y > 0 ? y - 1 : 0) * w, yc = y * w, yp = (y < h - 1 ? y + 1 : h - 1) * w;
            for (int x = 0; x < w; x++) o[yc + x] = (t[ym + x] + t[yc + x] + t[yp + x]) * (1f / 3f);
        }
        return o;
    }

    /**
     * Like shrink, but every coefficient is kept in proportion to how much it stands out from the noise
     * around it: flat areas are cleaned fully, textured areas keep their detail.
     * @param kappa  over-subtraction of the noise energy per band (1 = textbook Wiener, 2 = strong)
     */
    public static void wiener(float[] plane, int w, int h, float[] sigma, float[] kappa) {
        final int[] gw = new int[BANDS + 1];
        final int[] gh = new int[BANDS + 1];
        float[][] g = new float[BANDS + 1][];
        g[0] = plane;
        gw[0] = w; gh[0] = h;
        for (int k = 0; k < BANDS; k++) {
            gw[k + 1] = (gw[k] + 1) / 2;
            gh[k + 1] = (gh[k] + 1) / 2;
            if (gw[k + 1] < 4 || gh[k + 1] < 4) { gw[k + 1] = 0; break; }
            g[k + 1] = blurDown(g[k], gw[k], gh[k], gw[k + 1], gh[k + 1]);
        }
        int top = BANDS;
        while (top > 0 && gw[top] == 0) top--;
        float[] r = g[top];
        for (int k = top - 1; k >= 0; k--) {
            float[] base = up(g[k + 1], gw[k + 1], gh[k + 1], gw[k], gh[k]);
            float[] cleaned = up(r, gw[k + 1], gh[k + 1], gw[k], gh[k]);
            float[] src = g[k];
            int n = gw[k] * gh[k];
            float[] c = new float[n];
            float[] e = new float[n];
            for (int i = 0; i < n; i++) { c[i] = src[i] - base[i]; e[i] = c[i] * c[i]; }
            float[] v = box3(e, gw[k], gh[k]);
            float n2 = kappa[k] * sigma[k] * sigma[k];
            float[] out = new float[n];
            for (int i = 0; i < n; i++) {
                float gain = v[i] > n2 ? 1f - n2 / v[i] : 0f;
                out[i] = cleaned[i] + c[i] * gain;
            }
            r = out;
        }
        System.arraycopy(r, 0, plane, 0, plane.length);
    }

    /**
     * @param plane   values 0..255, w x h, result is written back
     * @param sigma   noise sd per band (BANDS entries), already scaled to the plane's remaining noise
     * @param alpha   threshold = alpha[k] * sigma[k]
     */
    public static void shrink(float[] plane, int w, int h, float[] sigma, float[] alpha) {
        final int[] gw = new int[BANDS + 1];
        final int[] gh = new int[BANDS + 1];
        float[][] g = new float[BANDS + 1][];
        g[0] = plane;
        gw[0] = w; gh[0] = h;
        for (int k = 0; k < BANDS; k++) {
            gw[k + 1] = (gw[k] + 1) / 2;
            gh[k + 1] = (gh[k] + 1) / 2;
            if (gw[k + 1] < 4 || gh[k + 1] < 4) { gw[k + 1] = 0; break; }
            g[k + 1] = blurDown(g[k], gw[k], gh[k], gw[k + 1], gh[k + 1]);
        }
        // from the coarsest level back up: r = shrunk detail + enlarged (cleaned) coarser level
        int top = BANDS;
        while (top > 0 && gw[top] == 0) top--;
        float[] r = g[top];
        for (int k = top - 1; k >= 0; k--) {
            float[] base = up(g[k + 1], gw[k + 1], gh[k + 1], gw[k], gh[k]);   // from the ORIGINAL coarser level
            float[] cleaned = up(r, gw[k + 1], gh[k + 1], gw[k], gh[k]);
            float t = alpha[k] * sigma[k];
            float[] src = g[k];
            float[] out = new float[gw[k] * gh[k]];
            for (int i = 0; i < out.length; i++) {
                float c = src[i] - base[i];
                float m = Math.abs(c) - t;
                float s = m <= 0f ? 0f : (c < 0 ? -m : m);
                out[i] = cleaned[i] + s;
            }
            r = out;
        }
        System.arraycopy(r, 0, plane, 0, plane.length);
    }

    /**
     * Cleans a whole NV21 frame. bandY / bandC are the noise sd per band of ONE frame, scale turns
     * that into what is left after merging (1 / sqrt(number of frames that count)).
     */
    public static void denoiseNv21(final byte[] nv, final int w, final int h, float[] bandY, float[] bandC,
                                   float scale, float kY, float kC) {
        final int wh = w * h;
        final int cw = w / 2, ch = h / 2;
        final float[] sy = new float[BANDS];
        final float[] sc = new float[BANDS];
        final float[] ky = new float[BANDS];
        final float[] kc = new float[BANDS];
        for (int k = 0; k < BANDS; k++) {
            sy[k] = bandY[k] * scale;
            sc[k] = bandC[k] * scale;
            // the finest bands carry the most grain, the coarse ones are mostly picture
            ky[k] = kY * (1f - 0.08f * k);
            kc[k] = kC * (1f - 0.04f * k);
        }
        Thread tu = new Thread(() -> chroma(nv, wh, w, cw, ch, 1, sc, kc));
        Thread tv = new Thread(() -> chroma(nv, wh, w, cw, ch, 0, sc, kc));
        tu.start();
        tv.start();
        float[] y = new float[wh];
        for (int i = 0; i < wh; i++) y[i] = nv[i] & 0xFF;
        wiener(y, w, h, sy, ky);
        for (int i = 0; i < wh; i++) {
            int v = Math.round(y[i]);
            nv[i] = (byte) (v < 0 ? 0 : (v > 255 ? 255 : v));
        }
        try {
            tu.join();
            tv.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // one of the two interleaved colour planes (off 0 = V, 1 = U)
    private static void chroma(byte[] nv, int wh, int w, int cw, int ch, int off, float[] sg, float[] kappa) {
        float[] p = new float[cw * ch];
        for (int y = 0; y < ch; y++) {
            int ro = wh + y * w + off;
            for (int x = 0; x < cw; x++) p[y * cw + x] = nv[ro + x * 2] & 0xFF;
        }
        wiener(p, cw, ch, sg, kappa);
        for (int y = 0; y < ch; y++) {
            int ro = wh + y * w + off;
            for (int x = 0; x < cw; x++) {
                int v = Math.round(p[y * cw + x]);
                nv[ro + x * 2] = (byte) (v < 0 ? 0 : (v > 255 ? 255 : v));
            }
        }
    }
}
