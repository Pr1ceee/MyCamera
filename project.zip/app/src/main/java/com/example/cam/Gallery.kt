package com.example.cam

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// An iOS Photos style library: a square-cropped grid (newest at the bottom) and a full-screen
// viewer with paging, pinch and double-tap zoom, swipe-down to dismiss, and video playback with
// play/pause, a scrubber and time labels. Hosted by GalleryActivity.
class GalleryView(private val act: Activity, private val accent: Int) : FrameLayout(act) {

    class Item(val uri: Uri, val video: Boolean, val dateMs: Long, val durMs: Long)

    companion object {
        const val REQ_PERM = 77

        // every photo and video this app saved (Pictures/MyCam, Movies/MyCam), oldest first
        fun queryAll(cr: ContentResolver): List<Item> {
            val out = ArrayList<Item>()
            val sel = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?"
            val args = arrayOf("%MyCam%")
            try {
                val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                cr.query(
                    base,
                    arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DATE_ADDED),
                    sel, args, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val taken = c.getLong(1)
                        val added = c.getLong(2)
                        out.add(Item(ContentUris.withAppendedId(base, c.getLong(0)), false, if (taken > 0L) taken else added * 1000L, 0L))
                    }
                }
            } catch (e: Exception) {
            }
            try {
                val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                cr.query(
                    base,
                    arrayOf(
                        MediaStore.Video.Media._ID, MediaStore.Video.Media.DATE_TAKEN,
                        MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.DURATION
                    ),
                    sel, args, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val taken = c.getLong(1)
                        val added = c.getLong(2)
                        out.add(Item(ContentUris.withAppendedId(base, c.getLong(0)), true, if (taken > 0L) taken else added * 1000L, c.getLong(3)))
                    }
                }
            } catch (e: Exception) {
            }
            out.sortBy { it.dateMs }
            return out
        }

        fun latestUri(ctx: Context): Uri? = queryAll(ctx.contentResolver).lastOrNull()?.uri
    }

    private val d = act.resources.displayMetrics.density
    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val thumbs = LruCache<String, Bitmap>(150)
    private val bigs = LruCache<String, Bitmap>(3)
    private val ease = PathInterpolator(0.22f, 1f, 0.36f, 1f)
    private val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
    private val all = ArrayList<Item>()
    private var shown: List<Item> = emptyList()
    private var filter = 0
    private var askedPerm = false
    private var cur = 0
    private var chromeVisible = true

    private val grid = GridView(act)
    private val title = TextView(act)
    private val subtitle = TextView(act)
    private val empty = TextView(act)
    private val viewer = FrameLayout(act)
    private val vTop = FrameLayout(act)
    private val vBottom = FrameLayout(act)
    private val vTitle = TextView(act)
    private val vSub = TextView(act)
    private val vCount = TextView(act)
    private lateinit var pager: Pager

    private fun dp(v: Int) = (v * d).toInt()

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cell = (convertView as? Cell) ?: Cell(act)
            bind(cell, shown[position])
            return cell
        }
    }

    val isOpen: Boolean get() = visibility == View.VISIBLE

    init {
        setBackgroundColor(Color.BLACK)
        isClickable = true
        visibility = View.GONE

        // ----- grid -----
        grid.numColumns = 3
        grid.horizontalSpacing = dp(2)
        grid.verticalSpacing = dp(2)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.setPadding(0, dp(104), 0, dp(40))
        grid.clipToPadding = false
        grid.isVerticalScrollBarEnabled = false
        grid.setSelector(android.R.color.transparent)
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> openViewer(pos) }
        addView(grid, FrameLayout.LayoutParams(-1, -1))

        empty.text = "No Photos or Videos\nPhotos and videos you take appear here."
        empty.setTextColor(Color.parseColor("#8E8E93"))
        empty.textSize = 15f
        empty.gravity = Gravity.CENTER
        empty.visibility = View.GONE
        addView(empty, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // ----- header -----
        val topScrim = View(act)
        topScrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#F2000000"), Color.TRANSPARENT)
        )
        addView(topScrim, FrameLayout.LayoutParams(-1, dp(120), Gravity.TOP))
        title.text = "Recents"
        title.setTextColor(Color.WHITE)
        title.textSize = 30f
        title.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        subtitle.setTextColor(Color.parseColor("#8E8E93"))
        subtitle.textSize = 13f
        val head = LinearLayout(act)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(dp(70), dp(12), 0, 0)
        head.addView(title)
        head.addView(subtitle)
        addView(head, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        val back = circleBtn(GIcon(act, 0), 44)
        back.setOnClickListener { close() }
        val dlp = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START)
        dlp.topMargin = dp(12)
        dlp.leftMargin = dp(14)
        addView(back, dlp)

        buildViewer()
    }

    private fun glassPill(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        return g
    }

    private fun press(v: View) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(ease).start()
            }
            false
        }
    }

    private fun toast(msg: String) = Toast.makeText(act, msg, Toast.LENGTH_SHORT).show()

    // ================= open / close =================

    var onExit: (() -> Unit)? = null

    fun open() {
        ensurePermission()
        visibility = View.VISIBLE
        reload(true)
    }

    // the back button in the header
    fun close() {
        pager.stopVideo()
        onExit?.invoke()
    }

    // true if the back press was used (the full-screen viewer closes first)
    fun handleBack(): Boolean {
        if (viewer.visibility == View.VISIBLE) {
            closeViewer()
            return true
        }
        return false
    }

    fun onHostPause() {
        pager.stopVideo()
    }

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    // the library also shows earlier photos if media access is granted
    private fun ensurePermission() {
        if (askedPerm) return
        val missing = perms().any { act.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing) {
            askedPerm = true
            act.requestPermissions(perms(), REQ_PERM)
        }
    }

    // ================= data =================

    fun reload(toBottom: Boolean) {
        pool.execute {
            val list = query()
            ui.post {
                all.clear()
                all.addAll(list)
                applyFilter(toBottom)
            }
        }
    }

    private fun query(): List<Item> = queryAll(act.contentResolver)

    private fun plural(n: Int, one: String) = "$n " + (if (n == 1) one else one + "s")

    private fun applyFilter(toBottom: Boolean) {
        shown = when (filter) {
            1 -> all.filter { !it.video }
            2 -> all.filter { it.video }
            else -> all.toList()
        }
        adapter.notifyDataSetChanged()
        subtitle.text = plural(all.count { !it.video }, "Photo") + ", " + plural(all.count { it.video }, "Video")
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        if (toBottom) grid.post { grid.setSelection(max(0, shown.size - 1)) }
    }

    // ================= grid cells =================

    private inner class Cell(c: Context) : FrameLayout(c) {
        val img = ImageView(c)
        val scrim = View(c)
        val badge = TextView(c)
        var key: String? = null

        init {
            setBackgroundColor(Color.parseColor("#1C1C1E"))
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            addView(img, FrameLayout.LayoutParams(-1, -1))
            scrim.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.parseColor("#99000000"))
            )
            addView(scrim, FrameLayout.LayoutParams(-1, dp(34), Gravity.BOTTOM))
            badge.setTextColor(Color.WHITE)
            badge.textSize = 11f
            badge.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            badge.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            badge.setPadding(dp(6), dp(4), dp(6), dp(4))
            addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            super.onMeasure(widthMeasureSpec, widthMeasureSpec)
        }
    }

    private fun durationText(ms: Long): String {
        val s = (ms / 1000L).toInt()
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun bind(cell: Cell, m: Item) {
        val key = m.uri.toString()
        cell.key = key
        cell.img.animate().cancel()
        cell.img.alpha = 1f
        if (m.video) {
            cell.badge.visibility = View.VISIBLE
            cell.scrim.visibility = View.VISIBLE
            cell.badge.text = if (m.durMs > 0L) "\u25B6 " + durationText(m.durMs) else "\u25B6"
        } else {
            cell.badge.visibility = View.GONE
            cell.scrim.visibility = View.GONE
        }
        val bm = thumbs.get(key)
        if (bm != null) {
            cell.img.setImageBitmap(bm)
        } else {
            cell.img.setImageDrawable(null)
            pool.execute {
                try {
                    val t = act.contentResolver.loadThumbnail(m.uri, Size(320, 320), null)
                    thumbs.put(key, t)
                    ui.post {
                        if (cell.key == key) {
                            cell.img.setImageBitmap(t)
                            cell.img.alpha = 0f
                            cell.img.animate().alpha(1f).setDuration(180).start()
                        }
                    }
                } catch (e: Exception) {
                }
            }
        }
    }

    // ================= viewer =================

    private fun circleBtn(icon: GIcon, sizeDp: Int): FrameLayout {
        val f = FrameLayout(act)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#66000000"))
        bg.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        f.background = bg
        f.addView(icon, FrameLayout.LayoutParams(dp(sizeDp / 2), dp(sizeDp / 2), Gravity.CENTER))
        f.isClickable = true
        press(f)
        return f
    }

    private fun buildViewer() {
        viewer.setBackgroundColor(Color.BLACK)
        viewer.visibility = View.GONE
        pager = Pager(act)
        viewer.addView(pager, FrameLayout.LayoutParams(-1, -1))

        vTop.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#B3000000"), Color.TRANSPARENT)
        )
        val back = circleBtn(GIcon(act, 0), 44)
        back.setOnClickListener { closeViewer() }
        val blp = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START)
        blp.leftMargin = dp(14)
        blp.topMargin = dp(12)
        vTop.addView(back, blp)
        vTitle.setTextColor(Color.WHITE)
        vTitle.textSize = 16f
        vTitle.gravity = Gravity.CENTER
        vTitle.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        vSub.setTextColor(Color.parseColor("#B0FFFFFF"))
        vSub.textSize = 12f
        vSub.gravity = Gravity.CENTER
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.addView(vTitle)
        col.addView(vSub)
        val clp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        clp.topMargin = dp(14)
        vTop.addView(col, clp)
        viewer.addView(vTop, FrameLayout.LayoutParams(-1, dp(100), Gravity.TOP))

        vBottom.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.TRANSPARENT, Color.parseColor("#B3000000"))
        )
        vCount.setTextColor(Color.parseColor("#B0FFFFFF"))
        vCount.textSize = 13f
        val vlp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        vlp.bottomMargin = dp(36)
        vBottom.addView(vCount, vlp)
        viewer.addView(vBottom, FrameLayout.LayoutParams(-1, dp(110), Gravity.BOTTOM))

        addView(viewer, FrameLayout.LayoutParams(-1, -1))
    }

    private fun dayLabel(ms: Long): String {
        val tz = TimeZone.getDefault()
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val diff = (now + tz.getOffset(now)) / day - (ms + tz.getOffset(ms)) / day
        return when (diff) {
            0L -> "Today"
            1L -> "Yesterday"
            else -> SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date(ms))
        }
    }

    private fun updateViewerTitle() {
        val m = shown.getOrNull(cur) ?: return
        vTitle.text = dayLabel(m.dateMs)
        vSub.text = timeFmt.format(Date(m.dateMs))
        vCount.text = (cur + 1).toString() + " of " + shown.size
    }

    private fun openViewer(pos: Int) {
        if (pos !in shown.indices) return
        cur = pos
        chromeVisible = true
        vTop.visibility = View.VISIBLE
        vBottom.visibility = View.VISIBLE
        vTop.alpha = 1f
        vBottom.alpha = 1f
        pager.reset()
        updateViewerTitle()
        viewer.animate().cancel()
        viewer.alpha = 0f
        viewer.scaleX = 0.92f
        viewer.scaleY = 0.92f
        viewer.visibility = View.VISIBLE
        viewer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).setInterpolator(ease).start()
    }

    private fun closeViewer() {
        pager.stopVideo()
        viewer.animate().cancel()
        viewer.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(220).setInterpolator(ease)
            .withEndAction {
                viewer.visibility = View.GONE
                viewer.scaleX = 1f
                viewer.scaleY = 1f
                pager.resetTransforms()
            }.start()
        grid.setSelection(cur)
    }

    private val autoHide = Runnable {
        if (chromeVisible && pager.pages[1].playingNow) toggleChrome()
    }

    private fun scheduleAutoHide() {
        ui.removeCallbacks(autoHide)
        ui.postDelayed(autoHide, 2800)
    }

    private fun showChrome() {
        if (!chromeVisible) toggleChrome()
    }

    private fun toggleChrome() {
        chromeVisible = !chromeVisible
        for (v in listOf<View>(vTop, vBottom)) {
            v.animate().cancel()
            if (chromeVisible) {
                v.visibility = View.VISIBLE
                v.animate().alpha(1f).setDuration(220).start()
            } else {
                v.animate().alpha(0f).setDuration(220).withEndAction {
                    if (!chromeVisible) v.visibility = View.INVISIBLE
                }.start()
            }
        }
        pager.pages[1].applyChrome(chromeVisible)
        if (chromeVisible && pager.pages[1].playingNow) scheduleAutoHide()
    }

    private fun loadBig(m: Item): Bitmap? {
        return try {
            if (m.video) {
                act.contentResolver.loadThumbnail(m.uri, Size(1280, 1280), null)
            } else {
                val src = ImageDecoder.createSource(act.contentResolver, m.uri)
                ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val big = max(w, h)
                    if (big > 2400) {
                        val f = 2400f / big
                        decoder.setTargetSize(max(1, (w * f).toInt()), max(1, (h * f).toInt()))
                    }
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    // ----- one page of the viewer: a photo or a video (photos pinch / double-tap zoom) -----
    private inner class Page(c: Context) : FrameLayout(c) {
        val img = ImageView(c)
        val playHolder = FrameLayout(c)
        private val playIcon = GIcon(c, 3)
        private val controls = LinearLayout(c)
        private val seek = SeekBar(c)
        private val tNow = TextView(c)
        private val tLeft = TextView(c)
        var item: Item? = null
        private var bmp: Bitmap? = null
        private var scale = 1f
        private var tx = 0f
        private var ty = 0f
        private val m = Matrix()
        private var vv: VideoView? = null
        private var zoomAnim: ValueAnimator? = null
        private var scrubbing = false
        val zoomed: Boolean get() = scale > 1.02f
        val playing: Boolean get() = vv != null
        val playingNow: Boolean get() = vv?.isPlaying == true
        private val tick = object : Runnable {
            override fun run() {
                val v = vv ?: return
                if (!scrubbing) syncProgress(v.currentPosition)
                if (v.isPlaying) ui.postDelayed(this, 200)
            }
        }

        init {
            img.scaleType = ImageView.ScaleType.MATRIX
            addView(img, FrameLayout.LayoutParams(-1, -1))

            // centre play / pause button
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.parseColor("#80000000"))
            bg.setStroke(dp(1), Color.parseColor("#4DFFFFFF"))
            playHolder.background = bg
            playHolder.addView(playIcon, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            playHolder.visibility = View.GONE
            addView(playHolder, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER))

            // scrubber with elapsed / remaining time
            controls.orientation = LinearLayout.HORIZONTAL
            controls.gravity = Gravity.CENTER_VERTICAL
            controls.setPadding(dp(18), 0, dp(18), 0)
            for (t in listOf(tNow, tLeft)) {
                t.setTextColor(Color.WHITE)
                t.textSize = 12f
                t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            seek.progressTintList = ColorStateList.valueOf(accent)
            seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        vv?.seekTo(p)
                        syncProgress(p)
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar) {
                    scrubbing = true
                    ui.removeCallbacks(autoHide)
                }
                override fun onStopTrackingTouch(s: SeekBar) {
                    scrubbing = false
                    if (playingNow) scheduleAutoHide()
                }
            })
            controls.addView(tNow, LinearLayout.LayoutParams(-2, -2))
            controls.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
            controls.addView(tLeft, LinearLayout.LayoutParams(-2, -2))
            controls.visibility = View.GONE
            val clp = FrameLayout.LayoutParams(-1, dp(44), Gravity.BOTTOM)
            clp.bottomMargin = dp(72)
            addView(controls, clp)
        }

        fun show(entry: Item?) {
            stopVideo()
            item = entry
            bmp = null
            img.setImageDrawable(null)
            scale = 1f
            tx = 0f
            ty = 0f
            playIcon.type = 3
            playHolder.animate().cancel()
            playHolder.alpha = 1f
            playHolder.visibility = if (entry != null && entry.video) View.VISIBLE else View.GONE
            controls.visibility = View.GONE
            if (entry == null) return
            val key = entry.uri.toString()
            val t = thumbs.get(key)
            if (t != null) setBitmap(t)
            val big = bigs.get(key)
            if (big != null) {
                setBitmap(big)
                return
            }
            pool.execute {
                val bm = loadBig(entry)
                if (bm != null) {
                    bigs.put(key, bm)
                    ui.post { if (item === entry) setBitmap(bm) }
                }
            }
        }

        private fun setBitmap(b: Bitmap) {
            bmp = b
            img.setImageBitmap(b)
            clamp()
            apply()
        }

        private fun baseScale(): Float {
            val b = bmp ?: return 1f
            if (width == 0 || height == 0) return 1f
            return min(width.toFloat() / b.width, height.toFloat() / b.height)
        }

        private fun clamp() {
            val b = bmp ?: return
            val s = baseScale() * scale
            val iw = b.width * s
            val ih = b.height * s
            tx = if (iw <= width) (width - iw) / 2f else tx.coerceIn(width - iw, 0f)
            ty = if (ih <= height) (height - ih) / 2f else ty.coerceIn(height - ih, 0f)
        }

        private fun apply() {
            val s = baseScale() * scale
            m.reset()
            m.postScale(s, s)
            m.postTranslate(tx, ty)
            img.imageMatrix = m
        }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            clamp()
            apply()
        }

        fun zoomBy(f: Float, fx: Float, fy: Float) {
            if (bmp == null || item?.video == true) return
            val s0 = baseScale() * scale
            val ns = (scale * f).coerceIn(0.85f, 5f)
            val s1 = baseScale() * ns
            val ix = (fx - tx) / s0
            val iy = (fy - ty) / s0
            scale = ns
            tx = fx - ix * s1
            ty = fy - iy * s1
            clamp()
            apply()
        }

        private fun animateZoom(target: Float, fx: Float, fy: Float) {
            zoomAnim?.cancel()
            val a = ValueAnimator.ofFloat(scale, target)
            a.duration = 280
            a.interpolator = ease
            a.addUpdateListener { zoomBy((it.animatedValue as Float) / scale, fx, fy) }
            a.start()
            zoomAnim = a
        }

        fun toggleZoom(x: Float, y: Float) {
            if (bmp == null || item?.video == true) return
            animateZoom(if (zoomed) 1f else 2.5f, x, y)
        }

        fun settleZoom() {
            if (scale < 1f) animateZoom(1f, width / 2f, height / 2f)
        }

        fun panBy(dx: Float, dy: Float) {
            tx += dx
            ty += dy
            clamp()
            apply()
        }

        fun hitPlay(x: Float, y: Float): Boolean =
            playHolder.visibility == View.VISIBLE && abs(x - width / 2f) < dp(60) && abs(y - height / 2f) < dp(60)

        // ----- video -----

        private fun syncProgress(pos: Int) {
            val total = vv?.duration ?: -1
            val dur = if (total > 0) total else (item?.durMs ?: 0L).toInt()
            seek.progress = pos
            tNow.text = durationText(pos.toLong())
            tLeft.text = "-" + durationText(max(0, dur - pos).toLong())
        }

        private fun fadeTo(v: View, show: Boolean) {
            v.animate().cancel()
            if (show) {
                v.visibility = View.VISIBLE
                v.animate().alpha(1f).setDuration(200).start()
            } else {
                v.animate().alpha(0f).setDuration(200).withEndAction { v.visibility = View.INVISIBLE }.start()
            }
        }

        // while a video plays, the buttons and scrubber follow the viewer's chrome
        fun applyChrome(show: Boolean) {
            if (item?.video != true) return
            fadeTo(playHolder, show || !playingNow)
            fadeTo(controls, show && vv != null)
        }

        fun startVideo() {
            val entry = item ?: return
            if (!entry.video || vv != null) return
            val v = VideoView(context)
            vv = v
            addView(v, 0, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            v.setVideoURI(entry.uri)
            v.setOnPreparedListener { mp ->
                img.visibility = View.INVISIBLE
                seek.max = max(1, v.duration)
                syncProgress(0)
                controls.alpha = 1f
                controls.visibility = View.VISIBLE
                playIcon.type = 4
                mp.start()
                ui.removeCallbacks(tick)
                ui.post(tick)
                scheduleAutoHide()
            }
            v.setOnCompletionListener {
                stopVideo()
                showChrome()
            }
            v.setOnErrorListener { _, _, _ ->
                stopVideo()
                toast("Can't play this video")
                true
            }
        }

        fun togglePause() {
            val v = vv ?: return
            if (v.isPlaying) {
                v.pause()
                playIcon.type = 3
                ui.removeCallbacks(autoHide)
                showChrome()
            } else {
                v.start()
                playIcon.type = 4
                ui.removeCallbacks(tick)
                ui.post(tick)
                scheduleAutoHide()
            }
        }

        fun stopVideo() {
            ui.removeCallbacks(tick)
            val v = vv ?: return
            try {
                v.stopPlayback()
            } catch (e: Exception) {
            }
            removeView(v)
            vv = null
            scrubbing = false
            img.visibility = View.VISIBLE
            controls.visibility = View.GONE
            playIcon.type = 3
            if (item?.video == true) {
                playHolder.animate().cancel()
                playHolder.alpha = 1f
                playHolder.visibility = View.VISIBLE
            }
        }
    }

    // ----- pages the viewer: previous / current / next, with drag, fling and dismiss -----
    private inner class Pager(c: Context) : FrameLayout(c) {
        val pages = Array(3) { Page(c) }
        private var dragX = 0f
        private var dragY = 0f
        private var animating = false
        private var mode = 0 // 0 undecided, 1 paging, 2 dismiss, 3 panning, 4 pinching, 5 ignore
        private var downX = 0f
        private var downY = 0f
        private var lastX = 0f
        private var lastY = 0f
        private var vt: VelocityTracker? = null
        private val slop = ViewConfiguration.get(c).scaledTouchSlop

        private val scaleDet = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(det: ScaleGestureDetector): Boolean {
                pages[1].zoomBy(det.scaleFactor, det.focusX, det.focusY)
                return true
            }
        })
        private val tapDet = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onTap(e.x, e.y)
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                pages[1].toggleZoom(e.x, e.y)
                return true
            }
        })

        init {
            for (p in pages) addView(p, FrameLayout.LayoutParams(-1, -1))
        }

        fun reset() {
            dragX = 0f
            dragY = 0f
            animating = false
            resetTransforms()
            bindPages()
            layoutPages()
        }

        fun resetTransforms() {
            dragX = 0f
            dragY = 0f
            pages[1].scaleX = 1f
            pages[1].scaleY = 1f
            viewer.setBackgroundColor(Color.BLACK)
            layoutPages()
        }

        fun bindPages() {
            pages[0].show(shown.getOrNull(cur - 1))
            pages[1].show(shown.getOrNull(cur))
            pages[2].show(shown.getOrNull(cur + 1))
        }

        fun stopVideo() {
            for (p in pages) p.stopVideo()
        }

        private fun layoutPages() {
            val w = width.toFloat()
            for (i in 0..2) {
                pages[i].translationX = (i - 1) * w + dragX
                pages[i].translationY = if (i == 1) dragY else 0f
            }
        }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            layoutPages()
        }

        private fun onTap(x: Float, y: Float) {
            val p = pages[1]
            val entry = p.item ?: return
            if (entry.video && p.hitPlay(x, y)) {
                if (p.playing) p.togglePause() else p.startVideo()
                return
            }
            toggleChrome()
        }

        private fun applyDismiss() {
            val h = max(1f, height.toFloat())
            val prog = (abs(dragY) / h).coerceIn(0f, 1f)
            val p = pages[1]
            p.translationY = dragY
            p.scaleX = 1f - prog * 0.35f
            p.scaleY = 1f - prog * 0.35f
            viewer.setBackgroundColor(Color.argb(((1f - prog * 1.4f).coerceIn(0f, 1f) * 255).toInt(), 0, 0, 0))
            if (chromeVisible) {
                val a = (1f - prog * 4f).coerceIn(0f, 1f)
                vTop.alpha = a
                vBottom.alpha = a
            }
        }

        private fun finishPaging(vx: Float) {
            val w = width.toFloat()
            var target = 0f
            var dir = 0
            if ((dragX < -w * 0.25f || vx < -900f) && cur < shown.size - 1) {
                target = -w
                dir = 1
            } else if ((dragX > w * 0.25f || vx > 900f) && cur > 0) {
                target = w
                dir = -1
            }
            animating = true
            val a = ValueAnimator.ofFloat(dragX, target)
            a.duration = 280
            a.interpolator = ease
            a.addUpdateListener {
                dragX = it.animatedValue as Float
                layoutPages()
            }
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    animating = false
                    if (dir != 0) {
                        cur += dir
                        dragX = 0f
                        bindPages()
                        layoutPages()
                        updateViewerTitle()
                    }
                }
            })
            a.start()
        }

        private fun finishDismiss(vy: Float) {
            if (abs(dragY) > height * 0.18f || abs(vy) > 1400f) {
                closeViewer()
                return
            }
            animating = true
            val a = ValueAnimator.ofFloat(dragY, 0f)
            a.duration = 260
            a.interpolator = ease
            a.addUpdateListener {
                dragY = it.animatedValue as Float
                applyDismiss()
            }
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    animating = false
                }
            })
            a.start()
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (animating) return true
            scaleDet.onTouchEvent(ev)
            tapDet.onTouchEvent(ev)
            val page = pages[1]
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    lastX = ev.x
                    lastY = ev.y
                    mode = 0
                    vt?.recycle()
                    vt = VelocityTracker.obtain()
                    vt?.addMovement(ev)
                }
                MotionEvent.ACTION_POINTER_DOWN -> mode = 4
                MotionEvent.ACTION_POINTER_UP -> {
                    val idx = if (ev.actionIndex == 0) 1 else 0
                    lastX = ev.getX(idx)
                    lastY = ev.getY(idx)
                    mode = if (page.zoomed) 3 else 5
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(ev)
                    if (mode == 4 || scaleDet.isInProgress) {
                        mode = 4
                    } else {
                        val dx = ev.x - lastX
                        val dy = ev.y - lastY
                        if (mode == 0 && (abs(ev.x - downX) > slop || abs(ev.y - downY) > slop)) {
                            mode = if (page.zoomed) 3 else if (abs(ev.x - downX) > abs(ev.y - downY)) 1 else 2
                            if (mode == 1 || mode == 2) page.stopVideo()
                        }
                        when (mode) {
                            1 -> {
                                var nx = dragX + dx
                                if ((nx > 0f && cur == 0) || (nx < 0f && cur >= shown.size - 1)) nx = dragX + dx * 0.35f
                                dragX = nx
                                layoutPages()
                            }
                            2 -> {
                                dragY += dy
                                applyDismiss()
                            }
                            3 -> page.panBy(dx, dy)
                        }
                        lastX = ev.x
                        lastY = ev.y
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    vt?.addMovement(ev)
                    vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    val vy = vt?.yVelocity ?: 0f
                    vt?.recycle()
                    vt = null
                    when (mode) {
                        1 -> finishPaging(vx)
                        2 -> finishDismiss(vy)
                        4, 5 -> page.settleZoom()
                    }
                    mode = 0
                }
            }
            return true
        }
    }
}

// small line icons: 0 back chevron, 1 share, 2 trash, 3 play
private class GIcon(c: Context, t: Int) : View(c) {
    var type = t
        set(v) {
            field = v
            invalidate()
        }
    var tint = Color.WHITE
        set(v) {
            field = v
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        canvas.scale(s, s)
        p.color = tint
        p.strokeWidth = 1.9f
        p.style = Paint.Style.STROKE
        when (type) {
            0 -> {
                path.reset()
                path.moveTo(15f, 5f)
                path.lineTo(8f, 12f)
                path.lineTo(15f, 19f)
                canvas.drawPath(path, p)
            }
            1 -> {
                path.reset()
                path.moveTo(8.5f, 10f)
                path.lineTo(6.5f, 10f)
                path.lineTo(6.5f, 20f)
                path.lineTo(17.5f, 20f)
                path.lineTo(17.5f, 10f)
                path.lineTo(15.5f, 10f)
                canvas.drawPath(path, p)
                canvas.drawLine(12f, 3f, 12f, 14f, p)
                path.reset()
                path.moveTo(8.5f, 6.5f)
                path.lineTo(12f, 3f)
                path.lineTo(15.5f, 6.5f)
                canvas.drawPath(path, p)
            }
            2 -> {
                canvas.drawLine(5f, 7f, 19f, 7f, p)
                path.reset()
                path.moveTo(10f, 7f)
                path.lineTo(10f, 4.5f)
                path.lineTo(14f, 4.5f)
                path.lineTo(14f, 7f)
                canvas.drawPath(path, p)
                path.reset()
                path.moveTo(7f, 7f)
                path.lineTo(8f, 20f)
                path.lineTo(16f, 20f)
                path.lineTo(17f, 7f)
                canvas.drawPath(path, p)
                canvas.drawLine(10.5f, 11f, 10.5f, 16f, p)
                canvas.drawLine(13.5f, 11f, 13.5f, 16f, p)
            }
            3 -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(8f, 5f)
                path.lineTo(19f, 12f)
                path.lineTo(8f, 19f)
                path.close()
                canvas.drawPath(path, p)
            }
            4 -> {
                p.style = Paint.Style.FILL
                canvas.drawRoundRect(6.5f, 5f, 10.5f, 19f, 1.5f, 1.5f, p)
                canvas.drawRoundRect(13.5f, 5f, 17.5f, 19f, 1.5f, 1.5f, p)
            }
        }
        canvas.restore()
    }
}

// The separate Gallery screen. The camera screen stays in the back stack, so its mode, zoom and
// settings are exactly as left when you come back.
class GalleryActivity : Activity() {
    private lateinit var gallery: GalleryView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        gallery = GalleryView(this, Color.parseColor("#FFD60A"))
        gallery.onExit = { finish() }
        setContentView(gallery)
        gallery.open()
    }

    override fun onPause() {
        gallery.onHostPause()
        super.onPause()
    }

    override fun onBackPressed() {
        if (!gallery.handleBack()) super.onBackPressed()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == GalleryView.REQ_PERM) gallery.reload(false)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left_parallax, R.anim.slide_out_right)
    }
}
