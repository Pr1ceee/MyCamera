package com.example.cam;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * The "look" of a finished photo, applied to the merged NV21 frame:
 * local tone mapping (lifts shadows, keeps highlights), a touch of local contrast and S-curve,
 * richer but skin-safe colour, and noise-aware sharpening.
 * Pure Java on byte arrays, every stage runs on all given threads.
 */
public final class Look {
    private Look() {}

    private static final int GRID = 8;          // local contrast grid (pixels per cell)
    private static final int LUT_N = 1024;

    /**
     * Noise level (standard deviation, 8-bit luma steps) of a frame, from the median response of a
     * noise-only filter, so edges and texture barely count. Looks at about 1 in 8 of the rows.
     */
    public static float estimateNoise(ByteBuffer luma, int w, int h, int rowStride) {
        if (w < 16 || h < 16) return 3f;
        ByteBuffer b = luma.duplicate();
        byte[] r0 = new byte[w];
        byte[] r1 = new byte[w];
        byte[] r2 = new byte[w];
        int[] hist = new int[1024];
        long total = 0;
        for (int y = 1; y < h - 1; y += 8) {
            b.position((y - 1) * rowStride); b.get(r0, 0, w);
            b.position(y * rowStride);       b.get(r1, 0, w);
            b.position((y + 1) * rowStride); b.get(r2, 0, w);
            for (int x = 1; x < w - 1; x += 2) {
                int r = (r0[x - 1] & 0xFF) - 2 * (r0[x] & 0xFF) + (r0[x + 1] & 0xFF)
                        - 2 * (r1[x - 1] & 0xFF) + 4 * (r1[x] & 0xFF) - 2 * (r1[x + 1] & 0xFF)
                        + (r2[x - 1] & 0xFF) - 2 * (r2[x] & 0xFF) + (r2[x + 1] & 0xFF);
                if (r < 0) r = -r;
                hist[r > 1023 ? 1023 : r]++;
                total++;
            }
        }
        return medianToSigma(hist, total);
    }

    public static float estimateNoise(byte[] nv, int w, int h) {
        return estimateNoise(ByteBuffer.wrap(nv), w, h, w);
    }

    private static float medianToSigma(int[] hist, long total) {
        if (total == 0) return 3f;
        long half = total / 2;
        long acc = 0;
        int med = 0;
        for (int i = 0; i < hist.length; i++) {
            acc += hist[i];
            if (acc > half) { med = i; break; }
        }
        // for pure noise the response has sd 6*sigma and median(|x|) = 0.6745 sd
        return Math.max(0.5f, Math.min(40f, (med + 0.5f) / 4.047f));
    }

    /**
     * @param nv      NV21 frame, modified in place
     * @param sharp   sharpening strength, 0 = none, 1 = normal (use less for single frames)
     */
    public static void process(byte[] nv, int w, int h, int threads, float sharp) {
        process(nv, w, h, threads, sharp, null, null, 0f, 0f);
    }

    /**
     * @param bandY    noise sd per pyramid band of one frame (luma), measured by the merge, or null
     * @param bandC    the same for colour
     * @param scale    what is left of that noise after merging
     * @param resid    noise sd left in the merged luma
     */
    public static void process(byte[] nv, int w, int h, int threads, float sharp,
                               float[] bandY, float[] bandC, float scale, float resid) {
        if (w < 64 || h < 64) return;
        final int wh = w * h;
        final float noise;
        final float after;       // noise expected once the cleaning is done
        if (bandY != null && bandC != null && resid > 0f) {
            noise = resid;
            float kY = clamp(1.0f + (resid - 2.0f) / 4.0f, 1.0f, 2.0f);
            float kC = clamp(2.5f + resid * 0.25f, 2.5f, 4.5f);
            if (resid >= 1.2f) {
                Pyr.denoiseNv21(nv, w, h, bandY, bandC, scale, kY, kC);
                after = resid * 0.5f;
            } else {
                after = resid;
            }
        } else {
            noise = estimateNoise(nv, w, h);
            after = noise;
            if (noise >= 2.2f) denoise(nv, w, h, threads, noise);
        }
        // 0 for a clean frame, 1 for a very noisy one
        final float noisy = clamp((after - 2.5f) / 7f, 0f, 1f);
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, threads));
        try {
            // ---- coarse brightness maps ----
            final int bw = (w + GRID - 1) / GRID;
            final int bh = (h + GRID - 1) / GRID;
            final float[] b8 = new float[bw * bh];
            gridMean(nv, w, h, bw, bh, b8);
            blur(b8, bw, bh, 1, 2);                          // local average, ~25 px
            final float[] tb = b8.clone();
            blur(tb, bw, bh, 5, 2);                          // wide average for the shadow lift, ~120 px

            // how dark the scene is overall decides how much shadow lift is welcome
            double sum = 0;
            for (float v : tb) sum += v;
            float mean = (float) (sum / tb.length);
            float lift = clamp((mean - 0.10f) / 0.20f, 0.25f, 1.0f) * (1f - 0.6f * noisy);

            final float[] gainLut = new float[LUT_N + 1];
            for (int k = 0; k <= LUT_N; k++) {
                float g = Math.max(k / (float) LUT_N, 0.03f);
                float gn = (float) Math.pow(g, -0.20);        // brighter by (g^0.8)/g
                gn = Math.min(gn, 1.75f);
                gainLut[k] = 1f + lift * (gn - 1f);
            }

            // ---- pass 1: tone map the luma into a second array ----
            final byte[] yt = new byte[wh];
            final int[] x0 = new int[w];
            final float[] fx = new float[w];
            for (int x = 0; x < w; x++) {
                float gx = (x + 0.5f) / GRID - 0.5f;
                int i0 = (int) Math.floor(gx);
                fx[x] = gx - i0;
                x0[x] = Math.max(0, Math.min(bw - 1, i0));
            }
            final float clarity = 0.30f * (1f - 0.8f * noisy);
            final float contrast = 0.30f;
            final float black = 0.010f;
            final int bands = Math.max(1, threads) * 3;
            runBands(pool, h, bands, (ya, yb) -> {
                for (int y = ya; y < yb; y++) {
                    float gy = (y + 0.5f) / GRID - 0.5f;
                    int j0 = (int) Math.floor(gy);
                    float fy = gy - j0;
                    int ja = Math.max(0, Math.min(bh - 1, j0));
                    int jb = Math.max(0, Math.min(bh - 1, j0 + 1));
                    int ra = ja * bw;
                    int rb = jb * bw;
                    int ro = y * w;
                    for (int x = 0; x < w; x++) {
                        int ia = x0[x];
                        int ib = Math.min(bw - 1, ia + 1);
                        float f = fx[x];
                        float local = lerp(lerp(b8[ra + ia], b8[ra + ib], f), lerp(b8[rb + ia], b8[rb + ib], f), fy);
                        float wide = lerp(lerp(tb[ra + ia], tb[ra + ib], f), lerp(tb[rb + ia], tb[rb + ib], f), fy);
                        float v = (nv[ro + x] & 0xFF) * (1f / 255f);
                        float gain = gainLut[(int) (clamp(wide, 0f, 1f) * LUT_N + 0.5f)];
                        float o = v * gain;
                        o += clarity * (v - local) * (4f * v * (1f - v));
                        if (o < 0f) o = 0f;
                        if (o > 0.92f) o = 0.92f + 0.08f * (1f - (float) Math.exp(-(o - 0.92f) * 12.5f));
                        if (o > 1f) o = 1f;
                        float s = o * o * (3f - 2f * o);
                        o += contrast * (s - o);
                        o = (o - black) / (1f - black);
                        if (o < 0f) o = 0f;
                        yt[ro + x] = (byte) (o * 255f + 0.5f);
                    }
                }
            });

            // ---- pass 2: colour, from the old and new brightness ----
            runBands(pool, h / 2, bands, (ca, cb) -> {
                for (int cy = ca; cy < cb; cy++) {
                    int r0 = cy * 2 * w;
                    int r1 = r0 + w;
                    int co = wh + cy * w;
                    for (int cx = 0; cx < w / 2; cx++) {
                        int p = cx * 2;
                        float yo = ((nv[r0 + p] & 0xFF) + (nv[r0 + p + 1] & 0xFF)
                                + (nv[r1 + p] & 0xFF) + (nv[r1 + p + 1] & 0xFF)) * 0.25f;
                        float yn = ((yt[r0 + p] & 0xFF) + (yt[r0 + p + 1] & 0xFF)
                                + (yt[r1 + p] & 0xFF) + (yt[r1 + p + 1] & 0xFF)) * 0.25f;
                        float ratio = (yn + 6f) / (yo + 6f);
                        float comp = (float) Math.sqrt(ratio);
                        comp = clamp(comp, 0.95f, 1.18f);
                        float v = (nv[co + p] & 0xFF) - 128f;
                        float u = (nv[co + p + 1] & 0xFF) - 128f;
                        float sat = (float) Math.sqrt(u * u + v * v);
                        float hump = sat < 8f ? sat / 8f : (sat < 30f ? 1f : Math.max(0f, 1f - (sat - 30f) / 45f));
                        float boost = 1.04f + 0.16f * hump;
                        // skin tones stay natural: only a quarter of the boost there
                        if (u > -58f && u < 2f && v > 3f && v < 52f) boost = 1f + (boost - 1f) * 0.25f;
                        float cf = boost * comp;
                        int nvv = Math.round(128f + v * cf);
                        int nu = Math.round(128f + u * cf);
                        nv[co + p] = (byte) (nvv < 0 ? 0 : (nvv > 255 ? 255 : nvv));
                        nv[co + p + 1] = (byte) (nu < 0 ? 0 : (nu > 255 ? 255 : nu));
                    }
                }
            });

            // ---- pass 3: sharpen the new luma back into the frame ----
            final float amount = 0.85f * sharp * (1f - 0.6f * noisy);
            final float coreT = Math.max(2.2f, 1.1f * after);
            runBands(pool, h, bands, (ya, yb) -> {
                for (int y = ya; y < yb; y++) {
                    int ym = Math.max(0, y - 1) * w;
                    int yc = y * w;
                    int yp = Math.min(h - 1, y + 1) * w;
                    for (int x = 0; x < w; x++) {
                        int xm = x == 0 ? 0 : x - 1;
                        int xp = x == w - 1 ? w - 1 : x + 1;
                        int c = yt[yc + x] & 0xFF;
                        int blurSum = 4 * c
                                + 2 * ((yt[yc + xm] & 0xFF) + (yt[yc + xp] & 0xFF) + (yt[ym + x] & 0xFF) + (yt[yp + x] & 0xFF))
                                + (yt[ym + xm] & 0xFF) + (yt[ym + xp] & 0xFF) + (yt[yp + xm] & 0xFF) + (yt[yp + xp] & 0xFF);
                        float d = c - blurSum * (1f / 16f);
                        float mag = Math.abs(d);
                        // fine grain stays untouched, real edges get crisper, halos are capped
                        float t = coreT;
                        float m = mag - t;
                        float out;
                        if (m <= 0f) {
                            out = c;
                        } else {
                            if (m > 26f) m = 26f;
                            out = c + amount * (d < 0 ? -m : m);
                        }
                        int oi = Math.round(out);
                        nv[yc + x] = (byte) (oi < 0 ? 0 : (oi > 255 ? 255 : oi));
                    }
                }
            });
        } finally {
            pool.shutdown();
        }
    }

    // ---------- noise removal ----------

    /**
     * Edge-preserving smoothing: luma with a sparse bilateral filter, colour with a wider filter
     * that follows the brightness edges. Strength follows the measured noise.
     */
    public static void denoise(byte[] nv, int w, int h, int threads, float noise) {
        final int wh = w * h;
        final int cw = w / 2;
        final int ch = h / 2;
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, threads));
        try {
            final int bands = Math.max(1, threads) * 3;
            // luma: weights fall off with brightness difference, scaled by the noise level
            final float rs = 2.4f * noise + 1f;
            final float[] wl = new float[256];
            for (int d = 0; d < 256; d++) wl[d] = (float) Math.exp(-(d * d) / (2.0 * rs * rs));
            final float strength = clamp((noise - 1.8f) / 4f, 0.25f, 0.85f);
            final byte[] src = new byte[wh];
            System.arraycopy(nv, 0, src, 0, wh);
            final int[] ox = {-1, 1, 0, 0, -1, 1, -1, 1, -2, 2, 0, 0};
            final int[] oy = {0, 0, -1, 1, -1, -1, 1, 1, 0, 0, -2, 2};
            final float[] ow = {1f, 1f, 1f, 1f, 0.7f, 0.7f, 0.7f, 0.7f, 0.5f, 0.5f, 0.5f, 0.5f};
            runBands(pool, h, bands, (ya, yb) -> {
                for (int y = ya; y < yb; y++) {
                    for (int x = 0; x < w; x++) {
                        int c = src[y * w + x] & 0xFF;
                        float sum = c * 1.5f;
                        float ws = 1.5f;
                        for (int k = 0; k < 12; k++) {
                            int xx = x + ox[k];
                            int yy = y + oy[k];
                            if (xx < 0) xx = 0; else if (xx >= w) xx = w - 1;
                            if (yy < 0) yy = 0; else if (yy >= h) yy = h - 1;
                            int v = src[yy * w + xx] & 0xFF;
                            int d = v - c;
                            float wt = ow[k] * wl[d < 0 ? -d : d];
                            sum += wt * v;
                            ws += wt;
                        }
                        float o = c + strength * (sum / ws - c);
                        nv[y * w + x] = (byte) (o + 0.5f);
                    }
                }
            });

            // colour: 5x5, only across similar brightness
            final byte[] ly = new byte[cw * ch];
            for (int cy = 0; cy < ch; cy++) {
                for (int cx = 0; cx < cw; cx++) {
                    int r0 = cy * 2 * w + cx * 2;
                    ly[cy * cw + cx] = (byte) (((nv[r0] & 0xFF) + (nv[r0 + 1] & 0xFF)
                            + (nv[r0 + w] & 0xFF) + (nv[r0 + w + 1] & 0xFF)) >> 2);
                }
            }
            final byte[] cc = new byte[wh / 2];
            System.arraycopy(nv, wh, cc, 0, wh / 2);
            final float cr = 5f + 3.5f * noise;
            final float[] wc = new float[256];
            for (int d = 0; d < 256; d++) wc[d] = (float) Math.exp(-(d * d) / (2.0 * cr * cr));
            final int rad = noise >= 5f ? 3 : 2;
            runBands(pool, ch, bands, (ya, yb) -> {
                for (int cy = ya; cy < yb; cy++) {
                    for (int cx = 0; cx < cw; cx++) {
                        int lc = ly[cy * cw + cx] & 0xFF;
                        float sv = 0, su = 0, ws = 0;
                        for (int dy = -rad; dy <= rad; dy++) {
                            int yy = cy + dy;
                            if (yy < 0) yy = 0; else if (yy >= ch) yy = ch - 1;
                            for (int dx = -rad; dx <= rad; dx++) {
                                int xx = cx + dx;
                                if (xx < 0) xx = 0; else if (xx >= cw) xx = cw - 1;
                                int d = (ly[yy * cw + xx] & 0xFF) - lc;
                                float wt = wc[d < 0 ? -d : d];
                                int o = yy * w + xx * 2;
                                sv += wt * (cc[o] & 0xFF);
                                su += wt * (cc[o + 1] & 0xFF);
                                ws += wt;
                            }
                        }
                        int o = wh + cy * w + cx * 2;
                        nv[o] = (byte) (sv / ws + 0.5f);
                        nv[o + 1] = (byte) (su / ws + 0.5f);
                    }
                }
            });
        } finally {
            pool.shutdown();
        }
    }

    // ---------- helpers ----------

    private interface Band {
        void run(int from, int to);
    }

    private static void runBands(ExecutorService pool, int rows, int bands, Band job) {
        List<Future<?>> fs = new ArrayList<>();
        for (int i = 0; i < bands; i++) {
            final int a = rows * i / bands;
            final int b = rows * (i + 1) / bands;
            if (b <= a) continue;
            fs.add(pool.submit(() -> job.run(a, b)));
        }
        try {
            for (Future<?> f : fs) f.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void gridMean(byte[] nv, int w, int h, int bw, int bh, float[] out) {
        for (int j = 0; j < bh; j++) {
            int ys = j * GRID;
            int ye = Math.min(h, ys + GRID);
            for (int i = 0; i < bw; i++) {
                int xs = i * GRID;
                int xe = Math.min(w, xs + GRID);
                int sum = 0;
                for (int y = ys; y < ye; y++) {
                    int ro = y * w;
                    for (int x = xs; x < xe; x++) sum += nv[ro + x] & 0xFF;
                }
                out[j * bw + i] = sum / (float) ((ye - ys) * (xe - xs)) * (1f / 255f);
            }
        }
    }

    // box blur, `passes` times, with the edge value repeated
    private static void blur(float[] a, int w, int h, int radius, int passes) {
        float[] tmp = new float[a.length];
        for (int p = 0; p < passes; p++) {
            for (int y = 0; y < h; y++) {
                int ro = y * w;
                for (int x = 0; x < w; x++) {
                    float s = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int xx = x + k;
                        if (xx < 0) xx = 0; else if (xx >= w) xx = w - 1;
                        s += a[ro + xx];
                    }
                    tmp[ro + x] = s / (2 * radius + 1);
                }
            }
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    float s = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int yy = y + k;
                        if (yy < 0) yy = 0; else if (yy >= h) yy = h - 1;
                        s += tmp[yy * w + x];
                    }
                    a[y * w + x] = s / (2 * radius + 1);
                }
            }
        }
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
