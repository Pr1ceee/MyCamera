package com.example.cam;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * The "look" of a finished photo, applied to the merged NV21 frame:
 * local tone mapping (lifts shadows, keeps highlights), a touch of local contrast and S-curve,
 * richer but skin-safe colour, and noise-aware sharpening.
 * Pure Java on byte arrays, every stage runs on all given threads.
 */
public final class Look {
    private Look() {}

    private static final int GRID = 8;          // local contrast grid (pixels per cell)
    private static final int LUT_N = 1024;

    /**
     * @param nv      NV21 frame, modified in place
     * @param sharp   sharpening strength, 0 = none, 1 = normal (use less for single frames)
     */
    public static void process(byte[] nv, int w, int h, int threads, float sharp) {
        if (w < 64 || h < 64) return;
        final int wh = w * h;
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, threads));
        try {
            // ---- coarse brightness maps ----
            final int bw = (w + GRID - 1) / GRID;
            final int bh = (h + GRID - 1) / GRID;
            final float[] b8 = new float[bw * bh];
            gridMean(nv, w, h, bw, bh, b8);
            blur(b8, bw, bh, 1, 2);                          // local average, ~25 px
            final float[] tb = b8.clone();
            blur(tb, bw, bh, 5, 2);                          // wide average for the shadow lift, ~120 px

            // how dark the scene is overall decides how much shadow lift is welcome
            double sum = 0;
            for (float v : tb) sum += v;
            float mean = (float) (sum / tb.length);
            float lift = clamp((mean - 0.07f) / 0.18f, 0.30f, 1.0f);

            final float[] gainLut = new float[LUT_N + 1];
            for (int k = 0; k <= LUT_N; k++) {
                float g = Math.max(k / (float) LUT_N, 0.03f);
                float gn = (float) Math.pow(g, -0.20);        // brighter by (g^0.8)/g
                gn = Math.min(gn, 1.75f);
                gainLut[k] = 1f + lift * (gn - 1f);
            }

            // ---- pass 1: tone map the luma into a second array ----
            final byte[] yt = new byte[wh];
            final int[] x0 = new int[w];
            final float[] fx = new float[w];
            for (int x = 0; x < w; x++) {
                float gx = (x + 0.5f) / GRID - 0.5f;
                int i0 = (int) Math.floor(gx);
                fx[x] = gx - i0;
                x0[x] = Math.max(0, Math.min(bw - 1, i0));
            }
            final float clarity = 0.30f;
            final float contrast = 0.30f;
            final float black = 0.010f;
            final int bands = Math.max(1, threads) * 3;
            runBands(pool, h, bands, (ya, yb) -> {
                for (int y = ya; y < yb; y++) {
                    float gy = (y + 0.5f) / GRID - 0.5f;
                    int j0 = (int) Math.floor(gy);
                    float fy = gy - j0;
                    int ja = Math.max(0, Math.min(bh - 1, j0));
                    int jb = Math.max(0, Math.min(bh - 1, j0 + 1));
                    int ra = ja * bw;
                    int rb = jb * bw;
                    int ro = y * w;
                    for (int x = 0; x < w; x++) {
                        int ia = x0[x];
                        int ib = Math.min(bw - 1, ia + 1);
                        float f = fx[x];
                        float local = lerp(lerp(b8[ra + ia], b8[ra + ib], f), lerp(b8[rb + ia], b8[rb + ib], f), fy);
                        float wide = lerp(lerp(tb[ra + ia], tb[ra + ib], f), lerp(tb[rb + ia], tb[rb + ib], f), fy);
                        float v = (nv[ro + x] & 0xFF) * (1f / 255f);
                        float gain = gainLut[(int) (clamp(wide, 0f, 1f) * LUT_N + 0.5f)];
                        float o = v * gain;
                        o += clarity * (v - local) * (4f * v * (1f - v));
                        if (o < 0f) o = 0f;
                        if (o > 0.92f) o = 0.92f + 0.08f * (1f - (float) Math.exp(-(o - 0.92f) * 12.5f));
                        if (o > 1f) o = 1f;
                        float s = o * o * (3f - 2f * o);
                        o += contrast * (s - o);
                        o = (o - black) / (1f - black);
                        if (o < 0f) o = 0f;
                        yt[ro + x] = (byte) (o * 255f + 0.5f);
                    }
                }
            });

            // ---- pass 2: colour, from the old and new brightness ----
            runBands(pool, h / 2, bands, (ca, cb) -> {
                for (int cy = ca; cy < cb; cy++) {
                    int r0 = cy * 2 * w;
                    int r1 = r0 + w;
                    int co = wh + cy * w;
                    for (int cx = 0; cx < w / 2; cx++) {
                        int p = cx * 2;
                        float yo = ((nv[r0 + p] & 0xFF) + (nv[r0 + p + 1] & 0xFF)
                                + (nv[r1 + p] & 0xFF) + (nv[r1 + p + 1] & 0xFF)) * 0.25f;
                        float yn = ((yt[r0 + p] & 0xFF) + (yt[r0 + p + 1] & 0xFF)
                                + (yt[r1 + p] & 0xFF) + (yt[r1 + p + 1] & 0xFF)) * 0.25f;
                        float ratio = (yn + 6f) / (yo + 6f);
                        float comp = (float) Math.sqrt(ratio);
                        comp = clamp(comp, 0.92f, 1.35f);
                        float v = (nv[co + p] & 0xFF) - 128f;
                        float u = (nv[co + p + 1] & 0xFF) - 128f;
                        float sat = (float) Math.sqrt(u * u + v * v);
                        float boost = 1.10f + 0.22f * (1f - Math.min(sat, 50f) / 50f);
                        // skin tones stay natural: only a quarter of the boost there
                        if (u > -58f && u < 2f && v > 3f && v < 52f) boost = 1f + (boost - 1f) * 0.25f;
                        float cf = boost * comp;
                        int nvv = Math.round(128f + v * cf);
                        int nu = Math.round(128f + u * cf);
                        nv[co + p] = (byte) (nvv < 0 ? 0 : (nvv > 255 ? 255 : nvv));
                        nv[co + p + 1] = (byte) (nu < 0 ? 0 : (nu > 255 ? 255 : nu));
                    }
                }
            });

            // ---- pass 3: sharpen the new luma back into the frame ----
            final float amount = 0.85f * sharp;
            runBands(pool, h, bands, (ya, yb) -> {
                for (int y = ya; y < yb; y++) {
                    int ym = Math.max(0, y - 1) * w;
                    int yc = y * w;
                    int yp = Math.min(h - 1, y + 1) * w;
                    for (int x = 0; x < w; x++) {
                        int xm = x == 0 ? 0 : x - 1;
                        int xp = x == w - 1 ? w - 1 : x + 1;
                        int c = yt[yc + x] & 0xFF;
                        int blurSum = 4 * c
                                + 2 * ((yt[yc + xm] & 0xFF) + (yt[yc + xp] & 0xFF) + (yt[ym + x] & 0xFF) + (yt[yp + x] & 0xFF))
                                + (yt[ym + xm] & 0xFF) + (yt[ym + xp] & 0xFF) + (yt[yp + xm] & 0xFF) + (yt[yp + xp] & 0xFF);
                        float d = c - blurSum * (1f / 16f);
                        float mag = Math.abs(d);
                        // fine grain stays untouched, real edges get crisper, halos are capped
                        float t = 2.2f;
                        float m = mag - t;
                        float out;
                        if (m <= 0f) {
                            out = c;
                        } else {
                            if (m > 26f) m = 26f;
                            out = c + amount * (d < 0 ? -m : m);
                        }
                        int oi = Math.round(out);
                        nv[yc + x] = (byte) (oi < 0 ? 0 : (oi > 255 ? 255 : oi));
                    }
                }
            });
        } finally {
            pool.shutdown();
        }
    }

    // ---------- helpers ----------

    private interface Band {
        void run(int from, int to);
    }

    private static void runBands(ExecutorService pool, int rows, int bands, Band job) {
        List<Future<?>> fs = new ArrayList<>();
        for (int i = 0; i < bands; i++) {
            final int a = rows * i / bands;
            final int b = rows * (i + 1) / bands;
            if (b <= a) continue;
            fs.add(pool.submit(() -> job.run(a, b)));
        }
        try {
            for (Future<?> f : fs) f.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void gridMean(byte[] nv, int w, int h, int bw, int bh, float[] out) {
        for (int j = 0; j < bh; j++) {
            int ys = j * GRID;
            int ye = Math.min(h, ys + GRID);
            for (int i = 0; i < bw; i++) {
                int xs = i * GRID;
                int xe = Math.min(w, xs + GRID);
                int sum = 0;
                for (int y = ys; y < ye; y++) {
                    int ro = y * w;
                    for (int x = xs; x < xe; x++) sum += nv[ro + x] & 0xFF;
                }
                out[j * bw + i] = sum / (float) ((ye - ys) * (xe - xs)) * (1f / 255f);
            }
        }
    }

    // box blur, `passes` times, with the edge value repeated
    private static void blur(float[] a, int w, int h, int radius, int passes) {
        float[] tmp = new float[a.length];
        for (int p = 0; p < passes; p++) {
            for (int y = 0; y < h; y++) {
                int ro = y * w;
                for (int x = 0; x < w; x++) {
                    float s = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int xx = x + k;
                        if (xx < 0) xx = 0; else if (xx >= w) xx = w - 1;
                        s += a[ro + xx];
                    }
                    tmp[ro + x] = s / (2 * radius + 1);
                }
            }
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    float s = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int yy = y + k;
                        if (yy < 0) yy = 0; else if (yy >= h) yy = h - 1;
                        s += tmp[yy * w + x];
                    }
                    a[y * w + x] = s / (2 * radius + 1);
                }
            }
        }
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
