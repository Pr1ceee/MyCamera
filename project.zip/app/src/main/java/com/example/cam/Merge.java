package com.example.cam;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Multi-frame merge of NV21 frames: every frame is aligned to the sharpest one tile by tile
 * (so hand shake, small rotation and perspective are followed, not just a global shift),
 * then all frames are averaged with a robust weight that throws away anything that moved.
 */
public final class Merge {
    private Merge() {}

    private static final int TILE = 32;     // tile size in full-resolution pixels
    private static final int BLOCK = 8;     // the per-pixel shift is looked up per 8x8 block

    /** noise (sd, in luma steps) of one frame of the last merge, measured between the frames themselves */
    public static volatile float lastFrameNoise = 0f;
    /** noise left in the merged frame: frame noise divided by the square root of the frames that really count */
    public static volatile float lastResidualNoise = 0f;
    /** noise sd of one frame in each pyramid band (luma, and colour), measured on a well aligned pair */
    public static volatile float[] lastBandSigmaY = null;
    public static volatile float[] lastBandSigmaC = null;

    /** @return the merged frame as a new NV21 array */
    public static byte[] merge(List<byte[]> frames, int w, int h, float noise, int threads) {
        return merge(frames, w, h, noise, threads, -1);
    }

    /** @param forceRef index of the reference frame, or -1 to take the sharpest */
    public static byte[] merge(List<byte[]> frames, int w, int h, float noise, int threads, int forceRef) {
        final int n = frames.size();
        if (n == 1) return frames.get(0).clone();
        final int wh = w * h;
        final byte[][] fr = frames.toArray(new byte[0][]);
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, threads));
        try {
            final int w1 = w / 2, h1 = h / 2, w2 = w1 / 2, h2 = h1 / 2, w3 = w2 / 2, h3 = h2 / 2;
            // luma pyramids
            final byte[][] l1 = new byte[n][];
            final byte[][] l2 = new byte[n][];
            final byte[][] l3 = new byte[n][];
            List<Future<?>> fs = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                final int fi = i;
                fs.add(pool.submit(() -> {
                    byte[] f = frames.get(fi);
                    l1[fi] = down(f, w, w1, h1, w);
                    l2[fi] = down(l1[fi], w1, w2, h2, w1);
                    l3[fi] = down(l2[fi], w2, w3, h3, w2);
                }));
            }
            get(fs);

            // reference = sharpest frame
            int ri = 0;
            long best = -1;
            for (int i = 0; i < n; i++) {
                long sh = sharpness(l3[i], w3, h3);
                if (sh > best) { best = sh; ri = i; }
            }
            final int ref = forceRef >= 0 && forceRef < n ? forceRef : ri;

            final int ntx = (w + TILE - 1) / TILE;
            final int nty = (h + TILE - 1) / TILE;
            final int[][] vx = new int[n][];
            final int[][] vy = new int[n][];
            final float[][] conf = new float[n][];   // how far each tile can be trusted, 0..1
            final float[] sigmaF = new float[n];

            for (int i = 0; i < n; i++) {
                vx[i] = new int[ntx * nty];
                vy[i] = new int[ntx * nty];
                conf[i] = new float[ntx * nty];
                if (i == ref) {
                    java.util.Arrays.fill(conf[i], 1f);
                    continue;
                }
                // global shift, coarse to fine
                int[] g3 = searchGlobal(l3[ref], l3[i], w3, h3, 0, 0, 6);
                int[] g2 = searchGlobal(l2[ref], l2[i], w2, h2, g3[0] * 2, g3[1] * 2, 3);
                int[] g1 = searchGlobal(l1[ref], l1[i], w1, h1, g2[0] * 2, g2[1] * 2, 3);
                final int gx1 = g1[0], gy1 = g1[1];
                // noise of a frame from its difference to the reference: robust against anything that moved
                final float sg = tempNoise(frames.get(ref), frames.get(i), w, h, gx1 * 2, gy1 * 2);
                sigmaF[i] = sg;
                // two aligned noisy pixels differ by about 1.13 sigma on average; leave room for sub-pixel error
                final float expect = Math.max(1.13f * sg, 3.0f);
                // tiles at half resolution (16 px) around the global shift, then at full resolution
                final byte[] rf = frames.get(ref);
                final byte[] ff = frames.get(i);
                final byte[] r1 = l1[ref];
                final byte[] f1 = l1[i];
                final int[] tvx = vx[i];
                final int[] tvy = vy[i];
                final float[] tcf = conf[i];
                runBands(pool, nty, threads * 3, (ta, tb) -> {
                    for (int ty = ta; ty < tb; ty++) {
                        for (int tx = 0; tx < ntx; tx++) {
                            int x0 = tx * TILE, y0 = ty * TILE;
                            int x1 = Math.min(w, x0 + TILE), y1 = Math.min(h, y0 + TILE);
                            // half resolution search: +-3 around the global shift
                            int hx0 = x0 / 2, hy0 = y0 / 2, hx1 = x1 / 2, hy1 = y1 / 2;
                            long bestS = Long.MAX_VALUE;
                            int bx = gx1, by = gy1;
                            for (int dy = -3; dy <= 3; dy++) {
                                for (int dx = -3; dx <= 3; dx++) {
                                    int cx = gx1 + dx, cy = gy1 + dy;
                                    long s = sad(r1, f1, w1, h1, hx0, hy0, hx1, hy1, cx, cy);
                                    // a small pull towards the global shift keeps flat tiles from wandering
                                    s += (Math.abs(dx) + Math.abs(dy)) * (long) ((hx1 - hx0) * (hy1 - hy0) * 0.02f);
                                    if (s < bestS) { bestS = s; bx = cx; by = cy; }
                                }
                            }
                            // full resolution: +-1 around twice the half resolution shift
                            long bestF = Long.MAX_VALUE;
                            int fx = bx * 2, fy = by * 2;
                            for (int dy = -1; dy <= 1; dy++) {
                                for (int dx = -1; dx <= 1; dx++) {
                                    int cx = bx * 2 + dx, cy = by * 2 + dy;
                                    long s = sad(rf, ff, w, h, x0, y0, x1, y1, cx, cy);
                                    if (s < bestF) { bestF = s; fx = cx; fy = cy; }
                                }
                            }
                            int t = ty * ntx + tx;
                            tvx[t] = fx;
                            tvy[t] = fy;
                            float per = bestF / (float) Math.max(1, (x1 - x0) * (y1 - y0));
                            // good alignment of two noisy frames gives per ~ 1.13 * sigma
                            float ratio = per / expect;
                            tcf[t] = ratio <= 1.35f ? 1f : (ratio >= 3.2f ? 0f : (3.2f - ratio) / 1.85f);
                        }
                    }
                });
            }

            // one noise figure for the burst (median over the frames) and what is left after merging
            float[] others = new float[n - 1];
            int oi = 0;
            for (int i = 0; i < n; i++) if (i != ref) others[oi++] = sigmaF[i];
            java.util.Arrays.sort(others);
            final float fnoise = Math.max(1f, others[others.length / 2]);
            double neff = 1;
            for (int i = 0; i < n; i++) {
                if (i == ref) continue;
                double c = 0;
                for (float v : conf[i]) c += v;
                neff += c / conf[i].length;
            }
            lastFrameNoise = fnoise;
            lastResidualNoise = (float) (fnoise / Math.sqrt(neff));

            // per 8x8 block shifts and trust, smoothly interpolated between tile centres
            final int nbx = (w + BLOCK - 1) / BLOCK;
            final int nby = (h + BLOCK - 1) / BLOCK;
            final short[][] bvx = new short[n][];
            final short[][] bvy = new short[n][];
            final byte[][] bcf = new byte[n][];
            for (int i = 0; i < n; i++) {
                bvx[i] = new short[nbx * nby];
                bvy[i] = new short[nbx * nby];
                bcf[i] = new byte[nbx * nby];
                for (int by = 0; by < nby; by++) {
                    float gy = (by * BLOCK + BLOCK / 2f) / TILE - 0.5f;
                    int ty0 = (int) Math.floor(gy);
                    float fy = gy - ty0;
                    int ta = clampi(ty0, 0, nty - 1), tb = clampi(ty0 + 1, 0, nty - 1);
                    for (int bx = 0; bx < nbx; bx++) {
                        float gx = (bx * BLOCK + BLOCK / 2f) / TILE - 0.5f;
                        int tx0 = (int) Math.floor(gx);
                        float fx = gx - tx0;
                        int ua = clampi(tx0, 0, ntx - 1), ub = clampi(tx0 + 1, 0, ntx - 1);
                        int a = ta * ntx + ua, b = ta * ntx + ub, c = tb * ntx + ua, d = tb * ntx + ub;
                        float x = bil(vx[i][a], vx[i][b], vx[i][c], vx[i][d], fx, fy);
                        float y = bil(vy[i][a], vy[i][b], vy[i][c], vy[i][d], fx, fy);
                        // the least trusted of the four tiles decides
                        float cf = Math.min(Math.min(conf[i][a], conf[i][b]), Math.min(conf[i][c], conf[i][d]));
                        int o = by * nbx + bx;
                        bvx[i][o] = (short) Math.round(x);
                        bvy[i][o] = (short) Math.round(y);
                        bcf[i][o] = (byte) Math.round(cf * 100f);
                    }
                }
            }

            // ---- noise spectrum of one frame, from the best aligned other frame (central crop) ----
            {
                int bi = -1;
                double bc = -1;
                for (int i = 0; i < n; i++) {
                    if (i == ref) continue;
                    double c = 0;
                    for (float v : conf[i]) c += v;
                    if (c > bc) { bc = c; bi = i; }
                }
                int cs = Math.min(1024, Math.min(w, h)) & ~3;
                int cx0 = ((w - cs) / 2) & ~1, cy0 = ((h - cs) / 2) & ~1;
                float[] pl = new float[cs * cs];
                final float r2 = (float) (1.0 / Math.sqrt(2.0));
                for (int y = 0; y < cs; y++) {
                    int yy = cy0 + y;
                    for (int x = 0; x < cs; x++) {
                        int xx = cx0 + x;
                        int bo = (yy / BLOCK) * nbx + xx / BLOCK;
                        int sx = clampi(xx + bvx[bi][bo], 0, w - 1);
                        int sy = clampi(yy + bvy[bi][bo], 0, h - 1);
                        pl[y * cs + x] = ((fr[ref][yy * w + xx] & 0xFF) - (fr[bi][sy * w + sx] & 0xFF)) * r2;
                    }
                }
                lastBandSigmaY = Pyr.bandNoise(pl, cs, cs);
                int cc = cs / 2;
                float[] pu = new float[cc * cc];
                float[] pv = new float[cc * cc];
                for (int y = 0; y < cc; y++) {
                    int yy = cy0 + y * 2;
                    for (int x = 0; x < cc; x++) {
                        int xx = cx0 + x * 2;
                        int bo = (yy / BLOCK) * nbx + xx / BLOCK;
                        int sx = clampi(xx + bvx[bi][bo], 0, w - 2) & ~1;
                        int sy = clampi(yy + bvy[bi][bo], 0, h - 2) & ~1;
                        int ro = wh + (yy >> 1) * w + (xx >> 1) * 2;
                        int fo = wh + (sy >> 1) * w + (sx >> 1) * 2;
                        pv[y * cc + x] = ((fr[ref][ro] & 0xFF) - (fr[bi][fo] & 0xFF)) * r2;
                        pu[y * cc + x] = ((fr[ref][ro + 1] & 0xFF) - (fr[bi][fo + 1] & 0xFF)) * r2;
                    }
                }
                float[] bu = Pyr.bandNoise(pu, cc, cc);
                float[] bv2 = Pyr.bandNoise(pv, cc, cc);
                float[] bcm = new float[Pyr.BANDS];
                for (int k = 0; k < Pyr.BANDS; k++) bcm[k] = 0.5f * (bu[k] + bv2[k]);
                lastBandSigmaC = bcm;
            }

            // ---- luma ----
            final byte[] out = new byte[wh * 3 / 2];
            final float sigma = Math.max(6f, 2.6f * fnoise);
            final float[] lut = new float[256];
            for (int d = 0; d < 256; d++) lut[d] = (float) Math.exp(-(d * d) / (2.0 * sigma * sigma));
            runBands(pool, h, threads * 3, (ya, yb) -> {
                final float[] vals = new float[n];
                final float[] cw = new float[n];
                for (int y = ya; y < yb; y++) {
                    int by = y / BLOCK;
                    for (int x = 0; x < w; x++) {
                        int bo = by * nbx + x / BLOCK;
                        float sumW = 0, sumV = 0;
                        for (int k = 0; k < n; k++) {
                            float c;
                            int v;
                            if (k == ref) {
                                c = 1f;
                                v = fr[k][y * w + x] & 0xFF;
                            } else {
                                c = bcf[k][bo] * 0.01f;
                                int sx = x + bvx[k][bo];
                                int sy = y + bvy[k][bo];
                                if (sx < 0) sx = 0; else if (sx >= w) sx = w - 1;
                                if (sy < 0) sy = 0; else if (sy >= h) sy = h - 1;
                                v = fr[k][sy * w + sx] & 0xFF;
                            }
                            vals[k] = v;
                            cw[k] = c;
                            sumW += c;
                            sumV += c * v;
                        }
                        float mean = sumV / sumW;
                        float fw = 0, fv = 0;
                        for (int k = 0; k < n; k++) {
                            float d = vals[k] - mean;
                            if (d < 0) d = -d;
                            float wt = cw[k] * lut[d > 255f ? 255 : (int) (d + 0.5f)];
                            fw += wt;
                            fv += wt * vals[k];
                        }
                        out[y * w + x] = (byte) (fw > 0 ? fv / fw + 0.5f : mean + 0.5f);
                    }
                }
            });

            // ---- colour: follows the merged luma, so noisy or moved frames lose their say ----
            final int cw2 = w / 2, ch2 = h / 2;
            final float csig = Math.max(7f, 3.0f * fnoise);
            runBands(pool, ch2, threads * 3, (ca, cb) -> {
                final float[] wt = new float[n];
                final int[] cu = new int[n];
                final int[] cv = new int[n];
                for (int cy = ca; cy < cb; cy++) {
                    int by = (cy * 2) / BLOCK;
                    for (int cx = 0; cx < cw2; cx++) {
                        int x = cx * 2, y = cy * 2;
                        int bo = by * nbx + x / BLOCK;
                        float sw = 0, su = 0, sv = 0;
                        int m00 = out[y * w + x] & 0xFF, m01 = out[y * w + x + 1] & 0xFF;
                        int m10 = out[(y + 1) * w + x] & 0xFF, m11 = out[(y + 1) * w + x + 1] & 0xFF;
                        for (int k = 0; k < n; k++) {
                            byte[] f = fr[k];
                            int dx = 0, dy = 0;
                            float c = 1f;
                            if (k != ref) {
                                dx = bvx[k][bo];
                                dy = bvy[k][bo];
                                c = bcf[k][bo] * 0.01f;
                            }
                            int sx = x + dx, sy = y + dy;
                            if (sx < 0) sx = 0; else if (sx > w - 2) sx = w - 2;
                            if (sy < 0) sy = 0; else if (sy > h - 2) sy = h - 2;
                            int d0 = (f[sy * w + sx] & 0xFF) - m00;
                            int d1 = (f[sy * w + sx + 1] & 0xFF) - m01;
                            int d2 = (f[(sy + 1) * w + sx] & 0xFF) - m10;
                            int d3 = (f[(sy + 1) * w + sx + 1] & 0xFF) - m11;
                            float dd = (d0 * d0 + d1 * d1 + d2 * d2 + d3 * d3) * 0.25f;
                            float wgt = c * (float) Math.exp(-dd / (2.0 * csig * csig));
                            int co = wh + (sy >> 1) * w + (sx >> 1) * 2;
                            sw += wgt;
                            sv += wgt * (f[co] & 0xFF);
                            su += wgt * (f[co + 1] & 0xFF);
                        }
                        int o = wh + cy * w + cx * 2;
                        if (sw > 1e-6f) {
                            out[o] = (byte) (sv / sw + 0.5f);
                            out[o + 1] = (byte) (su / sw + 0.5f);
                        } else {
                            byte[] f = frames.get(ref);
                            out[o] = f[o];
                            out[o + 1] = f[o + 1];
                        }
                    }
                }
            });
            return out;
        } finally {
            pool.shutdown();
        }
    }

    // ---------- helpers ----------

    // sd of one frame's noise from its difference to the aligned reference, sampled on a grid
    private static float tempNoise(byte[] r, byte[] f, int w, int h, int sx, int sy) {
        int[] hist = new int[256];
        long total = 0;
        int mx = Math.abs(sx) + 4, my = Math.abs(sy) + 4;
        for (int y = my; y < h - my; y += 3) {
            for (int x = mx; x < w - mx; x += 3) {
                int d = (r[y * w + x] & 0xFF) - (f[(y + sy) * w + x + sx] & 0xFF);
                hist[d < 0 ? -d : d]++;
                total++;
            }
        }
        if (total == 0) return 3f;
        // the 25th percentile of |a-b| is 0.3186 * sqrt(2) * sigma for independent noise, and it is
        // hardly moved by edges and texture that the two frames still disagree on
        long q = total / 4, acc = 0;
        int med = 0;
        for (int i = 0; i < 256; i++) {
            acc += hist[i];
            if (acc > q) { med = i; break; }
        }
        return Math.max(0.8f, (med + 0.5f) / 0.4506f);
    }

    private interface Band {
        void run(int from, int to);
    }

    private static void runBands(ExecutorService pool, int rows, int bands, Band job) {
        List<Future<?>> fs = new ArrayList<>();
        for (int i = 0; i < bands; i++) {
            final int a = rows * i / bands;
            final int b = rows * (i + 1) / bands;
            if (b <= a) continue;
            fs.add(pool.submit(() -> job.run(a, b)));
        }
        get(fs);
    }

    private static void get(List<Future<?>> fs) {
        try {
            for (Future<?> f : fs) f.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // 2x2 box downscale of a plane (stride = row stride of the source)
    private static byte[] down(byte[] src, int srcStride, int dw, int dh, int ignored) {
        byte[] d = new byte[dw * dh];
        for (int y = 0; y < dh; y++) {
            int r0 = y * 2 * srcStride;
            int r1 = r0 + srcStride;
            int o = y * dw;
            for (int x = 0; x < dw; x++) {
                int p = x * 2;
                d[o + x] = (byte) (((src[r0 + p] & 0xFF) + (src[r0 + p + 1] & 0xFF)
                        + (src[r1 + p] & 0xFF) + (src[r1 + p + 1] & 0xFF) + 2) >> 2);
            }
        }
        return d;
    }

    private static long sharpness(byte[] a, int w, int h) {
        long s = 0;
        for (int y = 1; y < h - 1; y += 2) {
            for (int x = 1; x < w - 1; x += 2) {
                int c = a[y * w + x] & 0xFF;
                int l = 4 * c - (a[y * w + x - 1] & 0xFF) - (a[y * w + x + 1] & 0xFF)
                        - (a[(y - 1) * w + x] & 0xFF) - (a[(y + 1) * w + x] & 0xFF);
                s += l < 0 ? -l : l;
            }
        }
        return s;
    }

    // best whole-image shift of f against r within +-range around (cx, cy), sampled on a grid
    private static int[] searchGlobal(byte[] r, byte[] f, int w, int h, int cx, int cy, int range) {
        long best = Long.MAX_VALUE;
        int bx = cx, by = cy;
        int m = range + Math.max(Math.abs(cx), Math.abs(cy)) + 2;
        int x0 = Math.max(m, w / 16), x1 = w - Math.max(m, w / 16);
        int y0 = Math.max(m, h / 16), y1 = h - Math.max(m, h / 16);
        if (x1 <= x0 || y1 <= y0) return new int[]{cx, cy};
        int step = Math.max(1, Math.min(w, h) / 160);
        for (int dy = -range; dy <= range; dy++) {
            for (int dx = -range; dx <= range; dx++) {
                int sx = cx + dx, sy = cy + dy;
                long s = 0;
                for (int y = y0; y < y1; y += step) {
                    int ro = y * w;
                    int fo = (y + sy) * w + sx;
                    if (y + sy < 0 || y + sy >= h) continue;
                    for (int x = x0; x < x1; x += step) {
                        if (x + sx < 0 || x + sx >= w) continue;
                        int d = (r[ro + x] & 0xFF) - (f[fo + x] & 0xFF);
                        s += d < 0 ? -d : d;
                    }
                }
                if (s < best) { best = s; bx = sx; by = sy; }
            }
        }
        return new int[]{bx, by};
    }

    // sum of absolute differences of a tile of r against f shifted by (sx, sy), edges clamped
    private static long sad(byte[] r, byte[] f, int w, int h, int x0, int y0, int x1, int y1, int sx, int sy) {
        long s = 0;
        for (int y = y0; y < y1; y++) {
            int yy = y + sy;
            if (yy < 0) yy = 0; else if (yy >= h) yy = h - 1;
            int ro = y * w;
            int fo = yy * w;
            for (int x = x0; x < x1; x++) {
                int xx = x + sx;
                if (xx < 0) xx = 0; else if (xx >= w) xx = w - 1;
                int d = (r[ro + x] & 0xFF) - (f[fo + xx] & 0xFF);
                s += d < 0 ? -d : d;
            }
        }
        return s;
    }

    private static float bil(float a, float b, float c, float d, float fx, float fy) {
        return (a + (b - a) * fx) * (1f - fy) + (c + (d - c) * fx) * fy;
    }

    private static int clampi(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
