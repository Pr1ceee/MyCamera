package com.example.cam

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.hypot

class MainActivity : Activity() {

    data class Lens(
        val label: String,
        val logicalId: String,
        val physicalId: String?,
        val chars: CameraCharacteristics
    )

    private lateinit var mgr: CameraManager
    private lateinit var texture: TextureView
    private lateinit var recBtn: Button
    private lateinit var stabBtn: Button
    private val lensButtons = mutableListOf<Button>()
    private var lenses = listOf<Lens>()
    private var cur: Lens? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var opening = false
    private var previewSurface: Surface? = null
    private var reader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recording = false
    private var stab = 1 // 0 off, 1 standard (OIS+EIS), 2 preview stabilization
    private var videoSize = Size(1920, 1080)
    private var photoSize = Size(1920, 1080)
    private val thread = HandlerThread("cam").also { it.start() }
    private val bg = Handler(thread.looper)
    private val stabNames = arrayOf("Stab: Off", "Stab: Standard", "Stab: Preview")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        mgr = getSystemService(CAMERA_SERVICE) as CameraManager
        val dp = resources.displayMetrics.density

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        texture = TextureView(this)
        root.addView(texture, FrameLayout.LayoutParams(-1, -1))

        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val w = r - l
            val h = b - t
            if (w > 0 && h > 0) {
                var tw = w
                var th = w * 16 / 9
                if (th > h) { th = h; tw = h * 9 / 16 }
                val lp = texture.layoutParams as FrameLayout.LayoutParams
                if (lp.width != tw || lp.height != th) {
                    lp.width = tw
                    lp.height = th
                    lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    texture.layoutParams = lp
                }
            }
        }

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER_HORIZONTAL
        panel.setBackgroundColor(Color.parseColor("#88000000"))
        val pad = (12 * dp).toInt()
        panel.setPadding(pad, pad, pad, pad * 2)

        val lensRow = LinearLayout(this)
        lensRow.orientation = LinearLayout.HORIZONTAL
        lensRow.gravity = Gravity.CENTER
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.gravity = Gravity.CENTER

        lenses = try { discover() } catch (e: Exception) { emptyList() }
        cur = lenses.firstOrNull { it.label == "1.0x" } ?: lenses.firstOrNull()
        if (lenses.isEmpty()) toast("No back cameras found")
        for (l in lenses) {
            val btn = Button(this)
            btn.text = l.label
            btn.setOnClickListener {
                if (!recording) {
                    cur = l
                    refreshButtons()
                    closeCamera()
                    tryOpen()
                }
            }
            lensButtons.add(btn)
            lensRow.addView(btn)
        }
        refreshButtons()

        stabBtn = Button(this)
        stabBtn.text = stabNames[stab]
        stabBtn.setOnClickListener {
            if (!recording) {
                stab = (stab + 1) % 3
                stabBtn.text = stabNames[stab]
                startPreview()
            }
        }
        val photoBtn = Button(this)
        photoBtn.text = "Photo"
        photoBtn.setOnClickListener { if (!recording) takePhoto() }
        recBtn = Button(this)
        recBtn.text = "Record"
        recBtn.setOnClickListener { if (recording) stopRecording(true) else startRecording() }
        row2.addView(stabBtn)
        row2.addView(photoBtn)
        row2.addView(recBtn)

        panel.addView(lensRow)
        panel.addView(row2)
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { tryOpen() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }

        if (!hasPerms()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasPerms()) tryOpen() else toast("Camera and microphone permissions are required")
    }

    override fun onResume() {
        super.onResume()
        tryOpen()
    }

    override fun onPause() {
        if (recording) stopRecording(false)
        closeCamera()
        super.onPause()
    }

    private fun hasPerms() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    private fun refreshButtons() {
        lensButtons.forEachIndexed { i, b -> b.alpha = if (lenses[i] == cur) 1f else 0.5f }
    }

    // ---------- lens discovery ----------

    private fun equiv(c: CameraCharacteristics): Double? {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return null
        val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        return f * 43.27 / hypot(s.width.toDouble(), s.height.toDouble())
    }

    private fun compat(c: CameraCharacteristics) =
        c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) == true

    private fun discover(): List<Lens> {
        val ids = mgr.cameraIdList.toSet()
        val found = mutableListOf<Triple<String, String?, CameraCharacteristics>>()
        for (id in ids) {
            val c = mgr.getCameraCharacteristics(id)
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
            found.add(Triple(id, null, c))
            for (pid in c.physicalCameraIds) {
                if (pid !in ids) found.add(Triple(id, pid, mgr.getCameraCharacteristics(pid)))
            }
        }
        val ok = found.filter { equiv(it.third) != null && compat(it.third) }
        if (ok.isEmpty()) return emptyList()
        val main = ok.minByOrNull { abs(equiv(it.third)!! - 24.0) }!!
        val mainEq = equiv(main.third)!!
        val out = LinkedHashMap<String, Lens>()
        for (t in ok.sortedBy { equiv(it.third)!! }) {
            val label = String.format(Locale.US, "%.1fx", equiv(t.third)!! / mainEq)
            if (label !in out) out[label] = Lens(label, t.first, t.second, t.third)
        }
        return out.values.toList()
    }

    private fun pickSizes(l: Lens) {
        val map = l.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return
        val vids = map.getOutputSizes(MediaRecorder::class.java)
        if (vids != null && vids.isNotEmpty()) {
            videoSize = vids.filter { it.width * 9 == it.height * 16 && it.width <= 1920 }
                .maxByOrNull { it.width } ?: vids.maxByOrNull { it.width * it.height }!!
        }
        val jpgs = map.getOutputSizes(ImageFormat.JPEG)
        if (jpgs != null && jpgs.isNotEmpty()) {
            photoSize = jpgs.filter { it.width * 9 == it.height * 16 }
                .maxByOrNull { it.width * it.height } ?: jpgs.maxByOrNull { it.width * it.height }!!
        }
    }

    // ---------- camera lifecycle ----------

    private fun tryOpen() {
        val l = cur ?: return
        if (!hasPerms() || !texture.isAvailable || device != null || opening) return
        pickSizes(l)
        opening = true
        try {
            mgr.openCamera(l.logicalId, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { opening = false; device = d; startPreview() }
                override fun onDisconnected(d: CameraDevice) { opening = false; d.close(); device = null }
                override fun onError(d: CameraDevice, e: Int) {
                    opening = false; d.close(); device = null; toast("Camera error $e")
                }
            }, bg)
        } catch (e: Exception) {
            opening = false
            toast("Open failed: ${e.message}")
        }
    }

    private fun closeCamera() {
        try { session?.close() } catch (e: Exception) {}
        session = null
        try { device?.close() } catch (e: Exception) {}
        device = null
        try { reader?.close() } catch (e: Exception) {}
        reader = null
    }

    private fun applyStab(b: CaptureRequest.Builder) {
        val l = cur ?: return
        val lc = mgr.getCameraCharacteristics(l.logicalId)
        val ois = lc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        val oisOn = stab != 0 && ois?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        b.set(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            if (oisOn) CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON
            else CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_OFF
        )
        val modes = lc.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf(0)
        val m = when (stab) {
            2 -> if (modes.contains(2)) 2 else if (modes.contains(1)) 1 else 0
            1 -> if (modes.contains(1)) 1 else 0
            else -> 0
        }
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, m)
    }

    private fun makeSession(
        d: CameraDevice,
        outputs: List<Surface>,
        targets: List<Surface>,
        template: Int,
        onReady: () -> Unit
    ) {
        try { session?.close() } catch (e: Exception) {}
        session = null
        val phys = cur?.physicalId
        val outs = outputs.map { s ->
            OutputConfiguration(s).also { if (phys != null) it.setPhysicalCameraId(phys) }
        }
        val req = d.createCaptureRequest(template)
        targets.forEach { req.addTarget(it) }
        req.set(
            CaptureRequest.CONTROL_AF_MODE,
            if (template == CameraDevice.TEMPLATE_RECORD) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
            else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
        )
        applyStab(req)
        val cfg = SessionConfiguration(
            SessionConfiguration.SESSION_REGULAR,
            outs,
            Executor { r -> bg.post(r) },
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        s.setRepeatingRequest(req.build(), null, bg)
                        onReady()
                    } catch (e: Exception) {
                        toast("Preview failed: ${e.message}")
                    }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    toast("Session failed. Try a different Stab setting.")
                }
            }
        )
        cfg.sessionParameters = req.build()
        try {
            d.createCaptureSession(cfg)
        } catch (e: Exception) {
            toast("Session error: ${e.message}")
        }
    }

    private fun startPreview() {
        val d = device ?: return
        val st = texture.surfaceTexture ?: return
        st.setDefaultBufferSize(videoSize.width, videoSize.height)
        previewSurface?.release()
        val ps = Surface(st)
        previewSurface = ps
        try { reader?.close() } catch (e: Exception) {}
        val r = ImageReader.newInstance(photoSize.width, photoSize.height, ImageFormat.JPEG, 2)
        reader = r
        makeSession(d, listOf(ps, r.surface), listOf(ps), CameraDevice.TEMPLATE_PREVIEW) {}
    }

    // ---------- photo ----------

    private fun sensorOri() = cur?.chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

    private fun takePhoto() {
        val d = device ?: return
        val s = session ?: return
        val r = reader ?: return
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage()
            if (img != null) {
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    savePhoto(bytes)
                } finally {
                    img.close()
                }
            }
        }, bg)
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(r.surface)
            b.set(CaptureRequest.JPEG_ORIENTATION, sensorOri())
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            s.capture(b.build(), null, bg)
        } catch (e: Exception) {
            toast("Capture failed: ${e.message}")
        }
    }

    private fun savePhoto(bytes: ByteArray) {
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MyCam")
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) { toast("Could not save photo"); return }
        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        toast("Photo saved")
    }

    // ---------- video ----------

    private fun startRecording() {
        val d = device ?: return
        val ps = previewSurface ?: return
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/MyCam")
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        val pfd = if (uri != null) contentResolver.openFileDescriptor(uri, "w") else null
        if (pfd == null) { toast("Could not create video file"); return }
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setOutputFile(pfd.fileDescriptor)
            r.setVideoEncodingBitRate(16_000_000)
            r.setVideoFrameRate(30)
            r.setVideoSize(videoSize.width, videoSize.height)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOrientationHint(sensorOri())
            r.prepare()
        } catch (e: Exception) {
            toast("Recorder error: ${e.message}")
            r.release()
            pfd.close()
            return
        }
        recorder = r
        recPfd = pfd
        makeSession(d, listOf(ps, r.surface), listOf(ps, r.surface), CameraDevice.TEMPLATE_RECORD) {
            runOnUiThread {
                try {
                    r.start()
                    recording = true
                    recBtn.text = "Stop"
                } catch (e: Exception) {
                    toast("Start failed: ${e.message}")
                }
            }
        }
    }

    private fun stopRecording(restart: Boolean) {
        try { session?.stopRepeating() } catch (e: Exception) {}
        try { session?.abortCaptures() } catch (e: Exception) {}
        try { recorder?.stop(); toast("Video saved") } catch (e: RuntimeException) { toast("Recording too short") }
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recording = false
        recBtn.text = "Record"
        if (restart) startPreview()
    }
}
