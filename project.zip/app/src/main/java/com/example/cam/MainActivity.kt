package com.example.cam

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.YuvImage
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraExtensionSession
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.ExtensionSessionConfiguration
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ExifInterface
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Choreographer
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.Future
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.math.sin

class MainActivity : Activity() {

    class Lens(val logicalId: String, val physicalId: String?, val chars: CameraCharacteristics)
    class VidOpt(
        val w: Int, val h: Int, val fps: Int, val bitrate: Int,
        val label: String, val short: String, val ok: Boolean
    )

    private val accent = Color.parseColor("#FFD60A")
    private val ios = PathInterpolator(0.22f, 1f, 0.36f, 1f)

    // camera state
    private lateinit var mgr: CameraManager
    private val lcCache = HashMap<String, CameraCharacteristics>()
    private var mainLens: Lens? = null
    private var ultraLens: Lens? = null
    private var frontLens: Lens? = null
    private var frontUltra: Lens? = null
    private var frontWideFactor = 0.8f
    private var frontNativeScale = 1f
    private var gridOn = false
    private var levelOn = false
    private var crossOn = false
    private var resumed = false
    private var devRot = 0 // phone turned this many degrees clockwise: 0, 90, 180 or 270
    private var uiAngle = 0f // angle the turning parts of the UI currently have (counter-rotation)
    private var flipSpin = 0f
    private var hostScale = 1f
    @Volatile private var selfieRot = 0
    private var procOn = false
    private var halBoost = false          // experiment: ask the phone's own multi-frame / HDR engine through its vendor settings
    @Volatile private var lastHalSet = ""
    @Volatile private var lastHalResult = ""
    private val pendingJobs = java.util.concurrent.atomic.AtomicInteger(0)
    private val packPool = Executors.newSingleThreadExecutor()
    private var xExt = -1                 // the phone's own HDR / Night processing: -1 off, else the extension id
    private var extSession: CameraExtensionSession? = null
    private val extCache = HashMap<String, List<Int>>()
    private lateinit var tileX: MenuTile
    private var yuvMode = false
    private var yuvSize = Size(0, 0)
    @Volatile private var processing = false
    @Volatile private var lastIso = 0
    @Volatile private var lastExpNs = 0L
    private val procPool = Executors.newSingleThreadExecutor()
    @Volatile private var lastFrames = 0
    @Volatile private var lastMergeMs = 0L
    @Volatile private var lastTotalMs = 0L
    @Volatile private var lastLookMs = 0L
    @Volatile private var lastNoise = 0f
    private val deferredReaders = ArrayList<ImageReader>()
    private lateinit var procSeg: SegControl
    private lateinit var procTv: TextView
    private lateinit var menuGrid: TileGrid
    private lateinit var tileRatio: MenuTile
    private lateinit var tilePhoto: MenuTile
    private lateinit var tileProc: MenuTile
    private lateinit var tileVideo: MenuTile
    private lateinit var tileStab: MenuTile
    private lateinit var tileHdr: MenuTile
    private lateinit var tileGridLines: MenuTile
    private lateinit var tileMirror: MenuTile
    private lateinit var tileLevel: MenuTile
    private lateinit var tileCross: MenuTile
    private lateinit var tileInfo: MenuTile
    private lateinit var detail: LinearLayout
    private lateinit var detailTitle: TextView
    private lateinit var detailBody: FrameLayout
    private var detailKey = ""
    private var levelRunning = false
    private lateinit var levelOverlay: LevelOverlay
    private lateinit var levelSeg: SegControl
    private lateinit var crossSeg: SegControl
    private val levelListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            levelOverlay.update(e.values[0], e.values[1], e.values[2])
        }
        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
    }
    private var hiddenInfo = listOf<String>()
    private var cur: Lens? = null
    private var front = false
    private var hiddenIds = listOf<String>()
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var opening = false
    private var configuring = false
    private var failCount = 0
    private var lastFailAt = 0L
    private var awaitFirstFrame = false
    @Volatile private var selfieRef: Bitmap? = null
    @Volatile private var selfieShot = false
    private var openRetries = 0
    private var sessionGen = 0
    private var staleReader: ImageReader? = null
    private var fpsProbing = false
    private var fpsCount = 0
    private var fpsFirstTs = 0L
    private var fps60Off = false
    private var photoOpts: List<Size> = emptyList()
    private var photoIdx = 0
    private var photoPrefMp = 12
    private val prefs by lazy { getSharedPreferences("mycam", MODE_PRIVATE) }
    private var pillAnim: ValueAnimator? = null
    private val glassViews = mutableListOf<View>()

    // A blurred RenderNode is cached as an offscreen layer and only redrawn when its content is
    // re-recorded, so the glass panels would keep showing the frame from when they were first
    // drawn. Invalidating them about 30 times a second keeps the blur live.
    private var glassPhase = false
    private val glassPump = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            glassPhase = !glassPhase
            if (glassPhase) {
                for (v in glassViews) if (v.visibility == View.VISIBLE && v.alpha > 0.01f) v.invalidate()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private var dialActive = false
    private var dialLastX = Float.NaN
    private val hideDial = Runnable {
        zoomDial.animate().alpha(0f).translationYBy(dp(20).toFloat()).setDuration(240).setInterpolator(ios)
            .withEndAction { if (!dialActive) zoomDial.visibility = View.GONE }.start()
        if (sheet.tag != true) zoomRow.animate().alpha(1f).setDuration(280).start()
    }
    private var pillBase = 0f
    private var pillSlide = 0f
    private var slideAnim: ValueAnimator? = null
    private var lensSwitching = false
    private var snapNear = false
    private var mirrorFront = true
    private var previewSurface: Surface? = null
    private var reader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recording = false
    private var recStart = 0L
    private var videoUri: Uri? = null
    private var lastUri: Uri? = null
    private var curTemplate = CameraDevice.TEMPLATE_PREVIEW
    private var curTargets: List<Surface> = emptyList()
    private val thread = HandlerThread("cam").also { it.start() }
    private val bg = Handler(thread.looper)
    private val ui = Handler(Looper.getMainLooper())

    // settings state
    private var mode = 0 // 0 photo, 1 video, 2 pro
    private var flashMode = 0 // photo: 0 off, 1 auto, 2 on, 3 torch (rear camera). The front camera lights the screen instead.
    private var torch = false // video
    private var timerSec = 0
    private var hdr = false
    private var ratio43 = true
    private var vidIdx = 0
    private var vidLabel = "1080p 30"
    private var vidOpts: List<VidOpt> = emptyList()
    private val stabNames = arrayOf("Off", "Optical", "Standard", "Preview")
    private var stab = 2 // 0 off, 1 optical, 2 standard (optical + electronic), 3 preview stabilization
    private val stabCap = HashMap<String, Int>()
    private var ev = 0
    private var evStep = 0f
    private var evAccum = 0f
    private var zoom = 1f
    private var tapRegion: MeteringRectangle? = null
    private var isoProg = 0
    private var shutProg = 0
    private var focusProg = 0
    private var hasFlash = false
    private var hdrSupported = false
    private var counting = false
    private var focusActive = false
    private var fx = 0f
    private var fy = 0f
    private var previewSize = Size(1920, 1080)
    private var photoSize = Size(1920, 1080)
    private var zoomAnim: ValueAnimator? = null
    private var stageAnim: ValueAnimator? = null
    private var blurNow = 0f
    private var blurAnim: ValueAnimator? = null

    // ui
    private lateinit var stage: FrameLayout
    private lateinit var rootView: FrameLayout
    private lateinit var panelView: LinearLayout
    private lateinit var texture: TextureView
    private lateinit var grid: CamGrid
    private lateinit var flashOverlay: View
    private lateinit var focusBox: View
    private lateinit var focusLine: View
    private lateinit var sunIcon: CamIcon
    private lateinit var countdownTv: TextView
    private lateinit var recTv: TextView
    private lateinit var topBar: FrameLayout
    private lateinit var topScrim: View
    private lateinit var flashIcon: CamIcon
    private lateinit var timerIcon: CamIcon
    private lateinit var chevron: CamIcon
    private lateinit var sheetHost: LinearLayout
    private lateinit var sheet: LinearLayout
    private lateinit var proSheet: LinearLayout
    private lateinit var zoomRow: LinearLayout
    private lateinit var zoomGlass: GlassLinear
    private lateinit var zoomDial: ZoomDial
    private lateinit var modeBar: FrameLayout
    private lateinit var modeRow: LinearLayout
    private lateinit var shutter: CamShutter
    private lateinit var thumb: ImageView
    private lateinit var thumbCell: FrameLayout
    private lateinit var flipCell: FrameLayout
    private lateinit var flipBtn: View
    private val tabBg = HashMap<Int, GradientDrawable>()
    private val pinKeys = ArrayList<String>()          // up to two controls pinned to the top row
    private val pinBtns = ArrayList<Pair<String, TileIcon>>()
    private val pinApplies = HashMap<String, Boolean>()   // does the control make sense in this mode (pinned or not)
    private val pinViews = ArrayList<View>()
    private lateinit var pinHost1: FrameLayout
    private lateinit var pinHost2: FrameLayout
    @Volatile private var nr3dUsed = false
    private var nr3dOff = false
    private val reqKeyCache = HashMap<String, Set<String>>()
    private var proSel = 0                 // Pro panel: 0 ISO, 1 shutter, 2 white balance, 3 focus
    private var wbIdx = 0                  // 0 = auto
    private var isoVal = 0                 // the exact ISO / shutter time picked on the ruler
    private var expVal = 0L
    private var peakOn = false
    private lateinit var proDial: DialRuler
    private lateinit var peaking: PeakingView
    private lateinit var peakChip: TextView
    private lateinit var wbLabel: TextView
    private val proCells = ArrayList<LinearLayout>()
    private val proCaps = ArrayList<TextView>()
    private val proBg = ArrayList<GradientDrawable>()
    private lateinit var flashSlot: View
    private lateinit var screenLight: View
    private var screenFlashOn = false
    private val wbNames = listOf("Auto", "Tungsten", "Fluor.", "Daylight", "Cloudy", "Shade")
    private val wbModes = intArrayOf(
        CaptureRequest.CONTROL_AWB_MODE_AUTO,
        CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
        CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,
        CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
        CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
        CaptureRequest.CONTROL_AWB_MODE_SHADE
    )
    private val isoStd = intArrayOf(50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400)
    private val shutStd = longArrayOf(
        125_000L, 250_000L, 500_000L, 1_000_000L, 2_000_000L, 4_000_000L, 8_000_000L,
        16_666_667L, 33_333_333L, 66_666_667L, 125_000_000L, 250_000_000L, 500_000_000L
    )
    private lateinit var ratioSeg: SegControl
    private lateinit var vidSeg: SegControl
    private lateinit var photoSeg: SegControl
    private lateinit var mirrorSeg: SegControl
    private lateinit var stabSeg: SegControl
    private lateinit var hdrSeg: SegControl
    private lateinit var gridSeg: SegControl
    private lateinit var evSeek: SeekBar
    private lateinit var evLabel: TextView
    private lateinit var evRow: LinearLayout
    private lateinit var isoSeek: SeekBar
    private lateinit var shutSeek: SeekBar
    private lateinit var focusSeek: SeekBar
    private lateinit var isoLabel: TextView
    private lateinit var shutLabel: TextView
    private lateinit var focusLabel: TextView
    private val tabs = HashMap<Int, TextView>()
    private val zoomChips = mutableListOf<Pair<TextView, Float>>()
    private val modeOrder = listOf(1, 0, 2) // display order: VIDEO, PHOTO, PRO

    private val fadeInSafety = Runnable { fadeInStage() }
    private val hideFocus = Runnable {
        focusActive = false
        for (v in listOf<View>(focusBox, focusLine, sunIcon)) {
            v.animate().alpha(0f).setDuration(250).withEndAction {
                if (!focusActive) v.visibility = View.GONE
            }.start()
        }
    }
    private val recTick = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000
            recTv.text = String.format(Locale.US, "\u25CF %02d:%02d", s / 60, s % 60)
            ui.postDelayed(this, 500)
        }
    }

    // ================= lifecycle =================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        mgr = getSystemService(CAMERA_SERVICE) as CameraManager
        fps60Off = prefs.getBoolean("fps60_off", false)
        mirrorFront = prefs.getBoolean("mirror_front", true)
        stab = prefs.getInt("stab", 2).coerceIn(0, 3)
        nr3dOff = prefs.getBoolean("nr3d_off", false)
        hdr = prefs.getBoolean("hdr_on", false)
        ratio43 = prefs.getBoolean("ratio43", true)
        gridOn = prefs.getBoolean("grid_on", false)
        levelOn = prefs.getBoolean("level_on", false)
        crossOn = prefs.getBoolean("cross_on", false)
        procOn = prefs.getBoolean("proc_on", false)
        halBoost = prefs.getBoolean("hal_boost", false)
        xExt = prefs.getInt("x_ext", -1)
        vidLabel = prefs.getString("vid_label", vidLabel) ?: vidLabel
        photoPrefMp = prefs.getInt("photo_mp", photoPrefMp)
        try { setupLenses() } catch (e: Exception) { toast("Camera setup failed: ${e.message}") }
        computeFrontScale()
        cur = mainLens
        buildUi()
        refreshCaps()
        buildZoomChips()
        refreshModeUi(false)
        if (!hasPerms()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasPerms()) tryOpen() else toast("Camera and microphone permissions are required")
    }

    override fun onResume() {
        super.onResume()
        // coming back from the gallery: reveal the viewfinder once the first frame arrives
        if (device == null && hasPerms()) fadeOutStage()
        tryOpen()
        loadLatestThumb()
        resumed = true
        applyLevel()
        if (orientationListener.canDetectOrientation()) orientationListener.enable()
        Choreographer.getInstance().removeFrameCallback(glassPump)
        Choreographer.getInstance().postFrameCallback(glassPump)
    }

    // the thumbnail shows the newest photo or video, also after restarting the app
    private fun loadLatestThumb() {
        bg.post {
            val u = GalleryView.latestUri(this)
            if (u != null && u != lastUri) setThumb(u)
        }
    }

    // ---------------- landscape ----------------
    // The screen stays portrait. Icons, text, pills and the menu turn in place to follow how the
    // phone is held, and saved photos / videos get the matching orientation.
    private val orientationListener by lazy {
        object : OrientationEventListener(this) {
            override fun onOrientationChanged(o: Int) {
                onDeviceOrientation(o)
            }
        }
    }

    private fun onDeviceOrientation(o: Int) {
        if (o == OrientationEventListener.ORIENTATION_UNKNOWN) return
        var diff = o - devRot
        while (diff > 180) diff -= 360
        while (diff < -180) diff += 360
        if (abs(diff) < 55) return // only switch once clearly past the halfway mark
        val nr = ((o + 45) / 90 * 90) % 360
        if (nr == devRot) return
        devRot = nr
        runOnUiThread { applyUiRotation(true) }
    }

    private fun chevronAngle() = uiAngle + (if (sheet.tag == true) 180f else 0f)

    private fun applyUiRotation(animate: Boolean) {
        val target = -devRot.toFloat()
        var delta = (target - uiAngle) % 360f
        if (delta > 180f) delta -= 360f
        if (delta < -180f) delta += 360f
        uiAngle += delta // always the short way round
        val dur = if (animate) 320L else 0L
        val views = ArrayList<View>()
        views.add(flashIcon)
        views.add(timerIcon)
        views.addAll(pinViews)
        views.add(recTv)
        views.add(procTv)
        views.add(countdownTv)
        views.addAll(tabs.values)
        for (p in zoomChips) views.add(p.first)
        for (v in views) v.animate().rotation(uiAngle).setDuration(dur).setInterpolator(ios).start()
        flipBtn.animate().rotation(uiAngle + flipSpin).setDuration(dur).setInterpolator(ios).start()
        chevron.animate().rotation(chevronAngle()).setDuration(dur).setInterpolator(ios).start()
        zoomDial.textRot = uiAngle
        applyMirror()
        layoutSheetForRotation(animate)
    }

    // the whole menu turns as one piece; sideways it is scaled to fit and lifted so it stays above the controls
    private fun layoutSheetForRotation(animate: Boolean) {
        val sideways = devRot == 90 || devRot == 270
        val w = sheetHost.width.toFloat()
        val h = sheetHost.height.toFloat()
        var sc = 1f
        var shift = 0f
        if (sideways && w > 0f && h > 0f) {
            sc = min(1f, (resources.displayMetrics.widthPixels - dp(16)) / h)
            shift = -(w * sc - h) / 2f
        }
        hostScale = sc
        val dur = if (animate) 320L else 0L
        sheetHost.animate().rotation(uiAngle).scaleX(sc).scaleY(sc).translationY(shift)
            .setDuration(dur).setInterpolator(ios).start()
    }

    // the mirror image flips left-right as the user sees it: that is the screen's other axis when sideways
    private fun applyMirror() {
        val m = front && mirrorFront
        val sideways = devRot == 90 || devRot == 270
        texture.scaleX = if (m && !sideways) -1f else 1f
        texture.scaleY = if (m && sideways) -1f else 1f
    }

    // clockwise rotation the saved picture / video needs to be upright the way the phone is held
    private fun jpegOrientation(): Int {
        val sensor = sensorOri()
        return if (front) (sensor - devRot + 360) % 360 else (sensor + devRot) % 360
    }

    // shows or hides the level aids and runs the tilt sensor only while they are needed
    private fun applyLevel() {
        levelOverlay.showBar = levelOn
        levelOverlay.showCross = crossOn
        levelOverlay.visibility = if (levelOn || crossOn) View.VISIBLE else View.GONE
        levelOverlay.invalidate()
        if ((levelOn || crossOn) && resumed) startLevel() else stopLevel()
    }

    private fun startLevel() {
        if (levelRunning) return
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (sensor == null) {
            toast("This phone has no tilt sensor")
            return
        }
        sm.registerListener(levelListener, sensor, SensorManager.SENSOR_DELAY_GAME)
        levelRunning = true
    }

    private fun stopLevel() {
        if (!levelRunning) return
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(levelListener)
        levelRunning = false
    }

    override fun onPause() {
        resumed = false
        orientationListener.disable()
        stopLevel()
        Choreographer.getInstance().removeFrameCallback(glassPump)
        if (dialActive) {
            dialActive = false
            zoomGlass.dialMode = false
        }
        ui.removeCallbacks(hideDial)
        zoomDial.visibility = View.GONE
        zoomRow.alpha = if (sheet.tag == true) 0f else 1f
        counting = false
        countdownTv.visibility = View.GONE
        if (recording) stopRecording(false)
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        procPool.shutdown()
        thread.quitSafely()
        super.onDestroy()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if ((event?.repeatCount ?: 0) == 0) shutterPressed()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun hasPerms() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun haptic(type: Int) { window.decorView.performHapticFeedback(type) }

    // ================= camera discovery =================

    private fun lcOf(id: String): CameraCharacteristics = lcCache.getOrPut(id) { mgr.getCameraCharacteristics(id) }

    private fun zoomRangeOf(l: Lens): Range<Float> =
        lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) ?: Range(1f, 1f)

    private fun equiv(c: CameraCharacteristics): Double? {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return null
        val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        return f * 43.27 / hypot(s.width.toDouble(), s.height.toDouble())
    }

    private fun compat(c: CameraCharacteristics) =
        c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) == true

    // the main and the wider lens of the camera currently in use (rear or front)
    private fun baseLens(): Lens? = if (front) frontLens else mainLens
    private fun wideLens(): Lens? = if (front) frontUltra else ultraLens
    private fun wideFactor(): Float = if (front) frontWideFactor else 0.6f

    // zoom shown on the buttons = real zoom x this (1 for the rear camera)
    private fun nativeScale(): Float = if (front) frontNativeScale else 1f

    // The front camera's own view (21.6 mm equivalent) is already wider than the rear 1x (26.2 mm).
    // On the 1x scale that is 0.8x, which is what the stock app calls the 0.8x selfie camera;
    // its 1x is a 1.25x crop of this view.
    private fun computeFrontScale() {
        frontNativeScale = 1f
        if (frontUltra != null) return
        val fl = frontLens ?: return
        val fe = equiv(fl.chars) ?: return
        val ref = mainLens?.let { equiv(it.chars) } ?: 27.0
        val ratio = (fe / ref).toFloat()
        if (ratio < 0.93f) frontNativeScale = ((ratio * 10f).roundToInt() / 10f).coerceIn(0.5f, 0.95f)
    }

    private fun logicalWide(): Boolean {
        val m = baseLens() ?: return false
        return zoomRangeOf(m).lower < 0.95f
    }

    // Looks for extra cameras the normal list doesn't show and picks a wider front camera if there is one.
    private fun probeHidden(ids: List<String>) {
        val info = mutableListOf<String>()
        val frontCands = mutableListOf<Lens>()
        for (i in 2..15) {
            val id = i.toString()
            if (id in ids) continue
            try {
                val c = mgr.getCameraCharacteristics(id)
                lcCache[id] = c
                val facing = c.get(CameraCharacteristics.LENS_FACING)
                val eq = equiv(c)?.let { String.format(Locale.US, "%.1f", it) }
                info.add(
                    "ID " + id + " facing=" + facing + " compat=" + compat(c) + " mm=" + eq +
                        " zoom=" + c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) +
                        " phys=" + c.physicalCameraIds
                )
                if (facing == CameraCharacteristics.LENS_FACING_FRONT && compat(c) && equiv(c) != null) {
                    frontCands.add(Lens(id, null, c))
                }
            } catch (e: Exception) {
            }
        }
        hiddenInfo = info
        val fl = frontLens ?: return
        val baseEq = equiv(fl.chars) ?: return
        for (pid in fl.chars.physicalCameraIds) {
            if (pid in ids) continue
            try {
                frontCands.add(Lens(fl.logicalId, pid, mgr.getCameraCharacteristics(pid)))
            } catch (e: Exception) {
            }
        }
        val wide = frontCands
            .filter { val e = equiv(it.chars); e != null && e < baseEq * 0.93 }
            .minByOrNull { equiv(it.chars)!! }
        frontUltra = wide
        if (wide != null) {
            val ratio = (equiv(wide.chars)!! / baseEq).toFloat()
            frontWideFactor = (((ratio * 10f).roundToInt()) / 10f).coerceIn(0.5f, 0.95f)
        }
    }

    private fun setupLenses() {
        val ids = mgr.cameraIdList.sortedBy { it.toIntOrNull() ?: 999 }
        val backs = mutableListOf<Lens>()
        for (id in ids) {
            val c = lcOf(id)
            if (!compat(c)) continue
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            if (facing == CameraCharacteristics.LENS_FACING_BACK) backs.add(Lens(id, null, c))
            else if (facing == CameraCharacteristics.LENS_FACING_FRONT && frontLens == null) frontLens = Lens(id, null, c)
        }
        probeHidden(ids)
        mainLens = backs.minByOrNull { zoomRangeOf(it).lower }
        val main = mainLens ?: return
        if (!logicalWide()) {
            val mainEq = equiv(main.chars) ?: return
            val cands = mutableListOf<Lens>()
            for (b in backs) {
                if (b !== main) cands.add(b)
                for (pid in b.chars.physicalCameraIds) {
                    if (pid !in ids) cands.add(Lens(b.logicalId, pid, mgr.getCameraCharacteristics(pid)))
                }
            }
            val hidden = mutableListOf<String>()
            for (i in 2..9) {
                val id = i.toString()
                if (id in ids) continue
                try {
                    val c = mgr.getCameraCharacteristics(id)
                    if (compat(c) && c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK) {
                        lcCache[id] = c
                        cands.add(Lens(id, null, c))
                        hidden.add(id)
                    }
                } catch (e: Exception) {
                }
            }
            hiddenIds = hidden
            ultraLens = cands
                .filter { val e = equiv(it.chars); e != null && e < mainEq * 0.8 }
                .minByOrNull { equiv(it.chars)!! }
        }
    }

    private fun showInfo() {
        val sb = StringBuilder()
        try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            sb.append("MyCam v").append(pi.versionName).append(" (build ").append(pi.longVersionCode).append(")\n\n")
        } catch (e: Exception) {
        }
        for (id in mgr.cameraIdList) {
            val c = lcOf(id)
            val eq = equiv(c)?.let { String.format(Locale.US, "%.1f", it) }
            sb.append("ID ").append(id)
                .append(" facing=").append(c.get(CameraCharacteristics.LENS_FACING))
                .append(" zoom=").append(c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE))
                .append(" phys=").append(c.physicalCameraIds)
                .append(" mm=").append(eq).append("\n")
        }
        sb.append("\nUsing: ").append(cur?.logicalId).append(" / ").append(cur?.physicalId)
        sb.append("\nLogical wide: ").append(logicalWide())
        sb.append("\nHidden IDs responding: ").append(hiddenIds)
        sb.append("\nUltra fallback: ").append(ultraLens?.let { it.logicalId + "/" + it.physicalId })
        sb.append("\nFront wide: ").append(frontUltra?.let { it.logicalId + "/" + it.physicalId + " x" + frontWideFactor })
        sb.append("\nFront zoom scale: ").append(frontNativeScale)
        sb.append("\nExtra camera IDs:")
        if (hiddenInfo.isEmpty()) sb.append(" none") else for (l in hiddenInfo) sb.append("\n").append(l)
        sb.append("\nStabilization limits: ").append(stabCap)
        sb.append("\n60 fps blocked: ").append(fps60Off)
        sb.append("\nImage processing: ").append(procOn).append(" (stream ")
            .append(if (yuvMode) "frames" else "jpeg").append(", last ISO ").append(lastIso).append(")")
        sb.append("\nLast enhanced photo: ").append(lastFrames).append(" frames, noise ").append(String.format("%.1f", lastNoise)).append(", merge ")
            .append(lastMergeMs).append(" ms, look ").append(lastLookMs).append(" ms, total ").append(lastTotalMs).append(" ms")
        sb.append("\nHAL boost: ").append(if (halBoost) "on" else "off").append(", set: ").append(lastHalSet)
        sb.append("\nHAL result: ").append(lastHalResult)
        sb.append("\nVideo noise reduction (3DNR): ").append(if (nr3dOff) "off, the phone refused it" else if (nr3dUsed) "on" else "not used in this mode")
        if (Build.VERSION.SDK_INT >= 31) {
            for (xid in listOfNotNull(mainLens?.logicalId, "4").distinct()) {
                try {
                    val ext = mgr.getCameraExtensionCharacteristics(xid).supportedExtensions
                    sb.append("\nCamera extensions ").append(xid).append(": ").append(
                        if (ext.isEmpty()) "none" else ext.joinToString(", ") {
                            when (it) { 0 -> "AUTO"; 1 -> "FACE_RETOUCH"; 2 -> "BOKEH"; 3 -> "HDR"; 4 -> "NIGHT"; else -> "#$it" }
                        })
                } catch (e: Exception) {
                    sb.append("\nCamera extensions ").append(xid).append(": unavailable")
                }
            }
        }
        val mlc = mainLens?.let { lcOf(it.logicalId) }
        if (mlc != null) {
            val rk = mlc.availableCaptureRequestKeys.map { it.name }.filter { !it.startsWith("android.") }
            val sk = (mlc.availableSessionKeys ?: emptyList()).map { it.name }.filter { !it.startsWith("android.") }
            sb.append("\nVendor request keys: ").append(if (rk.isEmpty()) "none" else rk.joinToString(", "))
            sb.append("\nVendor session keys: ").append(if (sk.isEmpty()) "none" else sk.joinToString(", "))
        }
        val m = mainLens
        if (m != null) {
            val lc = lcOf(m.logicalId)
            sb.append("\n\nAE fps ranges: ").append(
                lc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                    ?.joinToString(" ") { r -> "${r.lower}-${r.upper}" }
            )
            val mp = m.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            if (mp != null) {
                for ((w, h) in listOf(Pair(3840, 2160), Pair(1920, 1080), Pair(1280, 720))) {
                    val d = mp.getOutputMinFrameDuration(MediaRecorder::class.java, Size(w, h))
                    sb.append("\n").append(h).append("p max fps: ")
                        .append(if (d > 0L) (1e9 / d).roundToInt().toString() else "?")
                }
                val hs = mp.highSpeedVideoSizes
                sb.append("\nHigh-speed: ")
                if (hs.isEmpty()) sb.append("none")
                for (s in hs) {
                    sb.append(s.width).append("x").append(s.height).append(" ")
                    sb.append(mp.getHighSpeedVideoFpsRangesFor(s).joinToString(",", "[", "] ") { r -> "${r.lower}-${r.upper}" })
                }
            }
        }
        val report = sb.toString()
        AlertDialog.Builder(this).setTitle("Camera info").setMessage(report)
            .setNegativeButton("Copy") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Camera info", report))
                toast("Camera info copied")
            }
            .setNeutralButton("Reset limits") { _, _ ->
                stabCap.clear()
                val ed = prefs.edit()
                for (k in prefs.all.keys) if (k.startsWith("cap_") || k == "fps60_off") ed.remove(k)
                ed.apply()
                fps60Off = false
                cur?.let { pickSizes(it) }
                updateStabUi()
                toast("Limits reset")
            }
            .setPositiveButton("OK", null).show()
    }

    // ================= sizes =================

    private fun megapixels(sz: Size) = max(1, (sz.width.toLong() * sz.height / 1_000_000L).toInt())

    private fun pickSizes(l: Lens) {
        val map = l.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return
        val vs = map.getOutputSizes(MediaRecorder::class.java)?.toList() ?: emptyList()
        fun has(w: Int, h: Int) = vs.any { it.width == w && it.height == h }
        val dot = "\u00B7"
        // the full list is always shown; options this lens can't do are dimmed
        var all = listOf(
            VidOpt(1280, 720, 30, 12_000_000, "720p 30", "720${dot}30", has(1280, 720)),
            VidOpt(1920, 1080, 30, 24_000_000, "1080p 30", "1080${dot}30", has(1920, 1080)),
            VidOpt(1920, 1080, 60, 36_000_000, "1080p 60", "1080${dot}60", has(1920, 1080) && !fps60Off),
            VidOpt(3840, 2160, 24, 50_000_000, "4K 24", "4K${dot}24", has(3840, 2160)),
            VidOpt(3840, 2160, 30, 60_000_000, "4K 30", "4K${dot}30", has(3840, 2160))
        )
        if (all.none { it.ok }) {
            val bs = vs.maxByOrNull { it.width * it.height } ?: Size(1280, 720)
            all = listOf(VidOpt(bs.width, bs.height, 30, 12_000_000, "${bs.height}p 30", "${bs.height}${dot}30", true))
        }
        vidOpts = all
        var idx = all.indexOfFirst { it.label == vidLabel && it.ok }
        if (idx < 0) idx = all.indexOfFirst { it.label == "1080p 30" && it.ok }
        if (idx < 0) idx = max(0, all.indexOfFirst { it.ok })
        vidIdx = idx
        vidLabel = all[idx].label
        vidSeg.setOptions(all.map { it.short }, idx)
        vidSeg.setDimmed(all.indices.filter { !all[it].ok }.toSet())

        val wantW = if (mode == 1 || !ratio43) 16 else 4
        val wantH = if (mode == 1 || !ratio43) 9 else 3
        val ps = map.getOutputSizes(SurfaceTexture::class.java)?.toList() ?: emptyList()
        previewSize = ps.filter { it.width * wantH == it.height * wantW && it.width <= 1920 }
            .maxByOrNull { it.width }
            ?: ps.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: Size(1280, 720)

        // photo resolutions for this aspect ratio: the largest, about 12 MP, and a small one
        val js = map.getOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList()
        val fit = js.filter { it.width * wantH == it.height * wantW }.sortedBy { it.width * it.height }
        val cands = mutableListOf<Size>()
        fit.lastOrNull()?.let { cands.add(it) }
        fit.lastOrNull { it.width.toLong() * it.height <= 13_000_000L }?.let { if (it !in cands) cands.add(it) }
        fit.lastOrNull { it.width.toLong() * it.height <= 4_500_000L }?.let { if (it !in cands) cands.add(it) }
        var popts = cands.sortedBy { it.width * it.height }
        if (popts.isEmpty()) popts = listOf(js.maxByOrNull { it.width * it.height } ?: previewSize)
        photoOpts = popts
        var pi = 0
        var bestD = Int.MAX_VALUE
        popts.forEachIndexed { i, sz ->
            val dd = abs(megapixels(sz) - photoPrefMp)
            if (dd < bestD) { bestD = dd; pi = i }
        }
        photoIdx = pi
        photoSize = popts[pi]
        photoSeg.setOptions(popts.map { megapixels(it).toString() + " MP" }, pi)

        // frames for the multi-frame mode: the YUV size closest to the chosen photo size
        val ys = map.getOutputSizes(ImageFormat.YUV_420_888)?.toList() ?: emptyList()
        val photoArea = photoSize.width.toLong() * photoSize.height
        yuvSize = ys.filter { it.width * wantH == it.height * wantW && it.width.toLong() * it.height <= 13_000_000L }
            .minByOrNull { abs(it.width.toLong() * it.height - photoArea) } ?: Size(0, 0)
        refreshMenu(false)
    }

    // Viewfinder geometry: 4:3 sits below the top bar, 16:9 grows upward under it
    private fun layoutStage() {
        val w = resources.displayMetrics.widthPixels
        val h = w * previewSize.width / previewSize.height
        val wide = previewSize.width * 9 == previewSize.height * 16
        val top = if (wide) dp(10) else dp(52)
        val lp = stage.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w) { lp.width = w; stage.layoutParams = lp }
        topScrim.animate().alpha(if (wide) 1f else 0f).setDuration(300).start()
        if (lp.height == h && lp.topMargin == top) return
        stageAnim?.cancel()
        val h0 = lp.height
        val t0 = lp.topMargin
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 360
        a.interpolator = ios
        a.addUpdateListener {
            val f = it.animatedValue as Float
            val l2 = stage.layoutParams as FrameLayout.LayoutParams
            l2.height = (h0 + (h - h0) * f).toInt()
            l2.topMargin = (t0 + (top - t0) * f).toInt()
            stage.layoutParams = l2
            positionZoomPill(false)
        }
        a.start()
        stageAnim = a
    }

    // ================= camera lifecycle =================

    private fun scheduleOpenRetry(): Boolean {
        if (openRetries >= 10) return false
        openRetries++
        ui.postDelayed({ tryOpen() }, 350)
        return true
    }

    private fun tryOpen() {
        val l = cur ?: return
        if (!hasPerms() || !texture.isAvailable || device != null || opening) return
        pickSizes(l)
        opening = true
        try {
            mgr.openCamera(l.logicalId, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    opening = false
                    openRetries = 0
                    device = d
                    startPreview()
                }
                override fun onDisconnected(d: CameraDevice) {
                    opening = false
                    try { d.close() } catch (x: Exception) {}
                    if (device === d) device = null
                }
                override fun onError(d: CameraDevice, e: Int) {
                    val wasOpening = opening
                    opening = false
                    try { d.close() } catch (x: Exception) {}
                    if (device === d) device = null
                    if (configuring) {
                        handleSessionFailure("camera error $e", true)
                    } else if (wasOpening && scheduleOpenRetry()) {
                        // the camera was still busy: retry quietly
                    } else if (wasOpening && revertToBase()) {
                        // a hidden lens refused to open
                    } else if (SystemClock.elapsedRealtime() - lastFailAt > 1500) {
                        toast("Camera error $e")
                        runOnUiThread { fadeInStage() }
                    }
                }
            }, bg)
        } catch (e: Exception) {
            opening = false
            if (!scheduleOpenRetry() && !revertToBase()) {
                toast("Open failed: ${e.message}")
                fadeInStage()
            }
        }
    }

    private fun closeCamera() {
        closeExt()
        try { session?.close() } catch (e: Exception) {}
        session = null
        try { device?.close() } catch (e: Exception) {}
        device = null
        closeReader(reader)
        reader = null
        closeStaleReader()
    }

    private fun closeStaleReader() {
        closeReader(staleReader)
        staleReader = null
    }

    private fun closeReader(r: ImageReader?) {
        if (r == null) return
        if (processing) {
            synchronized(deferredReaders) { deferredReaders.add(r) }
        } else {
            try { r.close() } catch (e: Exception) {}
        }
    }

    private fun flushReaders() {
        synchronized(deferredReaders) {
            for (r in deferredReaders) try { r.close() } catch (e: Exception) {}
            deferredReaders.clear()
        }
    }

    // a hidden lens that can't be opened: fall back to the main camera of the same side
    private fun revertToBase(): Boolean {
        val b = baseLens() ?: return false
        if (cur === b) return false
        runOnUiThread {
            cur = b
            zoom = 1f
            openRetries = 0
            toast("That lens couldn't be opened. Back to the main camera.")
            reopen()
        }
        return true
    }

    private fun reopen(rebuildChips: Boolean = true) {
        openRetries = 0
        closeCamera()
        refreshCaps()
        if (rebuildChips) buildZoomChips()
        tryOpen()
    }

    private fun capKey() = (cur?.logicalId ?: "") + (if (mode == 1) "/v" else "/p")

    // the ultrawide's video session rejects electronic stabilization on this phone,
    // so it starts at "Optical" instead of failing first and learning it the slow way
    private fun defaultCap() = if (mode == 1 && wideLens() != null && cur === wideLens()) 1 else 3

    private fun stabCapNow(): Int {
        val key = capKey()
        return stabCap.getOrPut(key) { prefs.getInt("cap_$key", defaultCap()) }
    }

    private fun effStab() = min(stab, stabCapNow())

    private fun updateStabUi() {
        val cap = stabCapNow()
        stabSeg.setDimFrom(cap + 1)
        stabSeg.select(min(stab, cap), true)
        refreshMenu()
    }

    // A session that fails to configure steps stabilization down (and remembers it),
    // then falls back to the main lens. The camera is only reopened if the device itself died.
    private fun handleSessionFailure(msg: String, deviceDead: Boolean) {
        runOnUiThread {
            if (!configuring) return@runOnUiThread
            configuring = false
            lastFailAt = SystemClock.elapsedRealtime()
            if (recorder != null && !recording) abortRecorder()
            val eff = effStab()
            val key = capKey()
            failCount++
            openRetries = 0
            if (deviceDead) {
                closeCamera()
            } else {
                try { session?.close() } catch (e: Exception) {}
                session = null
            }
            if (mode == 1 && nr3dUsed && !nr3dOff) {
                // the phone refused the video noise reduction: remember, and carry on without it
                nr3dOff = true
                nr3dUsed = false
                prefs.edit().putBoolean("nr3d_off", true).apply()
                failCount = 0
                if (deviceDead) ui.postDelayed({ tryOpen() }, 300) else startPreview()
                return@runOnUiThread
            }
            if (yuvMode) {
                yuvMode = false
                procOn = false
                prefs.edit().putBoolean("proc_on", false).apply()
                procSeg.select(0)
                toast("This lens can't deliver frames for processing. Image processing is off.")
                if (deviceDead) ui.postDelayed({ tryOpen() }, 300) else startPreview()
                return@runOnUiThread
            }
            if (mode == 1 && (vidOpts.getOrNull(vidIdx)?.fps ?: 30) >= 50) {
                failCount = 0
                disable60()
                if (deviceDead) ui.postDelayed({ tryOpen() }, 300) else startPreview()
                return@runOnUiThread
            }
            if (eff > 0 && failCount <= 4) {
                stabCap[key] = eff - 1
                prefs.edit().putInt("cap_$key", eff - 1).apply()
                updateStabUi()
                toast("${stabNames[eff]} stabilization isn't supported here. Using ${stabNames[eff - 1]}.")
                if (deviceDead) ui.postDelayed({ tryOpen() }, 300) else startPreview()
            } else if (baseLens() != null && cur !== baseLens()) {
                toast("That mode isn't supported on this lens. Back to 1x.")
                cur = baseLens()
                zoom = 1f
                failCount = 0
                reopen()
            } else {
                toast("Camera failed: $msg")
                fadeInStage()
            }
        }
    }

    private fun sensorOri() = cur?.chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

    private fun logIso(range: Range<Int>): Int {
        val lo = range.lower.toDouble()
        val hi = min(range.upper, 6400).toDouble()
        return (lo * (max(hi, lo) / lo).pow((isoProg - 1) / 99.0)).toInt()
    }

    private fun logExp(range: Range<Long>): Long {
        val lo = max(range.lower, 125_000L).toDouble()
        val hi = min(range.upper, 500_000_000L).toDouble()
        return (lo * (max(hi, lo) / lo).pow((shutProg - 1) / 99.0)).toLong()
    }

    private fun applyCommon(b: CaptureRequest.Builder) {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        val video = mode == 1

        b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)

        val minFocus = lc.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (mode == 2 && focusProg > 0 && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * (focusProg - 1) / 99f)
        } else {
            b.set(
                CaptureRequest.CONTROL_AF_MODE,
                if (video) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            tapRegion?.let { b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(it)) }
        }
        tapRegion?.let { b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(it)) }

        val manualExp = mode == 2 && (isoProg > 0 || shutProg > 0)
        if (manualExp) {
            val isoR = lc.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 100)
            val expR = lc.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 1_000_000L)
            val iso = if (isoProg > 0) (if (isoVal > 0) isoVal.coerceIn(isoR.lower, isoR.upper) else logIso(isoR)) else 200.coerceIn(isoR.lower, isoR.upper)
            val exp = if (shutProg > 0) (if (expVal > 0L) expVal.coerceIn(expR.lower, expR.upper) else logExp(expR)) else 16_666_667L.coerceIn(expR.lower, expR.upper)
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp)
        } else {
            val ae = if (!video && hasFlash) {
                when (flashMode) {
                    1 -> CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH
                    2 -> CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH
                    else -> CaptureRequest.CONTROL_AE_MODE_ON
                }
            } else CaptureRequest.CONTROL_AE_MODE_ON
            b.set(CaptureRequest.CONTROL_AE_MODE, ae)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev)
        }

        if (mode == 2 && wbIdx in 1 until wbModes.size) {
            val awb = lc.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)
            if (awb != null && awb.contains(wbModes[wbIdx])) b.set(CaptureRequest.CONTROL_AWB_MODE, wbModes[wbIdx])
        }
        // the torch: the rear flash stays lit as a lamp (video, or the Torch choice in the photo flash button)
        if (hasFlash && ((video && torch) || (!video && !front && flashMode == 3))) {
            b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)
        }

        if (mode == 0 && hdr && hdrSupported) {
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_USE_SCENE_MODE)
            b.set(CaptureRequest.CONTROL_SCENE_MODE, CameraMetadata.CONTROL_SCENE_MODE_HDR)
        }

        if (video) {
            val fps = vidOpts.getOrNull(vidIdx)?.fps ?: 30
            val ranges = lc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList()
            val target = ranges.filter { it.upper == fps }.maxByOrNull { it.lower }
                ?: ranges.filter { it.lower <= fps && it.upper >= fps }.minByOrNull { it.upper - it.lower }
            if (target != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, target)
            // noise reduction that works across frames (the phone's own 3DNR): cleaner dark clips at no cost in frame rate
            nr3dUsed = false
            if (!nr3dOff) {
                val names = reqKeyCache.getOrPut(l.logicalId) {
                    try { lc.availableCaptureRequestKeys.map { it.name }.toSet() } catch (e: Exception) { emptySet() }
                }
                if ("com.mediatek.nrfeature.3dnrmode" in names) nr3dUsed = setVendor(b, "com.mediatek.nrfeature.3dnrmode")
            }
        }

        // stabilization: 1 = optical, 2 = optical + electronic, 3 = preview stabilization
        val eff = effStab()
        val ois = lc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        val oisOn = eff >= 1 && ois?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        b.set(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            if (oisOn) CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON
            else CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_OFF
        )
        val modes = lc.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf(0)
        val m = if (!video) 0 else when (eff) {
            3 -> if (modes.contains(2)) 2 else if (modes.contains(1)) 1 else 0
            2 -> if (modes.contains(1)) 1 else 0
            else -> 0
        }
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, m)
    }

    private fun buildRepeating(d: CameraDevice): CaptureRequest.Builder {
        val b = d.createCaptureRequest(curTemplate)
        curTargets.forEach { b.addTarget(it) }
        applyCommon(b)
        return b
    }

    // Measures the real frame rate when a 60 fps option is active: if the phone quietly stays
    // at 30 (or rejects it), 60 is switched off instead of recording a fake 60 fps clip.
    private val fpsCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            val iso = res.get(CaptureResult.SENSOR_SENSITIVITY)
            if (iso != null) lastIso = iso
            val ex = res.get(CaptureResult.SENSOR_EXPOSURE_TIME)
            if (ex != null) lastExpNs = ex
            if (!fpsProbing) return
            val ts = res.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
            if (fpsCount == 0) fpsFirstTs = ts
            fpsCount++
            val dt = ts - fpsFirstTs
            if (dt >= 1_500_000_000L && fpsCount > 5) {
                fpsProbing = false
                val fps = (fpsCount - 1) * 1e9 / dt
                runOnUiThread { onFpsMeasured(fps) }
            }
        }
    }

    private fun startFpsProbe() {
        val o = vidOpts.getOrNull(vidIdx)
        fpsProbing = mode == 1 && !recording && o != null && o.fps >= 50
        fpsCount = 0
    }

    private fun onFpsMeasured(fps: Double) {
        val o = vidOpts.getOrNull(vidIdx) ?: return
        if (mode != 1 || recording || o.fps < 50) return
        if (fps < 45.0) disable60()
    }

    private fun disable60() {
        fps60Off = true
        prefs.edit().putBoolean("fps60_off", true).apply()
        vidLabel = "1080p 30"
        cur?.let { pickSizes(it) }
        toast("60 fps isn't available through this phone's camera API. Using 1080p 30.")
        updateRepeating()
    }

    private fun updateRepeating() {
        if (extSession != null) {
            updateExtRepeating()
            return
        }
        val d = device ?: return
        val s = session ?: return
        try {
            s.setRepeatingRequest(buildRepeating(d).build(), fpsCb, bg)
        } catch (e: Exception) {
        }
    }

    private fun makeSession(
        d: CameraDevice,
        outputs: List<Surface>,
        targets: List<Surface>,
        template: Int,
        onReady: () -> Unit
    ) {
        val gen = ++sessionGen
        // TextureView resets its buffer size to the size of the view whenever it is laid out
        // (the 4:3 / 16:9 animation does that), and a new session takes its stream size from
        // that. Put the real preview size back first, or the first recording comes out stretched.
        try { texture.surfaceTexture?.setDefaultBufferSize(previewSize.width, previewSize.height) } catch (e: Exception) {}
        session = null
        curTemplate = template
        curTargets = targets
        configuring = true
        val phys = cur?.physicalId
        val outs = outputs.map { s ->
            OutputConfiguration(s).also { if (phys != null) it.setPhysicalCameraId(phys) }
        }
        val req = try {
            buildRepeating(d)
        } catch (e: Exception) {
            handleSessionFailure(e.message ?: "request error", false)
            return
        }
        val cfg = SessionConfiguration(
            SessionConfiguration.SESSION_REGULAR,
            outs,
            Executor { r -> bg.post(r) },
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (gen != sessionGen) {
                        try { s.close() } catch (e: Exception) {}
                        return
                    }
                    configuring = false
                    failCount = 0
                    session = s
                    try {
                        s.setRepeatingRequest(req.build(), fpsCb, bg)
                        onReady()
                    } catch (e: Exception) {
                        toast("Preview failed: ${e.message}")
                    }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    if (gen != sessionGen) return
                    handleSessionFailure("configuration failed", false)
                }
            }
        )
        cfg.sessionParameters = req.build()
        try {
            d.createCaptureSession(cfg)
        } catch (e: Exception) {
            handleSessionFailure(e.message ?: "session error", e is CameraAccessException)
        }
    }

    private fun startPreview() {
        val d = device ?: return
        val st = texture.surfaceTexture ?: return
        closeExt()
        if (xExt >= 0 && mode == 0 && extSupported(cur?.logicalId, cur?.physicalId, xExt)) {
            if (startExtPreview(d, st)) return
        }
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        runOnUiThread { layoutStage() }
        // One Surface per SurfaceTexture: re-creating it while the old session still holds the
        // SurfaceTexture is what froze the preview when switching 4:3 / 16:9
        val ps = previewSurface?.takeIf { it.isValid } ?: Surface(st).also { previewSurface = it }
        val outs = mutableListOf(ps)
        val oldReader = reader
        var newReader: ImageReader? = null
        yuvMode = false
        if (mode != 1) {
            if (procOn && !halBoost && yuvSize.width > 0) {
                val nr = ImageReader.newInstance(yuvSize.width, yuvSize.height, ImageFormat.YUV_420_888, 8)
                newReader = nr
                yuvMode = true
                outs.add(nr.surface)
            } else {
                val nr = ImageReader.newInstance(photoSize.width, photoSize.height, ImageFormat.JPEG, 2)
                newReader = nr
                outs.add(nr.surface)
            }
        }
        reader = newReader
        closeStaleReader()
        staleReader = oldReader
        // the stage stays hidden until the new camera's first frame arrives
        awaitFirstFrame = true
        startFpsProbe()
        makeSession(d, outs, listOf(ps), CameraDevice.TEMPLATE_PREVIEW) {
            closeStaleReader()
            updateRepeating()
        }
    }

    // ================= transitions =================

    private fun animateBlur(to: Float, dur: Long) {
        if (Build.VERSION.SDK_INT < 31) return
        blurAnim?.cancel()
        val a = ValueAnimator.ofFloat(blurNow, to)
        a.duration = dur
        a.addUpdateListener {
            blurNow = it.animatedValue as Float
            try {
                stage.setRenderEffect(
                    if (blurNow < 0.5f) null
                    else RenderEffect.createBlurEffect(blurNow, blurNow, Shader.TileMode.CLAMP)
                )
            } catch (e: Exception) {
            }
        }
        a.start()
        blurAnim = a
    }

    private fun fadeOutStage(flip: Boolean = false) {
        stage.animate().cancel()
        val a = stage.animate().alpha(if (flip) 0f else 0.3f)
            .setDuration(if (flip) 220L else 150L).setInterpolator(ios)
        if (flip) a.rotationY(80f)
        a.start()
        animateBlur(24f, 180L)
        ui.removeCallbacks(fadeInSafety)
        ui.postDelayed(fadeInSafety, 2500)
    }

    private fun fadeInStage() {
        lensSwitching = false
        ui.removeCallbacks(fadeInSafety)
        stage.animate().cancel()
        if (stage.rotationY > 1f) stage.rotationY = -80f
        stage.animate().alpha(1f).rotationY(0f).setDuration(340).setInterpolator(ios).start()
        animateBlur(0f, 300L)
    }

    private fun fadeView(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).translationY(0f).setDuration(280).setInterpolator(ios).start()
        } else {
            v.animate().alpha(0f).translationY(dp(12).toFloat()).setDuration(200).setInterpolator(ios)
                .withEndAction { if (recording) v.visibility = View.INVISIBLE }.start()
        }
    }

    // iPhone-style: while recording only the zoom pill and stop button stay on screen
    private fun setChromeHidden(hide: Boolean) {
        fadeView(modeBar, !hide)
        fadeView(thumbCell, !hide)
        fadeView(flipCell, !hide)
        if (hide) {
            animateVisibility(sheet, false)
            fadePill(true)
            animateVisibility(proSheet, false)
            chevron.animate().rotation(uiAngle).setDuration(200).start()
            chevron.tint = Color.WHITE
        } else {
            animateVisibility(proSheet, mode == 2)
        }
    }

    // ================= shutter / timer =================

    private fun shutterPressed() {
        if (counting) {
            counting = false
            countdownTv.visibility = View.GONE
            return
        }
        if (mode == 1 && recording) {
            haptic(HapticFeedbackConstants.CONFIRM)
            stopRecording(true)
            return
        }
        if (timerSec > 0) {
            counting = true
            tick(timerSec)
        } else doShutter()
    }

    private fun tick(n: Int) {
        if (!counting) { countdownTv.visibility = View.GONE; return }
        if (n == 0) {
            counting = false
            countdownTv.visibility = View.GONE
            doShutter()
            return
        }
        countdownTv.text = n.toString()
        countdownTv.alpha = 0f
        countdownTv.scaleX = 1.4f
        countdownTv.scaleY = 1.4f
        countdownTv.visibility = View.VISIBLE
        countdownTv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(ios).start()
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        ui.postDelayed({ tick(n - 1) }, 1000)
    }

    private fun doShutter() {
        haptic(HapticFeedbackConstants.CONFIRM)
        if (mode == 1) {
            startRecording()
            return
        }
        val screenFlash = mode == 0 && front && !hasFlash && (flashMode == 2 || (flashMode == 1 && lastIso >= 500))
        if (screenFlash) fireScreenFlash { takePhoto() } else takePhoto()
    }

    // Retina-flash style: the screen turns warm white at full brightness, the camera has a moment to
    // adjust to it, then the photo is taken. The light goes away as soon as the photo is captured.
    private val hideScreenFlashRun = Runnable { hideScreenFlash() }

    private fun fireScreenFlash(then: () -> Unit) {
        screenFlashOn = true
        val lp = window.attributes
        lp.screenBrightness = 1f
        window.attributes = lp
        screenLight.animate().cancel()
        screenLight.visibility = View.VISIBLE
        screenLight.animate().alpha(1f).setDuration(140).start()
        ui.removeCallbacks(hideScreenFlashRun)
        ui.postDelayed(hideScreenFlashRun, 6000)
        ui.postDelayed({ then() }, 500)
    }

    private fun hideScreenFlash() {
        if (!screenFlashOn) return
        screenFlashOn = false
        ui.removeCallbacks(hideScreenFlashRun)
        screenLight.animate().cancel()
        screenLight.animate().alpha(0f).setDuration(240).withEndAction { screenLight.visibility = View.GONE }.start()
        val lp = window.attributes
        lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
    }

    // ================= photo =================

    private fun takePhoto() {
        if (extSession != null) {
            takeExtPhoto()
            return
        }
        if (yuvMode) {
            takeProcessedPhoto()
            return
        }
        val d = device ?: return
        val s = session ?: return
        val r = reader ?: return
        val ps = previewSurface ?: return
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage()
            if (img != null) {
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    savePhoto(bytes)
                } finally {
                    img.close()
                }
            }
        }, bg)
        if (hasFlash && (flashMode == 1 || flashMode == 2) && mode != 1) {
            try {
                val p = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                p.addTarget(ps)
                applyCommon(p)
                p.set(
                    CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER,
                    CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START
                )
                s.capture(p.build(), null, bg)
            } catch (e: Exception) {
            }
            bg.postDelayed({ captureStill() }, 800)
        } else {
            captureStill()
        }
    }

    // ================= the phone's own HDR / Night (camera extensions) =================

    private fun extName(e: Int) = when (e) { 0 -> "Auto"; 3 -> "HDR"; 4 -> "Night"; else -> "#$e" }

    // extensions the phone offers for a lens: HDR, Night and Auto, in that order
    private fun extList(id: String?, phys: String?): List<Int> {
        if (id == null || phys != null || Build.VERSION.SDK_INT < 31) return emptyList()
        return extCache.getOrPut(id) {
            try {
                val sup = mgr.getCameraExtensionCharacteristics(id).supportedExtensions
                listOf(3, 4, 0).filter { sup.contains(it) }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    private fun extSupported(id: String?, phys: String?, ext: Int) = extList(id, phys).contains(ext)

    private fun closeExt() {
        try { extSession?.close() } catch (e: Exception) {}
        extSession = null
    }

    private fun pickExtSize(sizes: List<Size>, aspect: Float, maxW: Int): Size? {
        val ok = sizes.filter { it.width <= maxW }.ifEmpty { sizes }
        val match = ok.filter { abs(it.width.toFloat() / it.height - aspect) < 0.02f }
        return match.ifEmpty { ok }.maxByOrNull { it.width * it.height }
    }

    // the request keys the extension accepts: anything else is left out
    private fun extKeyNames(): Set<String> {
        val l = cur ?: return emptySet()
        if (Build.VERSION.SDK_INT < 31) return emptySet()
        return try {
            mgr.getCameraExtensionCharacteristics(l.logicalId).getAvailableCaptureRequestKeys(xExt).map { it.name }.toSet()
        } catch (e: Exception) {
            emptySet()
        }
    }

    private fun applyExtKeys(b: CaptureRequest.Builder, still: Boolean) {
        val names = extKeyNames()
        if (CaptureRequest.CONTROL_ZOOM_RATIO.name in names) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
        if (CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION.name in names) b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev)
        tapRegion?.let {
            if (CaptureRequest.CONTROL_AF_REGIONS.name in names) b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(it))
            if (CaptureRequest.CONTROL_AE_REGIONS.name in names) b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(it))
        }
        if (still) {
            if (CaptureRequest.JPEG_ORIENTATION.name in names) b.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation())
            if (CaptureRequest.JPEG_QUALITY.name in names) b.set(CaptureRequest.JPEG_QUALITY, 97.toByte())
        }
    }

    // lazy: the extension classes only exist on Android 12 and up
    private val extCb by lazy { object : CameraExtensionSession.ExtensionCaptureCallback() {
        override fun onCaptureFailed(session: CameraExtensionSession, request: CaptureRequest) {
            if (processing) {
                processing = false
                flushReaders()
                runOnUiThread { setProcessing(false) }
                toast("The phone's HDR/Night capture failed")
            }
        }
    } }

    // the extension refused to start: go back to the normal camera and switch it off
    private fun extFailed(why: String) {
        xExt = -1
        prefs.edit().putInt("x_ext", -1).apply()
        toast("Xiaomi HDR/Night isn't available here ($why). Back to normal.")
        runOnUiThread {
            refreshMenu(false)
            reopen()
        }
    }

    private fun startExtPreview(d: CameraDevice, st: SurfaceTexture): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        val l = cur ?: return false
        try {
            val xc = mgr.getCameraExtensionCharacteristics(l.logicalId)
            val aspect = if (ratio43) 4f / 3f else 16f / 9f
            val ps = pickExtSize(xc.getExtensionSupportedSizes(xExt, SurfaceTexture::class.java), aspect, 1920)
            val cs = pickExtSize(xc.getExtensionSupportedSizes(xExt, ImageFormat.JPEG), aspect, Int.MAX_VALUE)
            if (ps == null || cs == null) {
                extFailed("no matching sizes")
                return true
            }
            previewSize = ps
            st.setDefaultBufferSize(ps.width, ps.height)
            runOnUiThread { layoutStage() }
            val surf = previewSurface?.takeIf { it.isValid } ?: Surface(st).also { previewSurface = it }
            val oldReader = reader
            val nr = ImageReader.newInstance(cs.width, cs.height, ImageFormat.JPEG, 2)
            reader = nr
            yuvMode = false
            closeStaleReader()
            staleReader = oldReader
            awaitFirstFrame = true
            val gen = ++sessionGen
            configuring = true
            session = null
            val cfg = ExtensionSessionConfiguration(
                xExt,
                listOf(OutputConfiguration(surf), OutputConfiguration(nr.surface)),
                Executor { r -> bg.post(r) },
                object : CameraExtensionSession.StateCallback() {
                    override fun onConfigured(s: CameraExtensionSession) {
                        if (gen != sessionGen) {
                            try { s.close() } catch (e: Exception) {}
                            return
                        }
                        configuring = false
                        failCount = 0
                        extSession = s
                        closeStaleReader()
                        updateExtRepeating()
                    }
                    override fun onConfigureFailed(s: CameraExtensionSession) {
                        if (gen != sessionGen) return
                        configuring = false
                        extFailed("configuration failed")
                    }
                    override fun onClosed(s: CameraExtensionSession) {}
                }
            )
            d.createExtensionSession(cfg)
            return true
        } catch (e: Exception) {
            configuring = false
            extFailed(e.message ?: "error")
            return true
        }
    }

    private fun updateExtRepeating() {
        val d = device ?: return
        val s = extSession ?: return
        val surf = previewSurface ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(surf)
            applyExtKeys(b, false)
            s.setRepeatingRequest(b.build(), Executor { r -> bg.post(r) }, extCb)
        } catch (e: Exception) {
        }
    }

    private fun takeExtPhoto() {
        if (processing) return
        val d = device ?: return
        val s = extSession ?: return
        val r = reader ?: return
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage()
            if (img != null) {
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    savePhoto(bytes)
                } finally {
                    img.close()
                }
            }
            processing = false
            flushReaders()
            runOnUiThread { setProcessing(false) }
        }, bg)
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(r.surface)
            applyExtKeys(b, true)
            processing = true
            runOnUiThread { setProcessing(true) }
            selfieShot = front
            selfieRot = devRot
            if (front) {
                runOnUiThread {
                    selfieRef = try { texture.getBitmap(48, 64) } catch (e: Exception) { null }
                }
            }
            s.capture(b.build(), Executor { x -> bg.post(x) }, extCb)
            runOnUiThread {
                flashOverlay.animate().cancel()
                flashOverlay.alpha = 0.75f
                flashOverlay.animate().alpha(0f).setDuration(170).start()
            }
        } catch (e: Exception) {
            processing = false
            runOnUiThread { setProcessing(false) }
            toast("Capture failed: ${e.message}")
        }
    }

    // ================= image processing (burst, align, merge) =================

    // the camera's best-quality noise reduction, sharpening and tone settings for photos
    private fun applyQuality(b: CaptureRequest.Builder) {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        fun has(key: CameraCharacteristics.Key<IntArray>, v: Int) = lc.get(key)?.contains(v) == true
        if (has(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES, CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.NOISE_REDUCTION_MODE, CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY)
        if (has(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES, CameraMetadata.EDGE_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.EDGE_MODE, CameraMetadata.EDGE_MODE_HIGH_QUALITY)
        if (has(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES, CameraMetadata.HOT_PIXEL_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.HOT_PIXEL_MODE, CameraMetadata.HOT_PIXEL_MODE_HIGH_QUALITY)
        if (has(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES, CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
        if (has(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES, CameraMetadata.TONEMAP_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.TONEMAP_MODE, CameraMetadata.TONEMAP_MODE_HIGH_QUALITY)
    }

    // the noisier the scene (higher ISO), the more frames are merged; bright scenes stay a single frame
    private fun burstCount(pixels: Int): Int {
        val iso = lastIso
        var n = when {
            iso <= 0 -> 4
            iso < 200 -> 1
            iso < 500 -> 3
            iso < 1000 -> 5
            else -> 7
        }
        if (pixels > 10_000_000 && n > 5) n = 5
        return n
    }

    private fun refreshProcUi() {
        val n = pendingJobs.get()
        procTv.text = if (n > 1) "Enhancing ($n)\u2026" else "Enhancing\u2026"
        if (processing || n > 0) {
            if (procTv.visibility != View.VISIBLE || procTv.alpha < 0.99f) setProcessing(true)
        } else {
            setProcessing(false)
        }
    }

    // two photos can be finished in the background at once if the app is allowed enough memory
    private fun maxPending() = if (Runtime.getRuntime().maxMemory() >= 380L * 1024 * 1024) 2 else 1

    // long exposures are what a dim scene needs: let the camera use up to ~1/8 s per frame
    private fun lowLightRange() = cur?.let { l ->
        lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList()
            ?.filter { it.upper >= 24 && it.lower in 5..15 }?.minByOrNull { abs(it.lower - 8) }
    }

    private fun setProcessing(on: Boolean) {
        procTv.animate().cancel()
        if (on) {
            procTv.alpha = 0f
            procTv.visibility = View.VISIBLE
            procTv.animate().alpha(1f).setDuration(200).start()
        } else {
            procTv.animate().alpha(0f).setDuration(200).withEndAction {
                if (!processing && pendingJobs.get() == 0) procTv.visibility = View.GONE
            }.start()
        }
    }

    private fun takeProcessedPhoto() {
        val d = device ?: return
        val s = session ?: return
        val r = reader ?: return
        val ps = previewSurface ?: return
        if (processing) {
            toast("Still finishing the last photo")
            return
        }
        if (pendingJobs.get() >= maxPending()) {
            toast("Still finishing earlier photos")
            return
        }
        val flashShot = hasFlash && (flashMode == 1 || flashMode == 2)
        val n = if (flashShot) 1 else burstCount(r.width * r.height)
        val orient = jpegOrientation()
        val isoNow = lastIso
        val shotFront = front
        val shotRot = devRot
        val llr = if (isoNow >= 400 && !flashShot) lowLightRange() else null
        processing = true
        selfieShot = front
        selfieRot = devRot
        if (front) {
            runOnUiThread { selfieRef = try { texture.getBitmap(48, 64) } catch (e: Exception) { null } }
        }
        runOnUiThread { refreshProcUi() }

        val got = ArrayList<Image>()
        val done = BooleanArray(1)
        r.setOnImageAvailableListener({ ir ->
            val img = try { ir.acquireNextImage() } catch (e: Exception) { null }
            if (img != null) {
                synchronized(got) {
                    if (got.size < n) got.add(img) else img.close()
                    if (got.size == n && !done[0]) {
                        done[0] = true
                        ir.setOnImageAvailableListener(null, null)
                        val list = ArrayList(got)
                        packPool.execute { packAndQueue(list, orient, isoNow, shotFront, shotRot) }
                    }
                }
            }
        }, bg)

        // safety net: never stay stuck on "Enhancing"
        ui.postDelayed({
            if (processing && !done[0]) {
                synchronized(got) {
                    for (im in got) try { im.close() } catch (e: Exception) {}
                    got.clear()
                }
                try { r.setOnImageAvailableListener(null, null) } catch (e: Exception) {}
                processing = false
                setProcessing(false)
                flushReaders()
                toast("The capture took too long")
            }
        }, 12000)

        val shoot = Runnable {
            try {
                val reqs = ArrayList<CaptureRequest>()
                for (i in 0 until n) {
                    val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                    b.addTarget(r.surface)
                    applyCommon(b)
                    b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                    applyQuality(b)
                    if (llr != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, llr)
                    reqs.add(b.build())
                }
                s.captureBurst(reqs, null, bg)
                runOnUiThread {
                    flashOverlay.animate().cancel()
                    flashOverlay.alpha = 0.75f
                    flashOverlay.animate().alpha(0f).setDuration(170).start()
                }
            } catch (e: Exception) {
                processing = false
                runOnUiThread { setProcessing(false) }
                toast("Capture failed: ${e.message}")
            }
        }
        if (flashShot) {
            try {
                val p = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                p.addTarget(ps)
                applyCommon(p)
                p.set(
                    CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER,
                    CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START
                )
                s.capture(p.build(), null, bg)
            } catch (e: Exception) {
            }
            bg.postDelayed(shoot, 800)
        } else {
            shoot.run()
        }
    }

    // The frames are copied out of the camera's buffers right away, so the camera is free for the next
    // photo while this one is merged and finished in the background.
    private fun packAndQueue(list: List<Image>, orient: Int, iso: Int, selfie: Boolean, srot: Int) {
        val packed = ArrayList<ByteArray>()
        var pw = 0
        var ph = 0
        try {
            for (im in list) {
                try {
                    packed.add(toNv21(im))
                    pw = im.width
                    ph = im.height
                } catch (e: OutOfMemoryError) {
                    break
                }
            }
        } finally {
            for (im in list) try { im.close() } catch (e: Exception) {}
        }
        if (packed.isEmpty()) {
            processing = false
            flushReaders()
            runOnUiThread { refreshProcUi() }
            toast("Not enough memory for this photo")
            return
        }
        val sref = selfieRef
        pendingJobs.incrementAndGet()
        processing = false
        flushReaders()
        runOnUiThread {
            hideScreenFlash()
            refreshProcUi()
        }
        procPool.execute { runBurstPacked(packed, pw, ph, orient, iso, selfie, srot, sref) }
    }

    private fun runBurstPacked(frames: List<ByteArray>, w: Int, h: Int, orient: Int, iso: Int, selfie: Boolean, srot: Int, sref: Bitmap?) {
        val t0 = SystemClock.elapsedRealtime()
        try {
            lastFrames = frames.size
            var jpeg: ByteArray? = null
            try {
                val thr = max(2, min(8, Runtime.getRuntime().availableProcessors()))
                val nv = if (frames.size == 1) {
                    smoothChroma(frames[0], w, h)
                    frames[0]
                } else {
                    Merge.merge(frames, w, h, 0f, thr)
                }
                lastMergeMs = SystemClock.elapsedRealtime() - t0
                val tl = SystemClock.elapsedRealtime()
                if (frames.size == 1) {
                    Look.process(nv, w, h, thr, 0.7f)
                } else {
                    // the merge measured the noise of this very burst: the cleaning follows it
                    val fn = Merge.lastFrameNoise
                    val res = Merge.lastResidualNoise
                    lastNoise = fn
                    Look.process(nv, w, h, thr, 1f, Merge.lastBandSigmaY, Merge.lastBandSigmaC, if (fn > 0f) res / fn else 1f, res)
                }
                lastLookMs = SystemClock.elapsedRealtime() - tl
                jpeg = nv21ToJpeg(nv, w, h)
            } catch (e: Throwable) {
                // anything went wrong: keep the first frame so the photo is never lost
                try {
                    smoothChroma(frames[0], w, h)
                    jpeg = nv21ToJpeg(frames[0], w, h)
                } catch (x: Throwable) {
                }
            }
            val out = jpeg
            if (out != null) savePhoto(tagJpeg(out, orient), selfie, srot, sref, false) else toast("Couldn't process the photo")
            lastTotalMs = SystemClock.elapsedRealtime() - t0
        } finally {
            pendingJobs.decrementAndGet()
            runOnUiThread { refreshProcUi() }
        }
    }

    private fun toNv21(img: Image): ByteArray {
        val w = img.width
        val h = img.height
        val out = ByteArray(w * h * 3 / 2)
        val yp = img.planes[0]
        val up = img.planes[1]
        val vp = img.planes[2]
        val yb = yp.buffer.duplicate()
        for (y in 0 until h) {
            yb.position(y * yp.rowStride)
            yb.get(out, y * w, w)
        }
        val cw = w / 2
        val ub = up.buffer.duplicate()
        val vb = vp.buffer.duplicate()
        val ut = ByteArray((cw - 1) * up.pixelStride + 1)
        val vt = ByteArray((cw - 1) * vp.pixelStride + 1)
        var o = w * h
        for (cy in 0 until h / 2) {
            ub.position(cy * up.rowStride)
            ub.get(ut, 0, ut.size)
            vb.position(cy * vp.rowStride)
            vb.get(vt, 0, vt.size)
            var ui = 0
            var vi = 0
            for (cx in 0 until cw) {
                out[o++] = vt[vi]
                out[o++] = ut[ui]
                ui += up.pixelStride
                vi += vp.pixelStride
            }
        }
        return out
    }

    private fun singleFrame(img: Image): ByteArray {
        val nv = toNv21(img)
        smoothChroma(nv, img.width, img.height)
        return nv
    }

    private fun halfLuma(f: BurstFrame): ByteArray {
        val w2 = f.w / 2
        val h2 = f.h / 2
        val out = ByteArray(w2 * h2)
        val b = f.y.duplicate()
        val r0 = ByteArray(f.w)
        val r1 = ByteArray(f.w)
        for (yy in 0 until h2) {
            b.position(yy * 2 * f.yrs)
            b.get(r0, 0, f.w)
            b.position((yy * 2 + 1) * f.yrs)
            b.get(r1, 0, f.w)
            var o = yy * w2
            var x = 0
            for (xx in 0 until w2) {
                val a = (r0[x].toInt() and 0xFF) + (r0[x + 1].toInt() and 0xFF) +
                    (r1[x].toInt() and 0xFF) + (r1[x + 1].toInt() and 0xFF)
                out[o++] = (a shr 2).toByte()
                x += 2
            }
        }
        return out
    }

    private fun shrink(src: ByteArray, sw: Int, sh: Int, k: Int): ByteArray {
        val ow = sw / k
        val oh = sh / k
        val out = ByteArray(ow * oh)
        for (y in 0 until oh) {
            for (x in 0 until ow) {
                var sum = 0
                for (j in 0 until k) {
                    for (i in 0 until k) sum += src[(y * k + j) * sw + x * k + i].toInt() and 0xFF
                }
                out[y * ow + x] = (sum / (k * k)).toByte()
            }
        }
        return out
    }

    private fun sharpness(a: ByteArray, w: Int, h: Int): Long {
        var sum = 0L
        for (y in 0 until h) {
            val ro = y * w
            for (x in 0 until w - 1) {
                val d = (a[ro + x].toInt() and 0xFF) - (a[ro + x + 1].toInt() and 0xFF)
                sum += if (d < 0) -d else d
            }
        }
        return sum
    }

    // best shift (dx, dy) in [-r, r] around (cx, cy) so that frm(x + dx, y + dy) matches ref(x, y);
    // small shifts are slightly favoured so that noise alone can't pull a frame out of place
    private fun searchShift(
        ref: ByteArray, frm: ByteArray, w: Int, h: Int, cx: Int, cy: Int, r: Int, step: Int
    ): IntArray {
        val mx = abs(cx) + r + 1
        val my = abs(cy) + r + 1
        if (w - 2 * mx < 8 || h - 2 * my < 8) return intArrayOf(cx, cy)
        var best = Long.MAX_VALUE
        var bx = cx
        var by = cy
        for (oy in -r..r) {
            for (ox in -r..r) {
                val sx = cx + ox
                val sy = cy + oy
                var sad = 0L
                var yy = my
                while (yy < h - my) {
                    val ro = yy * w
                    val rf = (yy + sy) * w + sx
                    var xx = mx
                    while (xx < w - mx) {
                        val a = ref[ro + xx].toInt() and 0xFF
                        val b = frm[rf + xx].toInt() and 0xFF
                        sad += if (a > b) a - b else b - a
                        xx += step
                    }
                    if (sad >= best) break
                    yy += step
                }
                val score = sad + (sad shr 6) * (abs(ox) + abs(oy))
                if (score < best) {
                    best = score
                    bx = sx
                    by = sy
                }
            }
        }
        return intArrayOf(bx, by)
    }

    // Align the frames to the sharpest one (coarse 1/8 scale, then 1/2 scale) and average them,
    // pixel by pixel, with less weight where a frame disagrees (moving subjects, misalignment).
    // Every stage runs on all CPU cores.
    private fun mergeFrames(frames: List<BurstFrame>, iso: Int): ByteArray {
        val w = frames[0].w
        val h = frames[0].h
        val w2 = w / 2
        val h2 = h / 2
        val w8 = w2 / 4
        val h8 = h2 / 4
        val threads = max(2, min(8, Runtime.getRuntime().availableProcessors()))
        val pool = Executors.newFixedThreadPool(threads)
        val out = ByteArray(w * h * 3 / 2)
        try {
            val prep = ArrayList<Future<*>>()
            for (f in frames) {
                prep.add(pool.submit(Runnable {
                    f.s2 = halfLuma(f)
                    f.s8 = shrink(f.s2, w2, h2, 4)
                }))
            }
            for (j in prep) j.get()
            var ri = 0
            var bestSharp = -1L
            for (i in frames.indices) {
                val sh = sharpness(frames[i].s8, w8, h8)
                if (sh > bestSharp) {
                    bestSharp = sh
                    ri = i
                }
            }
            val ref = frames[ri]
            val others = frames.filterIndexed { i, _ -> i != ri }
            val aligns = ArrayList<Future<*>>()
            for (f in others) {
                aligns.add(pool.submit(Runnable {
                    val a = searchShift(ref.s8, f.s8, w8, h8, 0, 0, 6, 1)
                    val b = searchShift(ref.s2, f.s2, w2, h2, a[0] * 4, a[1] * 4, 4, 3)
                    f.dx = b[0] * 2
                    f.dy = b[1] * 2
                }))
            }
            for (j in aligns) j.get()
            // frames of a noisy scene differ by their noise alone, so the "this is movement" limit has to
            // follow the measured noise, otherwise most frames get thrown away and the grain stays
            val noiseRef = Look.estimateNoise(ref.y, w, h, ref.yrs)
            lastNoise = noiseRef
            val sigma = max((5.0 + iso / 120.0).coerceIn(6.0, 24.0), (2.2 * noiseRef).coerceIn(5.0, 40.0))
            val lut = IntArray(256) { dd -> (256.0 * exp(-(dd * dd) / (2.0 * sigma * sigma))).toInt() }
            val bands = threads * 2
            val jobs = ArrayList<Future<*>>()
            for (bi in 0 until bands) {
                val y0 = (h * bi / bands) and 1.inv()
                val y1 = if (bi == bands - 1) h else (h * (bi + 1) / bands) and 1.inv()
                jobs.add(pool.submit(Runnable { mergeRows(ref, others, out, y0, y1, lut) }))
            }
            for (j in jobs) j.get()
        } finally {
            pool.shutdown()
        }
        smoothChroma(out, w, h)
        return out
    }

    // one chroma row of a plane, copied in one go and spread out into a plain array
    private fun readChromaRow(buf: java.nio.ByteBuffer, row: Int, rs: Int, ps: Int, cw: Int, tmp: ByteArray, dst: ByteArray) {
        buf.position(row * rs)
        buf.get(tmp, 0, (cw - 1) * ps + 1)
        var i = 0
        for (x in 0 until cw) {
            dst[x] = tmp[i]
            i += ps
        }
    }

    private fun mergeRows(ref: BurstFrame, others: List<BurstFrame>, out: ByteArray, y0: Int, y1: Int, lut: IntArray) {
        val w = ref.w
        val h = ref.h
        val wh = w * h
        val n = others.size
        val cw = w / 2
        val ch = h / 2
        // every thread reads through its own views of the frames, a whole row at a time
        val refY = ref.y.duplicate()
        val refU = ref.u.duplicate()
        val refV = ref.v.duplicate()
        val fY = Array(n) { others[it].y.duplicate() }
        val fU = Array(n) { others[it].u.duplicate() }
        val fV = Array(n) { others[it].v.duplicate() }
        val rowR = ByteArray(w)
        val rowF = Array(n) { ByteArray(w) }
        val uR = ByteArray(cw)
        val vR = ByteArray(cw)
        val uF = Array(n) { ByteArray(cw) }
        val vF = Array(n) { ByteArray(cw) }
        val tmpU = ByteArray((cw - 1) * maxOf(ref.ups, others.maxOfOrNull { it.ups } ?: 1) + 1)
        val tmpV = ByteArray((cw - 1) * maxOf(ref.vps, others.maxOfOrNull { it.vps } ?: 1) + 1)
        for (y in y0 until y1) {
            refY.position(y * ref.yrs)
            refY.get(rowR, 0, w)
            val evenRow = (y and 1) == 0
            if (evenRow) {
                readChromaRow(refU, y shr 1, ref.urs, ref.ups, cw, tmpU, uR)
                readChromaRow(refV, y shr 1, ref.vrs, ref.vps, cw, tmpV, vR)
            }
            for (k in 0 until n) {
                val f = others[k]
                var sy = y + f.dy
                if (sy < 0) sy = 0 else if (sy >= h) sy = h - 1
                fY[k].position(sy * f.yrs)
                fY[k].get(rowF[k], 0, w)
                if (evenRow) {
                    var ccy = sy shr 1
                    if (ccy >= ch) ccy = ch - 1
                    readChromaRow(fU[k], ccy, f.urs, f.ups, cw, tmpU, uF[k])
                    readChromaRow(fV[k], ccy, f.vrs, f.vps, cw, tmpV, vF[k])
                }
            }
            val ro = y * w
            for (x in 0 until w) {
                val r = rowR[x].toInt() and 0xFF
                var sum = r * 256
                var ws = 256
                val chroma = evenRow && (x and 1) == 0
                var su = 0
                var sv = 0
                if (chroma) {
                    su = (uR[x shr 1].toInt() and 0xFF) * 256
                    sv = (vR[x shr 1].toInt() and 0xFF) * 256
                }
                for (k in 0 until n) {
                    val f = others[k]
                    var sx = x + f.dx
                    if (sx < 0) sx = 0 else if (sx >= w) sx = w - 1
                    val value = rowF[k][sx].toInt() and 0xFF
                    val dd = value - r
                    val wt = lut[if (dd < 0) -dd else dd]
                    if (wt == 0) continue
                    sum += wt * value
                    ws += wt
                    if (chroma) {
                        var ccx = sx shr 1
                        if (ccx >= cw) ccx = cw - 1
                        su += wt * (uF[k][ccx].toInt() and 0xFF)
                        sv += wt * (vF[k][ccx].toInt() and 0xFF)
                    }
                }
                out[ro + x] = (sum / ws).toByte()
                if (chroma) {
                    val o = wh + (y shr 1) * w + (x shr 1) * 2
                    out[o] = (sv / ws).toByte()
                    out[o + 1] = (su / ws).toByte()
                }
            }
        }
    }

    // colour noise is the blotchy kind: blur the colour channels a little (3x3, 75% strength)
    private fun smoothChroma(out: ByteArray, w: Int, h: Int) {
        val cw = w / 2
        val ch = h / 2
        val base = w * h
        val src = out.copyOfRange(base, out.size)
        for (cy in 0 until ch) {
            val y0 = if (cy > 0) cy - 1 else 0
            val y1 = if (cy < ch - 1) cy + 1 else ch - 1
            for (cx in 0 until cw) {
                val x0 = if (cx > 0) cx - 1 else 0
                val x1 = if (cx < cw - 1) cx + 1 else cw - 1
                var sv = 0
                var su = 0
                for (yy in y0..y1) {
                    for (xx in x0..x1) {
                        val o = yy * w + xx * 2
                        sv += src[o].toInt() and 0xFF
                        su += src[o + 1].toInt() and 0xFF
                    }
                }
                val cnt = (y1 - y0 + 1) * (x1 - x0 + 1)
                val cv = src[cy * w + cx * 2].toInt() and 0xFF
                val cu = src[cy * w + cx * 2 + 1].toInt() and 0xFF
                val o = base + cy * w + cx * 2
                out[o] = ((cv + 3 * (sv / cnt)) / 4).toByte()
                out[o + 1] = ((cu + 3 * (su / cnt)) / 4).toByte()
            }
        }
    }

    private fun nv21ToJpeg(nv: ByteArray, w: Int, h: Int): ByteArray {
        val bos = ByteArrayOutputStream(nv.size / 2)
        YuvImage(nv, ImageFormat.NV21, w, h, null).compressToJpeg(Rect(0, 0, w, h), 97, bos)
        return bos.toByteArray()
    }

    // the camera normally writes the orientation; for our own JPEG we add it (and basic details)
    private fun tagJpeg(jpeg: ByteArray, orient: Int): ByteArray {
        return try {
            val f = File.createTempFile("proc", ".jpg", cacheDir)
            try {
                f.writeBytes(jpeg)
                val ex = ExifInterface(f.absolutePath)
                ex.setAttribute("Orientation", when (orient) { 90 -> "6"; 180 -> "3"; 270 -> "8"; else -> "1" })
                ex.setAttribute("Make", Build.MANUFACTURER)
                ex.setAttribute("Model", Build.MODEL)
                ex.setAttribute("Software", "MyCam multi-frame")
                val now = java.text.SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).format(java.util.Date())
                ex.setAttribute("DateTimeOriginal", now)
                ex.setAttribute("DateTime", now)
                ex.saveAttributes()
                f.readBytes()
            } finally {
                f.delete()
            }
        } catch (e: Exception) {
            jpeg
        }
    }

    private fun captureStill() {
        val d = device ?: return
        val s = session ?: return
        val r = reader ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(r.surface)
            applyCommon(b)
            if (procOn || halBoost) applyQuality(b)
            if (halBoost) applyHalBoost(b)
            b.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation())
            b.set(CaptureRequest.JPEG_QUALITY, 97.toByte())
            val isFront = front
            selfieShot = isFront
            selfieRot = devRot
            if (isFront) {
                // what the preview shows right now, to compare with the JPEG that comes back
                runOnUiThread {
                    selfieRef = try { texture.getBitmap(48, 64) } catch (e: Exception) { null }
                }
            }
            s.capture(b.build(), if (halBoost) halCb else null, bg)
            runOnUiThread {
                flashOverlay.animate().cancel()
                flashOverlay.alpha = 0.75f
                flashOverlay.animate().alpha(0f).setDuration(170).start()
            }
        } catch (e: Exception) {
            toast("Capture failed: ${e.message}")
        }
    }

    // ---- experiment: switch on the phone's own multi-frame / HDR engine through its vendor settings ----
    private val halKeys = listOf(
        "com.mediatek.mfnrfeature.mfbmode",
        "xiaomi.mfnr.enabled",
        "com.xiaomi.algo.mfnrEnable",
        "xiaomi.hdr.enabled",
        "xiaomi.ai.asd.enabled",
        "xiaomi.colorenhancement.enabled",
        "com.mediatek.control.capture.highQualityYuv"
    )
    private val halProbeKeys = listOf(
        "xiaomi.multiframe.inputNum",
        "xiaomi.hdr.hdrDetected",
        "xiaomi.snapshot.shotType",
        "xiaomi.supernight.enabled",
        "xiaomi.ai.asd.sceneDetected"
    )

    // the type of a vendor setting isn't known here, so try a whole number first, then a single byte
    private fun setVendor(b: CaptureRequest.Builder, name: String): Boolean {
        try { b.set(CaptureRequest.Key(name, Int::class.javaObjectType), 1); return true } catch (e: Exception) {}
        try { b.set(CaptureRequest.Key(name, Byte::class.javaObjectType), 1.toByte()); return true } catch (e: Exception) {}
        return false
    }

    private fun applyHalBoost(b: CaptureRequest.Builder) {
        val l = cur ?: return
        val avail = lcOf(l.logicalId).availableCaptureRequestKeys.map { it.name }.toSet()
        val ok = ArrayList<String>()
        for (name in halKeys) {
            if (name in avail && setVendor(b, name)) ok.add(name.substringAfterLast('.'))
        }
        lastHalSet = if (ok.isEmpty()) "nothing accepted" else ok.joinToString(", ")
    }

    private fun readVendor(r: TotalCaptureResult, name: String): String? {
        try { r.get(CaptureResult.Key(name, Int::class.javaObjectType))?.let { return it.toString() } } catch (e: Exception) {}
        try { r.get(CaptureResult.Key(name, Byte::class.javaObjectType))?.let { return it.toString() } } catch (e: Exception) {}
        try { r.get(CaptureResult.Key(name, Float::class.javaObjectType))?.let { return it.toString() } } catch (e: Exception) {}
        try { r.get(CaptureResult.Key(name, IntArray::class.java))?.let { return it.joinToString("/") } } catch (e: Exception) {}
        return null
    }

    private val halCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
            val sb = StringBuilder()
            for (name in halKeys + halProbeKeys) {
                val v = readVendor(result, name)
                if (v != null) sb.append(name.substringAfterLast('.')).append('=').append(v).append("  ")
            }
            lastHalResult = if (sb.isEmpty()) "no vendor values returned" else sb.toString().trim()
        }
    }

    private fun savePhoto(bytes0: ByteArray) {
        runOnUiThread { hideScreenFlash() }
        savePhoto(bytes0, selfieShot, selfieRot, selfieRef, true)
    }

    private fun savePhoto(bytes0: ByteArray, selfie: Boolean, srot: Int, sref: Bitmap?, clear: Boolean) {
        var bytes = bytes0
        if (selfie) {
            if (clear) selfieShot = false
            try {
                bytes = fixSelfieMirror(bytes0, sref, srot)
            } catch (e: Throwable) {
            }
            if (clear) selfieRef = null
        }
        val cv = ContentValues()
        cv.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MyCam")
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) { toast("Could not save photo"); return }
        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        setThumb(uri)
    }

    // ---- front photos follow the "Mirror front camera" setting ----
    // This phone's camera can deliver selfies already mirrored, so instead of guessing, the JPEG is
    // compared with the live preview captured at the same moment and flipped only when needed:
    // setting on = the photo looks like the mirrored preview, off = like the plain (true) view.
    private fun fixSelfieMirror(src: ByteArray, ref: Bitmap?, rot: Int): ByteArray {
        var t = 1 // which flip of the JPEG looks like the plain preview: 0 none, 1 left-right, 2 top-bottom, 3 both
        if (ref != null) {
            // the preview in the picture's own (upright) frame: the screen was turned by how the phone was held
            val pu = rotateBmp(ref, rot)
            val cw = pu.width
            val ch = pu.height
            val small = decodeSmall(src, cw, ch)
            if (small != null) {
                val p = lum(pu)
                val a = lum(small)
                val cands = arrayOf(a, flipH(a, cw, ch), flipV(a, cw, ch), flipV(flipH(a, cw, ch), cw, ch))
                var best = 0
                var bestS = -2f
                var second = -2f
                for (i in cands.indices) {
                    val sc = ncc(cands[i], p)
                    if (sc > bestS) {
                        second = bestS
                        bestS = sc
                        best = i
                    } else if (sc > second) {
                        second = sc
                    }
                }
                if (bestS - second > 0.04f) t = best
            }
        }
        // wanted: the plain view with the setting off, the left-right mirrored view with it on
        val needH = ((t == 1 || t == 3) != mirrorFront)
        val needV = (t == 2 || t == 3)
        return if (needH || needV) flipJpeg(src, needH, needV) else src
    }

    private fun rotateBmp(bm: Bitmap, deg: Int): Bitmap {
        if (deg == 0) return bm
        val m = Matrix()
        m.postRotate(deg.toFloat())
        return Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, m, true)
    }

    private fun decodeSmall(src: ByteArray, tw: Int, th: Int): Bitmap? = try {
        val bm = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(src))) { d, _, _ ->
            d.setTargetSampleSize(8)
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        Bitmap.createScaledBitmap(bm, tw, th, true)
    } catch (e: Exception) {
        null
    }

    private fun lum(bm: Bitmap): FloatArray {
        val w = bm.width
        val h = bm.height
        val px = IntArray(w * h)
        bm.getPixels(px, 0, w, 0, 0, w, h)
        val out = FloatArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            out[i] = 0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF)
        }
        return out
    }

    private fun flipH(a: FloatArray, w: Int, h: Int): FloatArray {
        val o = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) o[y * w + x] = a[y * w + (w - 1 - x)]
        return o
    }

    private fun flipV(a: FloatArray, w: Int, h: Int): FloatArray {
        val o = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) o[y * w + x] = a[(h - 1 - y) * w + x]
        return o
    }

    private fun ncc(a: FloatArray, b: FloatArray): Float {
        var ma = 0f
        var mb = 0f
        for (i in a.indices) {
            ma += a[i]
            mb += b[i]
        }
        ma /= a.size
        mb /= b.size
        var sab = 0f
        var saa = 0f
        var sbb = 0f
        for (i in a.indices) {
            val x = a[i] - ma
            val y = b[i] - mb
            sab += x * y
            saa += x * x
            sbb += y * y
        }
        val den = kotlin.math.sqrt(saa * sbb)
        return if (den > 1e-3f) sab / den else 0f
    }

    // mirror the picture left-right (EXIF rotation is applied by the decoder, so the result is upright)
    private fun flipJpeg(src: ByteArray, h: Boolean, v: Boolean): ByteArray {
        val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(src))) { d, _, _ ->
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        val m = Matrix()
        m.preScale(if (h) -1f else 1f, if (v) -1f else 1f)
        val flipped = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, false)
        bmp.recycle()
        val bos = ByteArrayOutputStream(src.size + 65536)
        flipped.compress(Bitmap.CompressFormat.JPEG, 97, bos)
        flipped.recycle()
        return copyExif(src, bos.toByteArray())
    }

    // keep the capture details (time, exposure, ...) of the original in the flipped file
    private fun copyExif(orig: ByteArray, flipped: ByteArray): ByteArray {
        return try {
            val a = File.createTempFile("orig", ".jpg", cacheDir)
            val b = File.createTempFile("flip", ".jpg", cacheDir)
            try {
                a.writeBytes(orig)
                b.writeBytes(flipped)
                val from = ExifInterface(a.absolutePath)
                val to = ExifInterface(b.absolutePath)
                for (t in listOf(
                    "DateTime", "DateTimeOriginal", "DateTimeDigitized", "Make", "Model", "FNumber",
                    "ExposureTime", "FocalLength", "Flash", "WhiteBalance", "PhotographicSensitivity"
                )) {
                    val v = from.getAttribute(t)
                    if (v != null) to.setAttribute(t, v)
                }
                to.setAttribute("Orientation", "1")
                to.saveAttributes()
                b.readBytes()
            } finally {
                a.delete()
                b.delete()
            }
        } catch (e: Exception) {
            flipped
        }
    }

    private fun setThumb(uri: Uri) {
        lastUri = uri
        bg.post {
            try {
                val bm = contentResolver.loadThumbnail(uri, Size(200, 200), null)
                runOnUiThread {
                    thumb.setImageBitmap(bm)
                    thumb.scaleX = 0.5f
                    thumb.scaleY = 0.5f
                    thumb.animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(OvershootInterpolator(2.2f)).start()
                }
            } catch (e: Exception) {
            }
        }
    }

    // ================= video =================

    private fun abortRecorder() {
        try { recorder?.reset() } catch (e: Exception) {}
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        videoUri?.let { try { contentResolver.delete(it, null, null) } catch (e: Exception) {} }
        videoUri = null
        recording = false
        ui.removeCallbacks(recTick)
        recTv.visibility = View.GONE
        shutter.setState(mode == 1, false)
        setChromeHidden(false)
    }

    private fun startRecording() {
        fpsProbing = false
        val d = device ?: return
        val ps = previewSurface ?: return
        val o = vidOpts.getOrNull(vidIdx) ?: return
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/MyCam")
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        val pfd = if (uri != null) contentResolver.openFileDescriptor(uri, "w") else null
        if (pfd == null) { toast("Could not create video file"); return }
        // HEVC gives a cleaner picture at the same bitrate; if the phone refuses it, fall back to H.264
        var made: MediaRecorder? = null
        var recErr: Exception? = null
        // order: HEVC + rich audio, HEVC + plain audio, H.264 + rich audio, H.264 + plain audio
        for (attempt in 0..3) {
            val hevc = attempt < 2
            val rich = attempt % 2 == 0
            val cand = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            try {
                // the camcorder microphone points the way the camera does and is processed less than the
                // plain one: crisp, with the wind still audible
                cand.setAudioSource(if (rich) MediaRecorder.AudioSource.CAMCORDER else MediaRecorder.AudioSource.MIC)
                cand.setVideoSource(MediaRecorder.VideoSource.SURFACE)
                cand.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                cand.setOutputFile(pfd.fileDescriptor)
                cand.setVideoEncodingBitRate(o.bitrate)
                cand.setVideoFrameRate(o.fps)
                cand.setVideoSize(o.w, o.h)
                cand.setVideoEncoder(if (hevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
                cand.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                if (rich) {
                    cand.setAudioChannels(2)
                    cand.setAudioSamplingRate(48000)
                    cand.setAudioEncodingBitRate(192000)
                }
                cand.setOrientationHint(jpegOrientation())
                cand.prepare()
                made = cand
                break
            } catch (e: Exception) {
                recErr = e
                try { cand.release() } catch (x: Exception) {}
            }
        }
        val r = made
        if (r == null) {
            toast("Recorder error: ${recErr?.message}")
            pfd.close()
            if (uri != null) try { contentResolver.delete(uri, null, null) } catch (x: Exception) {}
            return
        }
        recorder = r
        recPfd = pfd
        videoUri = uri
        makeSession(d, listOf(ps, r.surface), listOf(ps, r.surface), CameraDevice.TEMPLATE_RECORD) {
            runOnUiThread {
                try {
                    r.start()
                    recording = true
                    recStart = SystemClock.elapsedRealtime()
                    recTv.alpha = 0f
                    recTv.visibility = View.VISIBLE
                    recTv.animate().alpha(1f).setDuration(250).start()
                    shutter.setState(true, true)
                    setChromeHidden(true)
                    ui.post(recTick)
                } catch (e: Exception) {
                    toast("Start failed: ${e.message}")
                    abortRecorder()
                }
            }
        }
    }

    private fun stopRecording(restart: Boolean) {
        try { session?.stopRepeating() } catch (e: Exception) {}
        try { session?.abortCaptures() } catch (e: Exception) {}
        var saved = true
        try { recorder?.stop() } catch (e: RuntimeException) { saved = false; toast("Recording too short") }
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recording = false
        ui.removeCallbacks(recTick)
        recTv.visibility = View.GONE
        shutter.setState(mode == 1, false)
        setChromeHidden(false)
        if (saved) videoUri?.let { setThumb(it) }
        if (restart) startPreview()
    }

    // ================= zoom / focus =================

    private fun displayZoom(): Float {
        val w = wideLens()
        return if (w != null && cur === w) wideFactor() * zoom else zoom * nativeScale()
    }

    private fun fmtZ(z: Float): String {
        val s = String.format(Locale.US, "%.1f", z)
        return if (s.endsWith(".0")) s.dropLast(2) else s
    }

    private fun animateZoom(target: Float) {
        zoomAnim?.cancel()
        val a = ValueAnimator.ofFloat(zoom, target)
        a.duration = 380
        a.interpolator = ios
        a.addUpdateListener {
            zoom = it.animatedValue as Float
            updateRepeating()
            refreshZoomChips()
        }
        a.start()
        zoomAnim = a
    }

    // Hold the zoom pill: a dial replaces it and sliding along it zooms in small steps.
    private fun startDial() {
        if (zoomChips.isEmpty() || sheet.tag == true || dialActive) return
        val m = baseLens()
        val ns = nativeScale()
        zoomDial.extraMajor = if (front && wideLens() != null) wideFactor() else if (ns < 0.95f) ns else 0f
        zoomDial.minV = if (wideLens() != null && !logicalWide()) wideFactor() else (m?.let { zoomRangeOf(it).lower * ns } ?: 1f)
        zoomDial.maxV = m?.let { zoomRangeOf(it).upper * ns } ?: 10f
        zoomDial.value = displayZoom()
        dialActive = true
        dialLastX = Float.NaN
        zoomGlass.dialMode = true
        ui.removeCallbacks(hideDial)
        haptic(HapticFeedbackConstants.LONG_PRESS)
        val ty = zoomRow.bottom + zoomRow.translationY - dp(150) + dp(10)
        zoomDial.animate().cancel()
        zoomDial.alpha = 0f
        zoomDial.y = ty + dp(24)
        zoomDial.visibility = View.VISIBLE
        zoomDial.animate().alpha(1f).y(ty).setDuration(300).setInterpolator(ios).start()
        zoomRow.animate().cancel()
        zoomRow.animate().alpha(0f).setDuration(140).start()
    }

    private fun dialTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (!dialLastX.isNaN()) {
                    val dx = ev.rawX - dialLastX
                    val cz = displayZoom()
                    val target = exp(ln(cz) - dx / zoomDial.pxPerLn).coerceIn(zoomDial.minV, zoomDial.maxV)
                    pinchZoom(target / cz)
                    zoomDial.value = displayZoom()
                }
                dialLastX = ev.rawX
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endDial()
        }
    }

    // Touching anything outside the dial puts it away at once (it used to stay until you changed mode).
    private fun closeDial() {
        dialActive = false
        zoomGlass.dialMode = false
        ui.removeCallbacks(hideDial)
        ui.post(hideDial)
    }

    private fun touchHits(v: View, ev: MotionEvent): Boolean {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return ev.rawX >= loc[0] && ev.rawX <= loc[0] + v.width && ev.rawY >= loc[1] && ev.rawY <= loc[1] + v.height
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && ::zoomDial.isInitialized &&
            (dialActive || zoomDial.visibility == View.VISIBLE) &&
            !touchHits(zoomGlass, ev)
        ) {
            closeDial()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun endDial() {
        if (!dialActive) return
        dialActive = false
        zoomGlass.dialMode = false
        ui.removeCallbacks(hideDial)
        ui.postDelayed(hideDial, 800)
    }

    // Pinching is one continuous zoom from 0.6x to 10x. The ultrawide covers 0.6x-1x, the main
    // lens everything above; 2x is a crop of the main sensor (there is no separate 2x lens),
    // so it gets a tick and a gentle snap instead of a lens switch.
    private fun pinchZoom(factor: Float) {
        val c = cur ?: return
        val m = baseLens()
        val u = wideLens()
        val wf = wideFactor()
        val onUltra = u != null && c === u
        val r = zoomRangeOf(c)
        if (m == null || u == null || logicalWide()) {
            zoom = (zoom * factor).coerceIn(r.lower, r.upper)
            updateRepeating()
            refreshZoomChips()
            return
        }
        val mr = zoomRangeOf(m)
        val ur = zoomRangeOf(u)
        var vz = (displayZoom() * factor).coerceIn(wf * ur.lower, mr.upper)
        if (abs(vz - 2f) < 0.05f) {
            if (!snapNear) {
                snapNear = true
                haptic(HapticFeedbackConstants.CLOCK_TICK)
            }
            vz = 2f
        } else {
            snapNear = false
        }
        val ultraZoom = (vz / wf).coerceIn(ur.lower, ur.upper)
        val mainZoom = vz.coerceIn(mr.lower, mr.upper)
        if (recording) {
            // lenses can't be swapped while recording: keep zooming on the current one
            zoom = if (onUltra) ultraZoom else mainZoom
            updateRepeating()
            refreshZoomChips()
            return
        }
        val wantUltra = if (onUltra) vz < 1f else vz < 0.98f
        if (wantUltra != onUltra) {
            if (!lensSwitching) switchLens(if (wantUltra) u else m, if (wantUltra) ultraZoom else mainZoom)
            return
        }
        zoom = if (onUltra) ultraZoom else mainZoom
        updateRepeating()
        refreshZoomChips()
    }

    private fun switchLens(target: Lens, newZoom: Float) {
        lensSwitching = true
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        tapRegion = null
        zoomAnim?.cancel()
        cur = target
        zoom = newZoom
        fadeOutStage()
        reopen(false)
        refreshZoomChips()
    }

    private fun selectZoom(v: Float) {
        if (recording && !logicalWide()) return
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        tapRegion = null
        val wl = wideLens()
        if (wl != null && v < 0.95f && !logicalWide()) {
            if (cur !== wl) {
                zoomAnim?.cancel()
                cur = wl
                zoom = 1f
                fadeOutStage()
                reopen()
            }
        } else {
            val c = cur ?: return
            val m = baseLens()
            if (wl != null && c === wl && m != null && c !== m) {
                zoomAnim?.cancel()
                cur = m
                zoom = v
                fadeOutStage()
                reopen()
            } else {
                val r = zoomRangeOf(c)
                animateZoom((v / nativeScale()).coerceIn(r.lower, r.upper))
            }
        }
        refreshZoomChips()
    }

    private fun buildZoomChips() {
        zoomRow.removeAllViews()
        zoomChips.clear()
        val m = baseLens()
        if (m == null) { zoomRow.visibility = View.GONE; return }
        val sheetOpen = sheet.tag == true
        zoomRow.visibility = if (sheetOpen) View.INVISIBLE else View.VISIBLE
        zoomRow.alpha = if (sheetOpen) 0f else 1f
        slideAnim?.cancel()
        pillSlide = if (sheetOpen) pillDist() else 0f
        applyPillY()
        val r = zoomRangeOf(m)
        val ns = nativeScale()
        val lowDisp = r.lower * ns
        val vals = mutableListOf<Float>()
        if (lowDisp < 0.95f) vals.add(lowDisp) else if (wideLens() != null) vals.add(wideFactor())
        vals.add(1f)
        if (r.upper * ns >= 2f) vals.add(2f)
        for (v in vals) {
            val tv = TextView(this)
            tv.textSize = 12.5f
            tv.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            tv.gravity = Gravity.CENTER
            tv.rotation = uiAngle
            tv.setOnClickListener { selectZoom(v) }
            pressable(tv, 0.88f)
            val lp = LinearLayout.LayoutParams(dp(42), dp(42))
            lp.leftMargin = dp(2)
            lp.rightMargin = dp(2)
            zoomRow.addView(tv, lp)
            zoomChips.add(Pair(tv, v))
        }
        refreshZoomChips()
    }

    // the active button shows the live zoom factor, like the iPhone camera
    private fun refreshZoomChips() {
        if (zoomChips.isEmpty()) return
        val dz = displayZoom()
        var activeIdx = 0
        for ((i, pr) in zoomChips.withIndex()) {
            if (dz >= pr.second - 0.04f) activeIdx = i
        }
        for ((i, pr) in zoomChips.withIndex()) {
            val tv = pr.first
            val v = pr.second
            val active = i == activeIdx
            tv.text = if (active) fmtZ(dz) + "\u00D7" else if (v < 1f) fmtZ(v).removePrefix("0") else fmtZ(v)
            if (tv.tag != active) {
                tv.tag = active
                tv.setTextColor(if (active) accent else Color.WHITE)
                tv.background = oval(if (active) Color.parseColor("#B0000000") else Color.TRANSPARENT)
                val s = if (active) 1.1f else 0.86f
                tv.animate().scaleX(s).scaleY(s).setDuration(220).setInterpolator(ios).start()
            }
        }
    }

    // Inside the viewfinder (14dp above its bottom edge) when the viewfinder ends above the controls,
    // as in 4:3; above the mode row when the viewfinder runs behind them, as in 16:9 and video.
    private fun applyPillY() {
        zoomRow.translationY = pillBase + pillSlide
    }

    private fun positionZoomPill(animate: Boolean) {
        val rootH = rootView.height
        val panelH = panelView.height
        if (rootH == 0 || panelH == 0) return
        val lp = stage.layoutParams as FrameLayout.LayoutParams
        val stageBottom = lp.topMargin + lp.height
        val layoutBottom = rootH - panelH - dp(6)
        val sideways = devRot == 90 || devRot == 270
        val proH = if (proSheet.tag == true && proSheet.visibility == View.VISIBLE) {
            if (sideways) (proSheet.width * hostScale).toInt() + dp(8) else proSheet.height + dp(8)
        } else 0
        val baseBottom = layoutBottom - proH
        val desired = min(baseBottom, stageBottom - dp(14))
        val target = (desired - layoutBottom).toFloat()
        pillAnim?.cancel()
        if (!animate || abs(target - pillBase) < 1f) {
            pillBase = target
            applyPillY()
            return
        }
        val a = ValueAnimator.ofFloat(pillBase, target)
        a.duration = 320
        a.interpolator = ios
        a.addUpdateListener {
            pillBase = it.animatedValue as Float
            applyPillY()
        }
        a.start()
        pillAnim = a
    }

    private fun pillDist() = dp(48).toFloat()

    // The pill drops out of the way when the menu opens. Once the menu has mostly gone it rises
    // back from the bottom with a soft spring. Nothing else moves the pill meanwhile: its resting
    // position ignores the settings sheet.
    private fun fadePill(show: Boolean) {
        if (zoomChips.isEmpty()) return
        slideAnim?.cancel()
        val dist = pillDist()
        if (show) zoomRow.visibility = View.VISIBLE
        val a = ValueAnimator.ofFloat(pillSlide, if (show) 0f else dist)
        if (show) {
            a.startDelay = 140
            a.duration = 560L
            a.interpolator = OvershootInterpolator(0.9f)
        } else {
            a.duration = 220L
            a.interpolator = DecelerateInterpolator(1.4f)
        }
        a.addUpdateListener {
            pillSlide = it.animatedValue as Float
            zoomRow.alpha = ((1f - pillSlide / dist) * 1.8f).coerceIn(0f, 1f)
            applyPillY()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (!show && sheet.tag == true) zoomRow.visibility = View.INVISIBLE
            }
        })
        a.start()
        slideAnim = a
    }

    private fun evOffsetPx(): Float {
        val l = cur ?: return 0f
        val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: return 0f
        if (er.upper <= er.lower) return 0f
        val frac = (ev - er.lower).toFloat() / (er.upper - er.lower).toFloat()
        return (0.5f - frac) * dp(80)
    }

    private fun positionSun() {
        val right = fx + dp(52) + dp(28) < stage.width
        val sx = if (right) fx + dp(52) else fx - dp(52) - dp(26)
        sunIcon.x = sx
        sunIcon.y = fy - dp(13) + evOffsetPx()
        focusLine.x = sx + dp(13) - dp(1)
        focusLine.y = fy - dp(44)
    }

    private fun scheduleFocusHide() {
        ui.removeCallbacks(hideFocus)
        ui.postDelayed(hideFocus, 3500)
    }

    private fun dragEv(dy: Float) {
        val l = cur ?: return
        val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: return
        if (er.upper <= er.lower) return
        evAccum += dy
        val unit = dp(10).toFloat()
        val steps = (evAccum / unit).toInt()
        if (steps != 0) {
            evAccum -= steps * unit
            ev = (ev + steps).coerceIn(er.lower, er.upper)
            evSeek.progress = ev - er.lower
            updateEvLabel()
            updateRepeating()
            positionSun()
        }
        scheduleFocusHide()
    }

    // one real refocus at the tapped spot (continuous focus alone only re-aims, it does not always re-scan)
    private fun triggerAf() {
        if (recording || extSession != null) return
        val d = device ?: return
        val sess = session ?: return
        try {
            val b = buildRepeating(d)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
            sess.capture(b.build(), null, bg)
        } catch (e: Exception) {
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val l = cur ?: return
        val w = stage.width.toFloat()
        val h = stage.height.toFloat()
        if (w <= 0f || h <= 0f) return
        var vx = x / w
        var vy = y / h
        if (front && mirrorFront) {
            if (devRot == 90 || devRot == 270) vy = 1f - vy else vx = 1f - vx
        }
        val a = lcOf(l.logicalId).get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        val sx: Float
        val sy: Float
        when (sensorOri()) {
            90 -> { sx = vy; sy = 1f - vx }
            270 -> { sx = 1f - vy; sy = vx }
            180 -> { sx = 1f - vx; sy = 1f - vy }
            else -> { sx = vx; sy = vy }
        }
        val px = a.left + (sx * a.width()).toInt()
        val py = a.top + (sy * a.height()).toInt()
        val half = (min(a.width(), a.height()) * 0.08f).toInt()
        val rect = Rect(
            max(a.left, px - half), max(a.top, py - half),
            min(a.right - 1, px + half), min(a.bottom - 1, py + half)
        )
        tapRegion = MeteringRectangle(rect, MeteringRectangle.METERING_WEIGHT_MAX - 1)
        // a new tap starts the exposure from scratch, like the iPhone: compensation back to zero
        val er0 = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        if (er0 != null && er0.upper > er0.lower && ev != 0) {
            ev = 0
            evSeek.progress = 0 - er0.lower
            updateEvLabel()
        }
        updateRepeating()
        triggerAf()
        haptic(HapticFeedbackConstants.CLOCK_TICK)

        fx = x
        fy = y
        focusActive = true
        evAccum = 0f
        val size = dp(76)
        focusBox.animate().cancel()
        focusBox.x = x - size / 2f
        focusBox.y = y - size / 2f
        focusBox.alpha = 1f
        focusBox.scaleX = 1.4f
        focusBox.scaleY = 1.4f
        focusBox.visibility = View.VISIBLE
        focusBox.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(ios).start()
        for (v in listOf<View>(focusLine, sunIcon)) {
            v.animate().cancel()
            v.alpha = 0f
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(220).start()
        }
        positionSun()
        scheduleFocusHide()
    }

    // ================= settings / state =================

    private fun refreshCaps() {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        hasFlash = lc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        if (front && flashMode == 3) flashMode = 0
        if (!hasFlash && !front) flashMode = 0
        updateFlashChip()
        applyPeaking()
        hdrSupported = lc.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)
            ?.contains(CameraMetadata.CONTROL_SCENE_MODE_HDR) == true
        updateSheetRows()
        val er = lc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = lc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        evRow.visibility = if (er.upper > er.lower) View.VISIBLE else View.GONE
        evSeek.max = er.upper - er.lower
        ev = ev.coerceIn(er.lower, er.upper)
        evSeek.progress = ev - er.lower
        updateEvLabel()
        updateProLabels()
        updateFlashChip()
        updateStabUi()
    }

    // photo buttons in photo/pro, video quality in video
    private fun updateSheetRows() {
        if (!::menuGrid.isInitialized) return
        val video = mode == 1
        tileRatio.visibility = if (video) View.GONE else View.VISIBLE
        tilePhoto.visibility = if (video) View.GONE else View.VISIBLE
        tileProc.visibility = if (video) View.GONE else View.VISIBLE
        tileVideo.visibility = if (video) View.VISIBLE else View.GONE
        tileHdr.visibility = if (hdrSupported && !video) View.VISIBLE else View.GONE
        tileX.visibility = if (mode == 0) View.VISIBLE else View.GONE
        // a pinned control lives in the top row only: it leaves the menu until it is taken off again
        pinApplies["hdr"] = tileHdr.visibility != View.GONE
        pinApplies["enhance"] = tileProc.visibility != View.GONE
        pinApplies["ratio"] = tileRatio.visibility != View.GONE
        for (k in listOf("grid", "level", "cross", "mirror")) {
            pinApplies[k] = true
            pinTile(k)?.visibility = View.VISIBLE
        }
        for (k in pinKeys) pinTile(k)?.visibility = View.GONE
        val gone = when (detailKey) {
            "ratio", "photo" -> video
            "video" -> !video
            else -> false
        }
        if (gone) hideDetail()
        menuGrid.requestLayout()
        refreshMenu(false)
    }

    // every button shows its current state: lit when on, the current value for multi-option ones
    private fun pinTile(key: String): MenuTile? = when (key) {
        "hdr" -> tileHdr
        "enhance" -> tileProc
        "ratio" -> tileRatio
        "grid" -> tileGridLines
        "level" -> tileLevel
        "cross" -> tileCross
        "mirror" -> tileMirror
        else -> null
    }

    private fun pinKind(key: String) = when (key) {
        "hdr" -> 5
        "enhance" -> 2
        "ratio" -> 0
        "grid" -> 6
        "level" -> 8
        "cross" -> 9
        else -> 7
    }

    private fun pinOn(key: String) = when (key) {
        "hdr" -> hdr
        "enhance" -> procOn
        "grid" -> gridOn
        "level" -> levelOn
        "cross" -> crossOn
        "mirror" -> mirrorFront
        else -> false
    }

    private fun pinToggle(key: String) {
        when (key) {
            "hdr" -> hdrSeg.choose(if (hdr) 0 else 1)
            "enhance" -> procSeg.choose(if (procOn) 0 else 1)
            "ratio" -> ratioSeg.choose(if (ratio43) 1 else 0)
            "grid" -> gridSeg.choose(if (gridOn) 0 else 1)
            "level" -> levelSeg.choose(if (levelOn) 0 else 1)
            "cross" -> crossSeg.choose(if (crossOn) 0 else 1)
            "mirror" -> mirrorSeg.choose(if (mirrorFront) 0 else 1)
        }
    }

    private fun togglePin(key: String) {
        haptic(HapticFeedbackConstants.LONG_PRESS)
        if (key in pinKeys) {
            pinKeys.remove(key)
            toast("Taken off the top row")
        } else {
            if (pinKeys.size >= 2) pinKeys.removeAt(0)
            pinKeys.add(key)
            toast("Pinned to the top row")
        }
        prefs.edit().putString("pins", pinKeys.joinToString(",")).apply()
        rebuildPins()
    }

    private fun rebuildPins() {
        pinHost1.removeAllViews()
        pinHost2.removeAllViews()
        pinBtns.clear()
        pinViews.clear()
        for ((i, key) in pinKeys.withIndex()) {
            val icon = TileIcon(this, pinKind(key), accent)
            val wrap = FrameLayout(this)
            wrap.addView(icon, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
            pressable(wrap, 0.9f)
            wrap.setOnClickListener {
                haptic(HapticFeedbackConstants.CLOCK_TICK)
                pinToggle(key)
                refreshPins()
            }
            wrap.setOnLongClickListener {
                togglePin(key)
                true
            }
            wrap.rotation = uiAngle
            (if (i == 0) pinHost1 else pinHost2).addView(wrap, FrameLayout.LayoutParams(-1, -1))
            pinBtns.add(Pair(key, icon))
            pinViews.add(wrap)
        }
        for (k in listOf("hdr", "enhance", "ratio", "grid", "level", "cross", "mirror")) pinTile(k)?.pinned = k in pinKeys
        updateSheetRows()
        refreshPins()
    }

    private fun refreshPins() {
        for ((i, pr) in pinBtns.withIndex()) {
            val key = pr.first
            val icon = pr.second
            icon.setOn(pinOn(key), false)
            if (key == "ratio") icon.wide = !ratio43
            pinViews[i].visibility = if (pinApplies[key] == false) View.GONE else View.VISIBLE
        }
    }

    private fun refreshMenu(animate: Boolean = true) {
        if (!::menuGrid.isInitialized) return
        tileRatio.icon.wide = !ratio43
        tileRatio.setState(false, if (ratio43) "4:3" else "16:9", animate)
        val mp = megapixels(photoSize)
        tilePhoto.icon.value = mp.toString()
        tilePhoto.setState(false, "$mp MP", animate)
        tileProc.setState(procOn, "Enhance", animate)
        tileX.setState(halBoost, "HAL boost", animate)
        tileX.visibility = if (mode == 0) View.VISIBLE else View.GONE
        val o = vidOpts.getOrNull(vidIdx)
        tileVideo.icon.value = if (o == null) "" else if (o.h >= 2160) "4K" else o.h.toString()
        tileVideo.icon.sub = o?.fps?.toString() ?: ""
        tileVideo.setState(false, o?.label ?: "Video", animate)
        val es = effStab()
        tileStab.setState(es > 0, stabNames[es], animate)
        tileHdr.setState(hdr, "HDR", animate)
        tileGridLines.setState(gridOn, "Grid", animate)
        tileLevel.setState(levelOn, "Level", animate)
        tileCross.setState(crossOn, "Crosshair", animate)
        tileMirror.setState(mirrorFront, "Mirror", animate)
        tileInfo.setState(false, "Info", animate)
        refreshPins()
        tileRatio.icon.ring = detailKey == "ratio"
        tilePhoto.icon.ring = detailKey == "photo"
        tileVideo.icon.ring = detailKey == "video"
        tileStab.icon.ring = detailKey == "stab"
    }

    private fun showDetail(key: String, title: String, seg: SegControl) {
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        if (detailKey == key) {
            hideDetail()
            return
        }
        (seg.parent as? ViewGroup)?.removeView(seg)
        detailBody.removeAllViews()
        detailBody.addView(seg, FrameLayout.LayoutParams(-1, -2))
        detailTitle.text = title.uppercase(Locale.US)
        detailKey = key
        refreshMenu(false)
        animateVisibility(detail, true)
    }

    private fun hideDetail() {
        if (detailKey.isEmpty()) return
        detailKey = ""
        refreshMenu(false)
        animateVisibility(detail, false)
    }

    // the buttons pop in one after another when the menu opens
    private fun staggerTiles() {
        var n = 0
        for (i in 0 until menuGrid.childCount) {
            val t = menuGrid.getChildAt(i)
            if (t.visibility == View.GONE) continue
            t.animate().cancel()
            t.alpha = 0f
            t.translationY = dp(10).toFloat()
            t.postDelayed({
                t.animate().alpha(1f).translationY(0f).setDuration(320).setInterpolator(ios).start()
            }, 40L + n * 24L)
            n++
        }
    }

    private fun updateEvLabel() {
        evLabel.text = "Exposure  " + String.format(Locale.US, "%+.1f", ev * evStep)
    }

    private fun fmtShutter(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/" + (1.0 / s).roundToInt()
    }

    private fun updateProLabels() {
        isoLabel.text = if (isoProg == 0) "Auto" else isoVal.toString()
        shutLabel.text = if (shutProg == 0) "Auto" else fmtShutter(expVal)
        wbLabel.text = wbNames[wbIdx.coerceIn(0, wbNames.size - 1)]
        focusLabel.text = if (focusProg == 0) "Auto" else "Manual"
    }

    private fun isoStops(): List<Int> {
        val l = cur ?: return listOf(100)
        val r = lcOf(l.logicalId).get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: return listOf(100)
        val hi = min(r.upper, 6400)
        return isoStd.filter { it >= r.lower && it <= hi }.ifEmpty { listOf(r.lower) }
    }

    private fun shutStops(): List<Long> {
        val l = cur ?: return listOf(16_666_667L)
        val r = lcOf(l.logicalId).get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: return listOf(16_666_667L)
        return shutStd.filter { it >= r.lower && it <= r.upper }.ifEmpty { listOf(r.lower) }
    }

    private fun proDialChanged(v: Int) {
        when (proSel) {
            0 -> if (v == 0) {
                isoProg = 0
                isoVal = 0
            } else {
                isoProg = v
                isoVal = isoStops()[v - 1]
            }
            1 -> if (v == 0) {
                shutProg = 0
                expVal = 0L
            } else {
                shutProg = v
                expVal = shutStops()[v - 1]
            }
            2 -> wbIdx = v
            else -> focusProg = v
        }
        updateProLabels()
        updateRepeating()
    }

    // puts the chosen value on the ruler and lights its card
    private fun selectPro(i: Int) {
        proSel = i
        proDial.lo = 0
        when (i) {
            0 -> {
                val st = isoStops()
                proDial.hi = st.size
                proDial.unitDp = 60f
                proDial.majorEvery = 1
                proDial.labelOf = { v: Int -> if (v == 0) "AUTO" else st[v - 1].toString() }
            }
            1 -> {
                val st = shutStops()
                proDial.hi = st.size
                proDial.unitDp = 60f
                proDial.majorEvery = 1
                proDial.labelOf = { v: Int -> if (v == 0) "AUTO" else fmtShutter(st[v - 1]) }
            }
            2 -> {
                proDial.hi = wbNames.size - 1
                proDial.unitDp = 72f
                proDial.majorEvery = 1
                proDial.labelOf = { v: Int -> wbNames.getOrElse(v) { "" } }
            }
            else -> {
                proDial.hi = 100
                proDial.unitDp = 7f
                proDial.majorEvery = 10
                proDial.labelOf = { v: Int ->
                    when (v) {
                        0 -> "AUTO"
                        1 -> "\u221E"
                        100 -> "NEAR"
                        else -> ""
                    }
                }
            }
        }
        syncProDial()
        for ((k, cell) in proCells.withIndex()) {
            val on = k == i
            cell.animate().alpha(if (on) 1f else 0.7f).setDuration(180).start()
            proCaps[k].setTextColor(if (on) accent else Color.parseColor("#99FFFFFF"))
            val cap = proBg[k]
            val va = ValueAnimator.ofInt(cap.alpha, if (on) 255 else 0)
            va.duration = 200
            va.addUpdateListener { cap.alpha = it.animatedValue as Int }
            va.start()
        }
    }

    private fun syncProDial() {
        val v = when (proSel) {
            0 -> if (isoProg == 0) 0 else isoStops().let { st -> (st.indices.minByOrNull { abs(st[it] - isoVal) } ?: 0) + 1 }
            1 -> if (shutProg == 0) 0 else shutStops().let { st -> (st.indices.minByOrNull { abs(st[it] - expVal) } ?: 0) + 1 }
            2 -> wbIdx
            else -> focusProg
        }
        proDial.setValue(v)
    }

    private fun applyPeaking() {
        val on = peakOn && mode == 2 && !front
        peaking.visibility = if (on) View.VISIBLE else View.GONE
        peaking.setActive(on)
        peakChip.setTextColor(if (peakOn) Color.parseColor("#1C1917") else Color.WHITE)
        peakChip.background = rounded(if (peakOn) accent else Color.parseColor("#26FFFFFF"), dp(18).toFloat())
    }

    private fun updateFlashChip() {
        val st = if (mode == 1) (if (torch) 2 else 0) else flashMode
        flashIcon.state = st
        flashIcon.tint = if (st != 0) accent else Color.WHITE
        flashSlot.visibility = if (flashAvailable()) View.VISIBLE else View.INVISIBLE
    }

    // the rear camera has a real flash; the front camera lights the screen in photo mode
    private fun flashAvailable() = if (mode == 1) hasFlash else (hasFlash || front)

    private fun animateVisibility(v: View, show: Boolean, animate: Boolean = true) {
        v.animate().cancel()
        v.tag = show
        if (!animate) {
            v.alpha = 1f
            v.translationY = 0f
            v.scaleX = 1f
            v.scaleY = 1f
            v.visibility = if (show) View.VISIBLE else View.GONE
            return
        }
        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.alpha = 0f
                v.translationY = dp(28).toFloat()
                v.scaleX = 0.94f
                v.scaleY = 0.94f
                v.visibility = View.VISIBLE
            }
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(340)
                .setInterpolator(ios).start()
        } else {
            v.animate().alpha(0f).translationY(dp(28).toFloat()).scaleX(0.96f).scaleY(0.96f)
                .setDuration(220).setInterpolator(ios)
                .withEndAction { if (v.tag == false) v.visibility = View.GONE }.start()
        }
    }

    private fun toggleSheet() {
        if (recording) return
        val show = sheet.visibility != View.VISIBLE || sheet.tag == false
        animateVisibility(sheet, show)
        if (show) {
            detailKey = ""
            detail.animate().cancel()
            detail.visibility = View.GONE
            detail.tag = false
            refreshMenu(false)
            staggerTiles()
        } else {
            hideDetail()
        }
        fadePill(!show)
        chevron.animate().rotation(uiAngle + (if (show) 180f else 0f)).setDuration(280).setInterpolator(ios).start()
        chevron.tint = if (show) accent else Color.WHITE
        haptic(HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun centerModeBar(animate: Boolean) {
        val tv = tabs[mode] ?: return
        if (modeBar.width == 0 || tv.width == 0) {
            modeBar.post { centerModeBar(false) }
            return
        }
        val target = modeBar.width / 2f - (tv.left + tv.width / 2f)
        if (animate) {
            modeRow.animate().translationX(target).setDuration(320).setInterpolator(ios).start()
        } else {
            modeRow.animate().cancel()
            modeRow.translationX = target
        }
    }

    private fun refreshModeUi(animate: Boolean) {
        for ((i, t) in tabs) {
            val sel = i == mode
            t.setTextColor(if (sel) accent else Color.WHITE)
            t.animate().alpha(if (sel) 1f else 0.7f).scaleX(if (sel) 1f else 0.92f)
                .scaleY(if (sel) 1f else 0.92f).setDuration(if (animate) 260L else 0L).start()
            val cap = tabBg[i]
            if (cap != null) {
                val to = if (sel) 255 else 0
                if (animate) {
                    val va = ValueAnimator.ofInt(cap.alpha, to)
                    va.duration = 260
                    va.addUpdateListener { cap.alpha = it.animatedValue as Int }
                    va.start()
                } else {
                    cap.alpha = to
                }
            }
        }
        shutter.setState(mode == 1, recording)
        animateVisibility(proSheet, mode == 2, animate)
        centerModeBar(animate)
        updateFlashChip()
        updateStabUi()
        updateSheetRows()
        applyPeaking()
    }

    private fun setMode(m: Int) {
        if (recording || counting || m == mode) return
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        mode = m
        tapRegion = null
        refreshModeUi(true)
        val l = cur ?: return
        pickSizes(l)
        if (device != null) {
            fadeOutStage()
            startPreview()
        }
    }

    private fun swipeMode(dir: Int) {
        val pos = modeOrder.indexOf(mode)
        val np = (pos + dir).coerceIn(0, modeOrder.size - 1)
        if (np != pos) setMode(modeOrder[np])
    }

    // mirroring is applied when the new camera's first frame arrives, so no stale frame flips
    private fun flipCamera() {
        if (recording) return
        val target = if (front) mainLens else frontLens
        if (target == null) { toast("No front camera found"); return }
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        flipSpin += 180f
        flipBtn.animate().rotation(uiAngle + flipSpin).setDuration(380).setInterpolator(ios).start()
        front = !front
        cur = target
        zoom = 1f
        tapRegion = null
        fadeOutStage(true)
        reopen()
    }

    // ================= ui building =================

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun pressable(v: View, s: Float = 0.9f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(s).scaleY(s).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun seekRow(label: TextView, seek: SeekBar): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        label.setTextColor(Color.WHITE)
        label.textSize = 13f
        r.addView(label, LinearLayout.LayoutParams(dp(120), -2))
        seek.progressTintList = ColorStateList.valueOf(accent)
        seek.thumbTintList = ColorStateList.valueOf(accent)
        r.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        return r
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val sw = resources.displayMetrics.widthPixels

        // ----- viewfinder -----
        stage = FrameLayout(this)
        stage.setBackgroundColor(Color.BLACK)
        stage.cameraDistance = 9000f * resources.displayMetrics.density
        stage.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(24).toFloat())
            }
        }
        stage.clipToOutline = true
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> stage.invalidateOutline() }

        texture = TextureView(this)
        stage.addView(texture, FrameLayout.LayoutParams(-1, -1))
        GlassSource.live = texture
        GlassSource.anchor = stage
        grid = CamGrid(this)
        grid.visibility = if (gridOn) View.VISIBLE else View.GONE
        stage.addView(grid, FrameLayout.LayoutParams(-1, -1))
        peaking = PeakingView(this, accent)
        peaking.source = texture
        peaking.visibility = View.GONE
        stage.addView(peaking, FrameLayout.LayoutParams(-1, -1))
        levelOverlay = LevelOverlay(this, accent)
        levelOverlay.visibility = View.GONE
        levelOverlay.onAligned = { haptic(HapticFeedbackConstants.CLOCK_TICK) }
        stage.addView(levelOverlay, FrameLayout.LayoutParams(-1, -1))
        flashOverlay = View(this)
        flashOverlay.setBackgroundColor(Color.BLACK)
        flashOverlay.alpha = 0f
        stage.addView(flashOverlay, FrameLayout.LayoutParams(-1, -1))

        focusBox = View(this)
        val boxBg = GradientDrawable()
        boxBg.shape = GradientDrawable.RECTANGLE
        boxBg.setColor(Color.TRANSPARENT)
        boxBg.setStroke(dp(2), accent)
        focusBox.background = boxBg
        focusBox.visibility = View.GONE
        stage.addView(focusBox, FrameLayout.LayoutParams(dp(76), dp(76)))
        focusLine = View(this)
        focusLine.setBackgroundColor(Color.parseColor("#99FFD60A"))
        focusLine.visibility = View.GONE
        stage.addView(focusLine, FrameLayout.LayoutParams(dp(2), dp(88)))
        sunIcon = CamIcon(this, 3)
        sunIcon.tint = accent
        sunIcon.visibility = View.GONE
        stage.addView(sunIcon, FrameLayout.LayoutParams(dp(26), dp(26)))

        countdownTv = TextView(this)
        countdownTv.setTextColor(Color.WHITE)
        countdownTv.textSize = 96f
        countdownTv.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        countdownTv.visibility = View.GONE
        stage.addView(countdownTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        recTv = TextView(this)
        recTv.setTextColor(Color.WHITE)
        recTv.textSize = 14f
        recTv.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        recTv.setPadding(dp(12), dp(5), dp(12), dp(5))
        recTv.background = rounded(Color.parseColor("#CCFF3B30"), dp(14).toFloat())
        recTv.visibility = View.GONE
        val rlp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        rlp.topMargin = dp(56)
        stage.addView(recTv, rlp)

        procTv = TextView(this)
        procTv.text = "Enhancing\u2026"
        procTv.setTextColor(Color.WHITE)
        procTv.textSize = 13f
        procTv.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        procTv.setPadding(dp(14), dp(6), dp(14), dp(6))
        procTv.background = rounded(Color.parseColor("#99000000"), dp(16).toFloat())
        procTv.visibility = View.GONE
        val plp0 = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        plp0.topMargin = dp(56)
        stage.addView(procTv, plp0)

        val slp = FrameLayout.LayoutParams(sw, sw * 4 / 3, Gravity.TOP)
        slp.topMargin = dp(52)
        root.addView(stage, slp)

        topScrim = View(this)
        topScrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#99000000"), Color.TRANSPARENT)
        )
        topScrim.alpha = 0f
        root.addView(topScrim, FrameLayout.LayoutParams(-1, dp(120), Gravity.TOP))

        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoomAnim?.cancel()
                pinchZoom(d.scaleFactor)
                return true
            }
        })
        val tapDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (sheet.visibility == View.VISIBLE && sheet.tag == true) {
                    toggleSheet()
                } else {
                    focusAt(e.x, e.y)
                }
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (focusActive && abs(dy) > abs(dx)) { dragEv(dy); return true }
                return false
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > 1200f && abs(vx) > abs(vy) * 1.5f) {
                    swipeMode(if (vx < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        stage.setOnTouchListener { _, ev ->
            scaleDet.onTouchEvent(ev)
            if (!scaleDet.isInProgress) tapDet.onTouchEvent(ev)
            true
        }

        // ----- top bar -----
        topBar = FrameLayout(this)
        flashIcon = CamIcon(this, 0)
        timerIcon = CamIcon(this, 1)
        chevron = CamIcon(this, 2)
        fun slot(icon: CamIcon, gravity: Int, margin: Int, glass: Boolean = true): FrameLayout {
            val f = FrameLayout(this)
            if (glass) {
                val g = GlassLinear(this, 22f, Color.parseColor("#661C1C1E"))
                g.gravity = Gravity.CENTER
                g.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)))
                f.addView(g, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
            } else {
                f.addView(icon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            }
            pressable(f, 0.9f)
            val lp = FrameLayout.LayoutParams(dp(48), dp(48), gravity or Gravity.CENTER_VERTICAL)
            lp.leftMargin = margin
            lp.rightMargin = margin
            topBar.addView(f, lp)
            return f
        }
        flashSlot = slot(flashIcon, Gravity.START, dp(12))
        flashSlot.setOnClickListener {
            if (mode == 1) torch = !torch else flashMode = (flashMode + 1) % (if (front) 3 else 4)
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            updateFlashChip()
            updateRepeating()
        }
        pinHost1 = FrameLayout(this)
        val ph1 = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL)
        ph1.leftMargin = dp(64)
        topBar.addView(pinHost1, ph1)
        pinHost2 = FrameLayout(this)
        val ph2 = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL)
        ph2.rightMargin = dp(64)
        topBar.addView(pinHost2, ph2)
        slot(chevron, Gravity.CENTER_HORIZONTAL, 0, false).setOnClickListener { toggleSheet() }
        slot(timerIcon, Gravity.END, dp(12)).setOnClickListener {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            timerIcon.label = if (timerSec == 0) "" else timerSec.toString()
            timerIcon.tint = if (timerSec != 0) accent else Color.WHITE
            haptic(HapticFeedbackConstants.CLOCK_TICK)
        }
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP))

        // ----- settings sheet (floats above the bottom controls) -----
        sheetHost = LinearLayout(this)
        sheetHost.orientation = LinearLayout.VERTICAL
        sheetHost.setPadding(dp(12), 0, dp(12), 0)

        sheet = GlassLinear(this, 28f, Color.parseColor("#A60C0C0E"))
        sheet.orientation = LinearLayout.VERTICAL
        sheet.setPadding(dp(18), dp(10), dp(18), dp(10))
        sheet.visibility = View.GONE
        sheet.tag = false
        sheet.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            v.pivotX = (r - l) / 2f
            v.pivotY = (b - t).toFloat()
        }
        glassViews.add(sheet)
        val grabber = View(this)
        grabber.background = rounded(Color.parseColor("#59FFFFFF"), dp(2).toFloat())
        val glp = LinearLayout.LayoutParams(dp(36), dp(4))
        glp.gravity = Gravity.CENTER_HORIZONTAL
        glp.bottomMargin = dp(8)
        sheet.addView(grabber, glp)

        ratioSeg = SegControl(this, accent) { i ->
            ratio43 = i == 0
            prefs.edit().putBoolean("ratio43", ratio43).apply()
            val l = cur
            if (l != null && !recording) {
                pickSizes(l)
                if (mode != 1 && device != null) { fadeOutStage(); startPreview() }
            }
        }
        ratioSeg.setOptions(listOf("4:3", "16:9"), if (ratio43) 0 else 1)

        photoSeg = SegControl(this, accent) { i ->
            if (!recording && i < photoOpts.size) {
                photoIdx = i
                photoSize = photoOpts[i]
                photoPrefMp = megapixels(photoSize)
                prefs.edit().putInt("photo_mp", photoPrefMp).apply()
                if (mode != 1 && device != null) startPreview()
            }
        }
        photoSeg.setOptions(listOf("12 MP"), 0)

        vidSeg = SegControl(this, accent) { i ->
            val o = vidOpts.getOrNull(i)
            if (!recording && o != null && o.ok) {
                vidIdx = i
                vidLabel = o.label
                prefs.edit().putString("vid_label", vidLabel).apply()
                startFpsProbe()
                updateRepeating()
            } else {
                vidSeg.select(vidIdx)
            }
        }
        vidSeg.onBlocked = { i ->
            val o = vidOpts.getOrNull(i)
            toast(
                if (o != null && o.fps >= 50 && fps60Off) "60 fps isn't available through this phone's camera API"
                else (o?.label ?: "That option") + " isn't available on this lens"
            )
        }
        vidSeg.setOptions(listOf("1080\u00B730"), 0)

        stabSeg = SegControl(this, accent) { i ->
            if (!recording) {
                stab = i
                prefs.edit().putInt("stab", stab).apply()
                updateStabUi()
                if (device != null) startPreview()
            }
        }
        stabSeg.onBlocked = { i ->
            if (!recording) {
                val key = capKey()
                stabCap[key] = 3
                prefs.edit().putInt("cap_$key", 3).apply()
                stab = i
                prefs.edit().putInt("stab", stab).apply()
                toast("Trying ${stabNames[i]}...")
                updateStabUi()
                if (device != null) startPreview()
            }
        }
        stabSeg.setOptions(stabNames.toList(), stab)

        hdrSeg = SegControl(this, accent) { i ->
            hdr = i == 1
            prefs.edit().putBoolean("hdr_on", hdr).apply()
            updateRepeating()
        }
        hdrSeg.setOptions(listOf("Off", "On"), if (hdr) 1 else 0)

        gridSeg = SegControl(this, accent) { i ->
            gridOn = i == 1
            prefs.edit().putBoolean("grid_on", gridOn).apply()
            grid.visibility = if (gridOn) View.VISIBLE else View.GONE
        }
        gridSeg.setOptions(listOf("Off", "On"), if (gridOn) 1 else 0)

        levelSeg = SegControl(this, accent) { i ->
            levelOn = i == 1
            prefs.edit().putBoolean("level_on", levelOn).apply()
            applyLevel()
        }
        levelSeg.setOptions(listOf("Off", "On"), if (levelOn) 1 else 0)

        crossSeg = SegControl(this, accent) { i ->
            crossOn = i == 1
            prefs.edit().putBoolean("cross_on", crossOn).apply()
            applyLevel()
        }
        crossSeg.setOptions(listOf("Off", "On"), if (crossOn) 1 else 0)

        procSeg = SegControl(this, accent) { i ->
            if (processing) {
                procSeg.select(if (procOn) 1 else 0)
            } else {
                procOn = i == 1
                prefs.edit().putBoolean("proc_on", procOn).apply()
                if (procOn && halBoost) {
                    halBoost = false
                    prefs.edit().putBoolean("hal_boost", false).apply()
                    refreshMenu(false)
                }
                if (device != null && mode != 1) startPreview()
            }
        }
        procSeg.setOptions(listOf("Off", "On"), if (procOn) 1 else 0)

        mirrorSeg = SegControl(this, accent) { i ->
            mirrorFront = i == 1
            prefs.edit().putBoolean("mirror_front", mirrorFront).apply()
            applyMirror()
        }
        mirrorSeg.setOptions(listOf("Off", "On"), if (mirrorFront) 1 else 0)

        evLabel = TextView(this)
        evSeek = SeekBar(this)
        evSeek.setOnSeekBarChangeListener(seekListener { p ->
            val l = cur
            if (l != null) {
                val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                ev = p + (er?.lower ?: 0)
                updateEvLabel()
                updateRepeating()
            }
        })
        evRow = LinearLayout(this)
        evRow.orientation = LinearLayout.HORIZONTAL
        evRow.gravity = Gravity.CENTER_VERTICAL
        evRow.setPadding(0, dp(5), 0, dp(5))
        evLabel.setTextColor(Color.parseColor("#C8FFFFFF"))
        evLabel.textSize = 13f
        evSeek.progressTintList = ColorStateList.valueOf(accent)
        evSeek.thumbTintList = ColorStateList.valueOf(accent)
        evRow.addView(evLabel, LinearLayout.LayoutParams(dp(120), -2))
        evRow.addView(evSeek, LinearLayout.LayoutParams(0, -2, 1f))

        // ---- compact menu: round icon buttons; multi-option settings open a small strip below ----
        for (sg in listOf(ratioSeg, photoSeg, vidSeg, stabSeg, hdrSeg, gridSeg, mirrorSeg, levelSeg, crossSeg, procSeg)) {
            sg.onAfter = { refreshMenu() }
        }
        fun tile(kind: Int): MenuTile {
            val t = MenuTile(this, kind, accent)
            pressable(t, 0.92f)
            return t
        }
        tileRatio = tile(0)
        tilePhoto = tile(1)
        tileProc = tile(2)
        tileX = tile(2)
        tileHdr = tile(5)
        tileVideo = tile(3)
        tileStab = tile(4)
        tileGridLines = tile(6)
        tileLevel = tile(8)
        tileCross = tile(9)
        tileMirror = tile(7)
        tileInfo = tile(10)

        // on/off settings flip on tap (through the same option controls as before)
        tileProc.setOnClickListener {
            if (!processing) {
                haptic(HapticFeedbackConstants.CLOCK_TICK)
                procSeg.choose(if (procOn) 0 else 1)
            }
        }
        tileX.setOnClickListener {
            if (!processing && !configuring) {
                haptic(HapticFeedbackConstants.CLOCK_TICK)
                halBoost = !halBoost
                prefs.edit().putBoolean("hal_boost", halBoost).apply()
                if (halBoost) {
                    // the phone's own engine works on the camera's normal pictures, so Enhance steps aside
                    procOn = false
                    prefs.edit().putBoolean("proc_on", false).apply()
                    procSeg.select(0)
                    toast("HAL boost (experiment): asks the phone's own multi-frame engine. Enhance is off.")
                }
                refreshMenu()
                if (device != null && mode != 1) startPreview()
            }
        }
        tileHdr.setOnClickListener {
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            hdrSeg.choose(if (hdr) 0 else 1)
        }
        tileGridLines.setOnClickListener {
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            gridSeg.choose(if (gridOn) 0 else 1)
        }
        tileLevel.setOnClickListener {
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            levelSeg.choose(if (levelOn) 0 else 1)
        }
        tileCross.setOnClickListener {
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            crossSeg.choose(if (crossOn) 0 else 1)
        }
        tileMirror.setOnClickListener {
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            mirrorSeg.choose(if (mirrorFront) 0 else 1)
        }
        tileInfo.setOnClickListener { showInfo() }
        // settings with several options open their existing option control in a strip under the buttons
        tileRatio.setOnClickListener { showDetail("ratio", "Photo ratio", ratioSeg) }
        tilePhoto.setOnClickListener { showDetail("photo", "Photo resolution", photoSeg) }
        tileVideo.setOnClickListener { showDetail("video", "Video quality", vidSeg) }
        tileStab.setOnClickListener { showDetail("stab", "Stabilization", stabSeg) }

        menuGrid = TileGrid(this, 5)
        for (t in listOf(
            tileRatio, tilePhoto, tileProc, tileX, tileHdr, tileVideo, tileStab,
            tileGridLines, tileLevel, tileCross, tileMirror, tileInfo
        )) menuGrid.addView(t)
        sheet.addView(menuGrid, LinearLayout.LayoutParams(-1, -2))
        // hold a control to pin it to the top row (two fit); hold its top button to take it off again
        for (key in listOf("hdr", "enhance", "ratio", "grid", "level", "cross", "mirror")) {
            pinTile(key)?.setOnLongClickListener {
                togglePin(key)
                true
            }
        }
        val saved = prefs.getString("pins", "hdr,enhance") ?: ""
        for (k in saved.split(",")) if (k.isNotEmpty() && pinTile(k) != null && pinKeys.size < 2) pinKeys.add(k)
        rebuildPins()

        detail = LinearLayout(this)
        detail.orientation = LinearLayout.VERTICAL
        detail.background = rounded(Color.parseColor("#1AFFFFFF"), dp(16).toFloat())
        detail.setPadding(dp(12), dp(10), dp(12), dp(12))
        detail.visibility = View.GONE
        detail.tag = false
        detailTitle = TextView(this)
        detailTitle.textSize = 11f
        detailTitle.letterSpacing = 0.08f
        detailTitle.setTextColor(Color.parseColor("#99FFFFFF"))
        detailTitle.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        detailBody = FrameLayout(this)
        detail.addView(detailTitle)
        val dbl = LinearLayout.LayoutParams(-1, -2)
        dbl.topMargin = dp(8)
        detail.addView(detailBody, dbl)
        val dtl = LinearLayout.LayoutParams(-1, -2)
        dtl.topMargin = dp(6)
        sheet.addView(detail, dtl)

        val elp = LinearLayout.LayoutParams(-1, -2)
        elp.topMargin = dp(4)
        sheet.addView(evRow, elp)
        val shlp = LinearLayout.LayoutParams(-1, -2)
        shlp.bottomMargin = dp(8)
        sheetHost.addView(sheet, shlp)

        proSheet = GlassLinear(this, 28f, Color.parseColor("#A60C0C0E"))
        proSheet.orientation = LinearLayout.VERTICAL
        proSheet.setPadding(dp(18), dp(8), dp(18), dp(8))
        proSheet.visibility = View.GONE
        proSheet.tag = false
        proSheet.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            v.pivotX = (r - l) / 2f
            v.pivotY = (b - t).toFloat()
        }
        glassViews.add(proSheet)
        // Pro panel: four values (tap one to put it on the ruler), the ruler under them, two quick buttons
        isoLabel = TextView(this)
        shutLabel = TextView(this)
        wbLabel = TextView(this)
        focusLabel = TextView(this)
        proDial = DialRuler(this, accent)
        proDial.onTick = { haptic(HapticFeedbackConstants.CLOCK_TICK) }
        proDial.onChange = { v -> proDialChanged(v) }
        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        val capNames = listOf("ISO", "SHUTTER", "WB", "FOCUS")
        val valueLabels = listOf(isoLabel, shutLabel, wbLabel, focusLabel)
        for (i in 0..3) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(dp(4), dp(8), dp(4), dp(8))
            val capsule = GradientDrawable()
            capsule.cornerRadius = dp(16).toFloat()
            capsule.setColor(Color.parseColor("#2EFFFFFF"))
            capsule.alpha = 0
            cell.background = capsule
            proBg.add(capsule)
            val cap = TextView(this)
            cap.text = capNames[i]
            cap.textSize = 10f
            cap.letterSpacing = 0.1f
            cap.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            cap.setTextColor(Color.parseColor("#99FFFFFF"))
            cap.gravity = Gravity.CENTER
            val vl = valueLabels[i]
            vl.textSize = 17f
            vl.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            vl.setTextColor(Color.WHITE)
            vl.gravity = Gravity.CENTER
            vl.maxLines = 1
            vl.fontFeatureSettings = "tnum"
            cell.addView(cap, LinearLayout.LayoutParams(-2, -2))
            cell.addView(vl, LinearLayout.LayoutParams(-2, -2))
            pressable(cell, 0.95f)
            cell.setOnClickListener {
                haptic(HapticFeedbackConstants.CLOCK_TICK)
                selectPro(i)
            }
            proCells.add(cell)
            proCaps.add(cap)
            val clp = LinearLayout.LayoutParams(0, -2, 1f)
            clp.leftMargin = dp(2)
            clp.rightMargin = dp(2)
            chipRow.addView(cell, clp)
        }
        proSheet.addView(chipRow, LinearLayout.LayoutParams(-1, -2))
        proSheet.addView(proDial, LinearLayout.LayoutParams(-1, dp(72)))
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.gravity = Gravity.CENTER_VERTICAL
        fun smallPill(label: String): TextView {
            val t = TextView(this)
            t.text = label
            t.textSize = 13f
            t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(16), 0, dp(16), 0)
            t.background = rounded(Color.parseColor("#26FFFFFF"), dp(18).toFloat())
            pressable(t, 0.94f)
            return t
        }
        val resetPill = smallPill("Reset all")
        resetPill.setOnClickListener {
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            isoProg = 0
            isoVal = 0
            shutProg = 0
            expVal = 0L
            wbIdx = 0
            focusProg = 0
            syncProDial()
            updateProLabels()
            updateRepeating()
        }
        peakChip = smallPill("Peaking")
        peakChip.setOnClickListener {
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            peakOn = !peakOn
            applyPeaking()
        }
        actions.addView(resetPill, LinearLayout.LayoutParams(-2, dp(36)))
        actions.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        actions.addView(peakChip, LinearLayout.LayoutParams(-2, dp(36)))
        val alp = LinearLayout.LayoutParams(-1, -2)
        alp.topMargin = dp(2)
        proSheet.addView(actions, alp)
        selectPro(0)
        val plp = LinearLayout.LayoutParams(-1, -2)
        plp.bottomMargin = dp(8)
        sheetHost.addView(proSheet, plp)

        // ----- bottom panel: zoom pill, mode carousel, shutter row -----
        val panel = LinearLayout(this)
        panel.clipChildren = false
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER_HORIZONTAL
        panel.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.TRANSPARENT, Color.parseColor("#E6000000"))
        )
        panel.setPadding(dp(12), dp(8), dp(12), dp(10))

        // the zoom pill floats above the panel and follows the viewfinder edge (see positionZoomPill)
        zoomGlass = GlassLinear(this, 30f, Color.parseColor("#52000000"))
        zoomRow = zoomGlass
        zoomRow.orientation = LinearLayout.HORIZONTAL
        zoomRow.gravity = Gravity.CENTER
        zoomRow.setPadding(dp(4), dp(4), dp(4), dp(4))
        glassViews.add(zoomRow)
        zoomGlass.onLongPressed = { startDial() }
        zoomGlass.onDialTouch = { ev -> dialTouch(ev) }

        modeBar = FrameLayout(this)
        modeBar.clipChildren = false
        modeRow = LinearLayout(this)
        modeRow.clipChildren = false
        modeRow.orientation = LinearLayout.HORIZONTAL
        val names = mapOf(0 to "Photo", 1 to "Video", 2 to "Pro")
        for (m in modeOrder) {
            val t = TextView(this)
            t.text = names[m]
            t.textSize = 15f
            t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            t.setPadding(dp(18), dp(9), dp(18), dp(9))
            val capsule = GradientDrawable()
            capsule.cornerRadius = dp(20).toFloat()
            capsule.setColor(Color.parseColor("#33FFFFFF"))
            capsule.alpha = 0
            t.background = capsule
            tabBg[m] = capsule
            t.setOnClickListener { setMode(m) }
            tabs[m] = t
            modeRow.addView(t)
        }
        modeBar.addView(modeRow, FrameLayout.LayoutParams(-2, -2))
        panel.addView(modeBar, LinearLayout.LayoutParams(-1, dp(44)))

        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER_VERTICAL

        thumb = ImageView(this)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.background = rounded(Color.parseColor("#33FFFFFF"), dp(10).toFloat())
        val thumbEdge = GradientDrawable()
        thumbEdge.shape = GradientDrawable.RECTANGLE
        thumbEdge.setColor(Color.TRANSPARENT)
        thumbEdge.cornerRadius = dp(10).toFloat()
        thumbEdge.setStroke(dp(1), Color.parseColor("#59FFFFFF"))
        thumb.foreground = thumbEdge
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
            }
        }
        thumb.clipToOutline = true
        pressable(thumb, 0.9f)
        thumb.setOnClickListener {
            if (!recording && !counting) {
                startActivity(Intent(this, GalleryActivity::class.java))
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax)
            }
        }

        shutter = CamShutter(this)
        shutter.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    (v as CamShutter).pressTo(true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> (v as CamShutter).pressTo(false)
            }
            false
        }
        shutter.setOnClickListener { shutterPressed() }

        val flipGlass = GlassLinear(this, 26f, Color.parseColor("#661C1C1E"))
        flipGlass.gravity = Gravity.CENTER
        flipGlass.addView(FlipIconView(this), LinearLayout.LayoutParams(dp(26), dp(26)))
        flipBtn = flipGlass
        pressable(flipBtn, 0.9f)
        flipBtn.setOnClickListener { flipCamera() }

        fun cell(v: View, size: Int): FrameLayout {
            val f = FrameLayout(this)
            f.addView(v, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
            return f
        }
        thumbCell = cell(thumb, dp(52))
        flipCell = cell(flipBtn, dp(52))
        controls.addView(thumbCell, LinearLayout.LayoutParams(0, dp(92), 1f))
        controls.addView(cell(shutter, dp(84)), LinearLayout.LayoutParams(0, dp(92), 1f))
        controls.addView(flipCell, LinearLayout.LayoutParams(0, dp(92), 1f))
        panel.addView(controls, LinearLayout.LayoutParams(-1, -2))

        rootView = root
        panelView = panel
        root.addView(sheetHost, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(zoomRow, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        zoomDial = ZoomDial(this, accent)
        zoomDial.visibility = View.GONE
        zoomDial.onTick = { haptic(HapticFeedbackConstants.CLOCK_TICK) }
        root.addView(zoomDial, FrameLayout.LayoutParams(-1, dp(150), Gravity.TOP))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        screenLight = View(this)
        screenLight.setBackgroundColor(Color.parseColor("#FFF4E6"))
        screenLight.alpha = 0f
        screenLight.visibility = View.GONE
        root.addView(screenLight, FrameLayout.LayoutParams(-1, -1))
        panel.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val nm = (b - t) + dp(4)
            val lp = sheetHost.layoutParams as FrameLayout.LayoutParams
            if (lp.bottomMargin != nm) {
                lp.bottomMargin = nm
                sheetHost.layoutParams = lp
            }
            val zp = zoomRow.layoutParams as FrameLayout.LayoutParams
            val zm = (b - t) + dp(6)
            if (zp.bottomMargin != zm) {
                zp.bottomMargin = zm
                zoomRow.layoutParams = zp
            }
            positionZoomPill(false)
        }
        sheetHost.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (devRot == 90 || devRot == 270) layoutSheetForRotation(false)
            positionZoomPill(true)
        }
        setContentView(root)

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) {
                try { previewSurface?.release() } catch (e: Exception) {}
                previewSurface = Surface(s)
                tryOpen()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {
                try { s.setDefaultBufferSize(previewSize.width, previewSize.height) } catch (e: Exception) {}
            }
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean {
                try { previewSurface?.release() } catch (e: Exception) {}
                previewSurface = null
                return true
            }
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {
                if (awaitFirstFrame) {
                    awaitFirstFrame = false
                    applyMirror()
                    fadeInStage()
                }
            }
        }
    }
}

// Frosted glass: the live camera layer itself, blurred on the GPU every frame (no snapshots), then a
// dark tint, a soft sheen and a hairline edge.
private object GlassSource {
    var live: View? = null // the camera preview (TextureView)
    var anchor: View? = null // its parent, which is not mirrored: where the preview sits on screen
}

private class GlassPainter(private val d: Float, radiusDp: Float, private val tint: Int) {
    private val radius = radiusDp * d
    private val path = Path()
    private val rect = RectF()
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)
    private val anchorLoc = IntArray(2)
    private var w = 0f
    private var h = 0f
    private var node: RenderNode? = null
    private var fx: RenderEffect? = null

    fun onSize(width: Int, height: Int) {
        w = width.toFloat()
        h = height.toFloat()
        rect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        tintPaint.color = tint
        sheenPaint.shader = LinearGradient(
            0f, 0f, 0f, h, Color.argb(30, 255, 255, 255), Color.argb(4, 255, 255, 255), Shader.TileMode.CLAMP
        )
        borderPaint.style = Paint.Style.STROKE
        borderPaint.strokeWidth = d
        borderPaint.shader = LinearGradient(
            0f, 0f, w, h, Color.argb(120, 255, 255, 255), Color.argb(22, 255, 255, 255), Shader.TileMode.CLAMP
        )
    }

    fun drawBackdrop(canvas: Canvas, v: View) {
        if (w <= 0f || h <= 0f) return
        canvas.save()
        canvas.clipPath(path)
        canvas.drawColor(Color.BLACK)
        val tex = GlassSource.live
        val anchor = GlassSource.anchor
        if (Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated &&
            tex != null && anchor != null && tex.width > 0 && tex.height > 0
        ) {
            try {
                val sigma = 20f * d
                val m = sigma * 2.5f // extra context around the panel so its edges blur correctly
                val n = node ?: RenderNode("glass").also { node = it }
                if (fx == null) {
                    val blur = RenderEffect.createBlurEffect(sigma, sigma, Shader.TileMode.CLAMP)
                    val cm = ColorMatrix()
                    cm.setSaturation(1.5f)
                    fx = RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm), blur)
                }
                n.setPosition((-m).toInt(), (-m).toInt(), (w + m).toInt(), (h + m).toInt())
                n.setRenderEffect(fx)
                val rc = n.beginRecording()
                try {
                    v.getLocationInWindow(loc)
                    anchor.getLocationInWindow(anchorLoc)
                    rc.translate(m + (anchorLoc[0] - loc[0]), m + (anchorLoc[1] - loc[1]))
                    if (tex.scaleX < 0f) rc.scale(-1f, 1f, tex.width / 2f, tex.height / 2f)
                    if (tex.scaleY < 0f) rc.scale(1f, -1f, tex.width / 2f, tex.height / 2f)
                    tex.draw(rc)
                } finally {
                    n.endRecording()
                }
                canvas.drawRenderNode(n)
            } catch (e: Exception) {
            }
        }
        canvas.drawRect(rect, tintPaint)
        canvas.drawRect(rect, sheenPaint)
        canvas.restore()
    }

    fun drawBorder(canvas: Canvas) {
        if (w <= 0f || h <= 0f) return
        val inset = borderPaint.strokeWidth / 2f
        canvas.drawRoundRect(inset, inset, w - inset, h - inset, radius - inset, radius - inset, borderPaint)
    }
}

private class GlassLinear(c: Context, radiusDp: Float, tint: Int) : LinearLayout(c) {
    private val gp = GlassPainter(c.resources.displayMetrics.density, radiusDp, tint)
    var dialMode = false
    var onLongPressed: (() -> Unit)? = null
    var onDialTouch: ((MotionEvent) -> Unit)? = null
    private val detector = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onLongPress(e: MotionEvent) {
            onLongPressed?.invoke()
        }
    })

    init {
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        gp.onSize(w, h)
    }

    override fun dispatchDraw(canvas: Canvas) {
        gp.drawBackdrop(canvas, this)
        super.dispatchDraw(canvas)
        gp.drawBorder(canvas)
    }

    // once the dial is up, this panel takes over the finger from the zoom buttons
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (onLongPressed != null) detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (dialMode) return true
        return super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (dialMode) {
            onDialTouch?.invoke(ev)
            return true
        }
        return super.onTouchEvent(ev)
    }
}

// The zoom dial: tick marks on a wide arc that slide under a fixed yellow marker.
private class ZoomDial(c: Context, private val accent: Int) : View(c) {
    var value = 1f
        set(v) {
            field = v
            val idx = nearestIndex(v)
            if (idx != lastIdx) {
                if (lastIdx != -1) onTick?.invoke()
                lastIdx = idx
            }
            invalidate()
        }
    var minV = 0.6f
    var maxV = 10f
    var extraMajor = 0f
    var onTick: (() -> Unit)? = null
    var textRot = 0f
        set(v) {
            field = v
            invalidate()
        }
    private var lastIdx = -1
    private val d = c.resources.displayMetrics.density
    val pxPerLn = 240f * d
    private val majors = floatArrayOf(0.6f, 1f, 2f, 3f, 5f, 10f)
    private val ticks = floatArrayOf(
        0.6f, 0.7f, 0.8f, 0.9f, 1f, 1.2f, 1.4f, 1.6f, 1.8f, 2f, 2.5f, 3f, 3.5f, 4f, 5f, 6f, 7f, 8f, 9f, 10f
    )
    private val ringPath = Path()
    private val capsule = RectF()
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#80000000") }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        color = Color.argb(70, 255, 255, 255)
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.6f * d
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        textSize = 11f * d
    }
    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2.5f * d
        color = accent
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        textSize = 15f * d
        color = accent
    }
    private val capsulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#99000000") }

    private fun nearestIndex(v: Float): Int {
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in ticks.indices) {
            val dd = abs(ln(ticks[i]) - ln(v))
            if (dd < bd) {
                bd = dd
                best = i
            }
        }
        return best
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val r = w * 0.78f
        val cx = w / 2f
        val topY = 46f * d
        val cy = topY + r
        val band = 46f * d
        ringPath.reset()
        ringPath.addCircle(cx, cy, r, Path.Direction.CW)
        ringPath.addCircle(cx, cy, r - band, Path.Direction.CCW)
        canvas.drawPath(ringPath, bandPaint)
        canvas.drawCircle(cx, cy, r - edgePaint.strokeWidth / 2f, edgePaint)

        val lnV = ln(value)
        for (t in ticks) {
            if (t < minV - 0.001f || t > maxV + 0.001f) continue
            val ang = (ln(t) - lnV) * (pxPerLn / r)
            if (abs(ang) > 0.95f) continue
            val major = majors.any { abs(it - t) < 0.001f } || (extraMajor > 0f && abs(extraMajor - t) < 0.001f)
            val len = (if (major) 16f else 9f) * d
            val s = sin(ang)
            val co = cos(ang)
            val sx = cx + r * s
            if (sx < -10f || sx > w + 10f) continue
            val q = abs(ang) / 0.95f
            val a = (1f - q * q).coerceIn(0f, 1f)
            tickPaint.color = Color.argb((235 * a).toInt(), 255, 255, 255)
            canvas.drawLine(sx, cy - r * co, cx + (r - len) * s, cy - (r - len) * co, tickPaint)
            if (major) {
                textPaint.color = Color.argb((230 * a).toInt(), 255, 255, 255)
                val label = if (t < 1f) String.format(Locale.US, "%.1f", t).removePrefix("0") else t.roundToInt().toString()
                val lr = r - len - 13f * d
                val lx = cx + lr * s
                val ly = cy - lr * co + 4f * d
                canvas.save()
                canvas.rotate(textRot, lx, ly - 4f * d)
                canvas.drawText(label, lx, ly, textPaint)
                canvas.restore()
            }
        }
        canvas.drawLine(cx, topY - 8f * d, cx, topY + 24f * d, markPaint)
        // the value turns with the phone; sideways it is nudged down so it is not cut off at the top
        val shift = if (abs(sin(textRot * 0.0174533f)) > 0.5f) 16f * d else 0f
        canvas.save()
        canvas.rotate(textRot, cx, topY - 28f * d + shift)
        capsule.set(cx - 32f * d, topY - 42f * d + shift, cx + 32f * d, topY - 14f * d + shift)
        canvas.drawRoundRect(capsule, 14f * d, 14f * d, capsulePaint)
        canvas.drawText(String.format(Locale.US, "%.1f\u00D7", value), cx, topY - 22f * d + shift, valuePaint)
        canvas.restore()
    }
}

// ---- compact menu ----

// 5-column grid that skips hidden buttons, so the rest always close up
private class TileGrid(c: Context, private val cols: Int) : ViewGroup(c) {
    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = View.MeasureSpec.getSize(widthSpec)
        val cw = w / cols
        var idx = 0
        var rowH = 0
        var total = 0
        for (i in 0 until childCount) {
            val ch = getChildAt(i)
            if (ch.visibility == View.GONE) continue
            ch.measure(
                View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            rowH = max(rowH, ch.measuredHeight)
            idx++
            if (idx % cols == 0) {
                total += rowH
                rowH = 0
            }
        }
        if (idx % cols != 0) total += rowH
        setMeasuredDimension(w, total)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l) / cols
        var idx = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val ch = getChildAt(i)
            if (ch.visibility == View.GONE) continue
            val x = (idx % cols) * cw
            ch.layout(x, y, x + cw, y + ch.measuredHeight)
            rowH = max(rowH, ch.measuredHeight)
            idx++
            if (idx % cols == 0) {
                y += rowH
                rowH = 0
            }
        }
    }
}

// a round button with its label underneath
private class MenuTile(c: Context, kind: Int, private val accent: Int) : LinearLayout(c) {
    val icon = TileIcon(c, kind, accent)
    val label = TextView(c)
    var pinned = false
        set(v) {
            field = v
            invalidate()
        }
    private val dotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent }
    private val dotEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E61C1C1E")
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * c.resources.displayMetrics.density
    }

    // a small yellow dot on the corner of a pinned control
    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (pinned) {
            val d = resources.displayMetrics.density
            val cx = width / 2f + 21f * d
            val cy = 9f * d
            canvas.drawCircle(cx, cy, 5f * d, dotFill)
            canvas.drawCircle(cx, cy, 5f * d, dotEdge)
        }
    }

    init {
        val d = c.resources.displayMetrics.density
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
        addView(icon, LinearLayout.LayoutParams((52 * d).toInt(), (52 * d).toInt()))
        label.textSize = 10.5f
        label.maxLines = 1
        label.gravity = Gravity.CENTER
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.setTextColor(Color.argb(190, 255, 255, 255))
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.topMargin = (5 * d).toInt()
        addView(label, lp)
    }

    fun setState(on: Boolean, text: String, animate: Boolean) {
        icon.setOn(on, animate)
        label.text = text
        label.setTextColor(if (on) accent else Color.argb(190, 255, 255, 255))
    }
}

// The icon itself: a glassy circle that fills yellow (with a little pop) when the setting is on.
// kinds: 0 ratio, 1 megapixels, 2 enhance, 3 video, 4 stabilization, 5 HDR, 6 grid, 7 mirror,
// 8 level, 9 crosshair, 10 info
private class TileIcon(c: Context, private val kind: Int, private val accent: Int) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val ev = ArgbEvaluator()
    private var t = 0f
    private var target = 0f
    private var rp = 0f
    private var anim: ValueAnimator? = null
    private var ratioAnim: ValueAnimator? = null
    var ring = false
        set(v) {
            field = v
            invalidate()
        }
    var value = ""
        set(v) {
            field = v
            invalidate()
        }
    var sub = ""
        set(v) {
            field = v
            invalidate()
        }
    var wide = false
        set(v) {
            if (field != v) {
                field = v
                ratioAnim?.cancel()
                val a = ValueAnimator.ofFloat(rp, if (v) 1f else 0f)
                a.duration = 320
                a.interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
                a.addUpdateListener {
                    rp = it.animatedValue as Float
                    invalidate()
                }
                a.start()
                ratioAnim = a
            }
        }
    private val fillCircle = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = accent
        strokeWidth = 2f * d
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.8f
    }
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()

    fun setOn(on: Boolean, animate: Boolean) {
        val to = if (on) 1f else 0f
        if (to == target) return
        target = to
        anim?.cancel()
        if (!animate) {
            t = to
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(t, to)
        a.duration = 260
        a.interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
        if (on) {
            animate().scaleX(1.14f).scaleY(1.14f).setDuration(110).withEndAction {
                animate().scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(OvershootInterpolator(3f)).start()
            }.start()
        }
    }

    private fun star(canvas: Canvas, x: Float, y: Float, r: Float) {
        path.reset()
        path.moveTo(x, y - r)
        path.quadTo(x, y, x + r, y)
        path.quadTo(x, y, x, y + r)
        path.quadTo(x, y, x - r, y)
        path.quadTo(x, y, x, y - r)
        path.close()
        canvas.drawPath(path, solid)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - d
        fillCircle.color = ev.evaluate(t, Color.argb(46, 255, 255, 255), accent) as Int
        canvas.drawCircle(cx, cy, r, fillCircle)
        if (ring) canvas.drawCircle(cx, cy, r, ringPaint)
        val col = ev.evaluate(t, Color.WHITE, Color.parseColor("#1C1C1E")) as Int
        line.color = col
        solid.color = col
        txt.color = col
        val s = min(width, height) * 0.5f / 24f
        canvas.save()
        canvas.translate(cx - 12f * s, cy - 12f * s)
        canvas.scale(s, s)
        when (kind) {
            0 -> {
                val h = 19f
                val w = h * (0.75f + (0.5625f - 0.75f) * rp)
                canvas.drawRoundRect(12f - w / 2f, 12f - h / 2f, 12f + w / 2f, 12f + h / 2f, 2.6f, 2.6f, line)
            }
            1 -> {
                txt.textSize = 11f
                canvas.drawText(value, 12f, 13.2f, txt)
                txt.textSize = 5.8f
                canvas.drawText("MP", 12f, 19.5f, txt)
            }
            2 -> {
                star(canvas, 10f, 13.5f, 6.5f)
                star(canvas, 18f, 6.5f, 3.2f)
                star(canvas, 18.5f, 18f, 2.2f)
            }
            3 -> {
                txt.textSize = 9.5f
                canvas.drawText(value, 12f, 13.2f, txt)
                txt.textSize = 6f
                canvas.drawText(sub, 12f, 19.5f, txt)
            }
            4 -> {
                val a = 4.5f
                val b = 19.5f
                val l = 5f
                canvas.drawLine(a, a + l, a, a, line)
                canvas.drawLine(a, a, a + l, a, line)
                canvas.drawLine(b - l, a, b, a, line)
                canvas.drawLine(b, a, b, a + l, line)
                canvas.drawLine(a, b - l, a, b, line)
                canvas.drawLine(a, b, a + l, b, line)
                canvas.drawLine(b - l, b, b, b, line)
                canvas.drawLine(b, b - l, b, b, line)
                canvas.drawCircle(12f, 12f, 2.4f, solid)
            }
            5 -> {
                canvas.drawRoundRect(3f, 6.5f, 21f, 17.5f, 2.4f, 2.4f, line)
                txt.textSize = 6.4f
                canvas.drawText("HDR", 12f, 14.3f, txt)
            }
            6 -> {
                canvas.drawRoundRect(4f, 4f, 20f, 20f, 3f, 3f, line)
                canvas.drawLine(9.33f, 4f, 9.33f, 20f, line)
                canvas.drawLine(14.67f, 4f, 14.67f, 20f, line)
                canvas.drawLine(4f, 9.33f, 20f, 9.33f, line)
                canvas.drawLine(4f, 14.67f, 20f, 14.67f, line)
            }
            7 -> {
                canvas.drawLine(12f, 3f, 12f, 6.5f, line)
                canvas.drawLine(12f, 10f, 12f, 14f, line)
                canvas.drawLine(12f, 17.5f, 12f, 21f, line)
                path.reset()
                path.moveTo(3f, 18f)
                path.lineTo(9.5f, 18f)
                path.lineTo(9.5f, 7f)
                path.close()
                canvas.drawPath(path, solid)
                path.reset()
                path.moveTo(21f, 18f)
                path.lineTo(14.5f, 18f)
                path.lineTo(14.5f, 7f)
                path.close()
                canvas.drawPath(path, line)
            }
            8 -> {
                canvas.drawRoundRect(3f, 8.5f, 21f, 15.5f, 3.5f, 3.5f, line)
                canvas.drawLine(9.5f, 8.5f, 9.5f, 10.8f, line)
                canvas.drawLine(14.5f, 8.5f, 14.5f, 10.8f, line)
                canvas.drawCircle(12f, 12.6f, 1.7f, solid)
            }
            9 -> {
                canvas.drawCircle(12f, 12f, 8.5f, line)
                canvas.drawLine(12f, 7f, 12f, 17f, line)
                canvas.drawLine(7f, 12f, 17f, 12f, line)
            }
            10 -> {
                canvas.drawCircle(12f, 12f, 9f, line)
                canvas.drawCircle(12f, 8f, 1.1f, solid)
                canvas.drawLine(12f, 11f, 12f, 17f, line)
            }
        }
        canvas.restore()
    }
}

// iOS-style segmented control with a sliding highlight
private class SegControl(
    c: Context,
    private val accent: Int,
    private val onSelect: (Int) -> Unit
) : FrameLayout(c) {
    var onBlocked: ((Int) -> Unit)? = null
    var onAfter: (() -> Unit)? = null
    private val d = c.resources.displayMetrics.density
    private val hi = View(c)
    private val row = LinearLayout(c)
    private val items = mutableListOf<TextView>()
    private var sel = 0
    private var dimmed: Set<Int> = emptySet()
    private val pad = (3 * d).toInt()

    init {
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#26FFFFFF"))
        bg.cornerRadius = 12 * d
        background = bg
        setPadding(pad, pad, pad, pad)
        val hb = GradientDrawable()
        hb.setColor(Color.parseColor("#4DFFFFFF"))
        hb.cornerRadius = 10 * d
        hi.background = hb
        addView(hi, FrameLayout.LayoutParams(0, 0))
        row.orientation = LinearLayout.HORIZONTAL
        addView(row, FrameLayout.LayoutParams(-1, -2))
    }

    fun setOptions(opts: List<String>, selected: Int) {
        row.removeAllViews()
        items.clear()
        opts.forEachIndexed { i, s ->
            val t = TextView(context)
            t.text = s
            t.textSize = 12.5f
            t.gravity = Gravity.CENTER
            t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            t.setPadding((4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt())
            t.setOnClickListener {
                if (i in dimmed) {
                    onBlocked?.invoke(i)
                } else {
                    select(i, true)
                    onSelect(i)
                    onAfter?.invoke()
                }
            }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            items.add(t)
        }
        sel = selected.coerceIn(0, max(0, opts.size - 1))
        applyStyle()
        moveHi(false)
    }

    // same as tapping option i
    fun choose(i: Int) {
        select(i, true)
        onSelect(i)
        onAfter?.invoke()
    }

    fun select(i: Int, animate: Boolean = true) {
        sel = i
        applyStyle()
        moveHi(animate)
    }

    fun setDimmed(set: Set<Int>) {
        dimmed = set
        applyStyle()
    }

    fun setDimFrom(n: Int) {
        setDimmed((n until items.size).toSet())
    }

    private fun applyStyle() {
        items.forEachIndexed { idx, t ->
            t.setTextColor(if (idx == sel) accent else Color.WHITE)
            t.alpha = if (idx in dimmed) 0.35f else 1f
        }
    }

    private fun moveHi(animate: Boolean) {
        if (items.isEmpty() || width == 0) return
        val w = (width - 2 * pad) / items.size
        val lp = hi.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != height - 2 * pad) {
            lp.width = w
            lp.height = height - 2 * pad
            hi.layoutParams = lp
        }
        val x = (sel * w).toFloat()
        if (animate) {
            hi.animate().translationX(x).setDuration(280)
                .setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f)).start()
        } else {
            hi.animate().cancel()
            hi.translationX = x
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        post { moveHi(false) }
    }
}

private class CamShutter(c: Context) : View(c) {
    private var video = false
    private var morph = 0f // 0 = circle, 1 = rounded square (recording)
    private var red = 0f
    private var anim: ValueAnimator? = null
    private val d = c.resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 4f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val eval = ArgbEvaluator()
    private var press = 0f
    private var pressAnim: ValueAnimator? = null

    // the disc shrinks a little while the finger is down and springs back
    fun pressTo(down: Boolean) {
        val from = press
        val to = if (down) 1f else 0f
        pressAnim?.cancel()
        val a = ValueAnimator.ofFloat(from, to)
        a.duration = if (down) 90L else 260L
        a.interpolator = if (down) PathInterpolator(0.3f, 0f, 0.6f, 1f) else OvershootInterpolator(2.2f)
        a.addUpdateListener {
            press = it.animatedValue as Float
            invalidate()
        }
        a.start()
        pressAnim = a
    }

    fun setState(v: Boolean, r: Boolean) {
        video = v
        val m0 = morph
        val r0 = red
        val mt = if (r) 1f else 0f
        val rt = if (v) 1f else 0f
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 300
        a.interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            morph = m0 + (mt - m0) * f
            red = r0 + (rt - r0) * f
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - ring.strokeWidth
        canvas.drawCircle(cx, cy, r, ring)
        fill.color = eval.evaluate(red, Color.WHITE, Color.parseColor("#FF3B30")) as Int
        val half = r * (0.80f + (0.42f - 0.80f) * morph) * (1f - 0.12f * press)
        val corner = half + (half * 0.3f - half) * morph
        canvas.drawRoundRect(cx - half, cy - half, cx + half, cy + half, corner, corner, fill)
    }
}

private class CamGrid(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(110, 255, 255, 255)
        strokeWidth = 1.2f * c.resources.displayMetrics.density
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, p)
            canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, p)
        }
    }
}

// types: 0 flash, 1 timer, 2 chevron, 3 sun
private class CamIcon(c: Context, private val type: Int) : View(c) {
    var tint = Color.WHITE
        set(v) { field = v; invalidate() }
    var state = 0
        set(v) { field = v; invalidate() }
    var label = ""
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        canvas.scale(s, s)
        p.color = tint
        p.strokeWidth = 1.8f
        p.style = Paint.Style.STROKE
        tp.color = tint
        when (type) {
            0 -> {
                path.reset()
                path.moveTo(13f, 2.5f)
                path.lineTo(5.5f, 13f)
                path.lineTo(11f, 13f)
                path.lineTo(10f, 21.5f)
                path.lineTo(18.5f, 10.5f)
                path.lineTo(13f, 10.5f)
                path.close()
                p.style = if (state >= 2) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
                canvas.drawPath(path, p)
                p.style = Paint.Style.STROKE
                if (state == 0) canvas.drawLine(4f, 4f, 20f, 20f, p)
                if (state == 1) {
                    tp.textSize = 9f
                    canvas.drawText("A", 19f, 21f, tp)
                }
                if (state == 3) {
                    tp.textSize = 9f
                    canvas.drawText("T", 19f, 21f, tp)
                }
            }
            1 -> {
                canvas.drawCircle(12f, 13.5f, 7.5f, p)
                canvas.drawLine(9.5f, 3f, 14.5f, 3f, p)
                if (label.isEmpty()) {
                    canvas.drawLine(12f, 13.5f, 12f, 9.5f, p)
                } else {
                    tp.textSize = 9f
                    canvas.drawText(label, 12f, 16.7f, tp)
                }
            }
            2 -> {
                path.reset()
                path.moveTo(5f, 9f)
                path.lineTo(12f, 16f)
                path.lineTo(19f, 9f)
                canvas.drawPath(path, p)
            }
            3 -> {
                // a solid disc with eight round-ended rays, with a faint dark edge so it reads on any picture
                val c0 = p.color
                for (pass in 0..1) {
                    if (pass == 0) {
                        p.color = Color.argb(95, 0, 0, 0)
                        p.strokeWidth = 3.6f
                    } else {
                        p.color = c0
                        p.strokeWidth = 2.0f
                    }
                    p.style = Paint.Style.FILL
                    canvas.drawCircle(12f, 12f, if (pass == 0) 5.1f else 4.2f, p)
                    p.style = Paint.Style.STROKE
                    for (i in 0 until 8) {
                        canvas.drawLine(12f, 2.4f, 12f, 4.6f, p)
                        canvas.rotate(45f, 12f, 12f)
                    }
                }
                p.color = c0
            }
        }
        canvas.restore()
    }
}

// Level aids over the viewfinder. Held upright, the bar follows the real horizon and turns yellow
// when level. With the phone flat (back camera pointing down) the crosshair becomes a bubble level
// for overhead shots: the moving plus slides toward the raised side and merges with the fixed one
// (yellow) when the phone is flat.
private class LevelOverlay(c: Context, private val accent: Int) : View(c) {
    private val d = c.resources.displayMetrics.density
    var showBar = false
    var showCross = false
    var onAligned: (() -> Unit)? = null
    private var roll = 0f // degrees the phone is turned clockwise
    private var pitch = 0f // 0 = camera level with the horizon, 90 = pointing straight down
    private var tx = 0f // flat: tilt toward the right edge
    private var ty = 0f // flat: tilt toward the top edge
    private var quarter = 0f // nearest multiple of 90 degrees to the roll
    private var relRoll = 0f // roll relative to that
    private var barAligned = false
    private var flatAligned = false
    private var primed = false
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val white = Color.argb(235, 255, 255, 255)
    private val dim = Color.argb(150, 255, 255, 255)

    fun update(ax: Float, ay: Float, az: Float) {
        val g = sqrt(ax * ax + ay * ay + az * az)
        if (g < 1f) return
        val nx = (ax / g).coerceIn(-1f, 1f)
        val ny = (ay / g).coerceIn(-1f, 1f)
        val nz = (az / g).coerceIn(-1f, 1f)
        val rad = 57.29578f
        val k = if (primed) 0.3f else 1f
        // roll: how far the phone is turned clockwise, whichever way up; smoothed across the +-180 wrap
        var dr = atan2(-nx, ny) * rad - roll
        if (dr > 180f) dr -= 360f
        if (dr < -180f) dr += 360f
        roll += dr * k
        if (roll > 180f) roll -= 360f
        if (roll <= -180f) roll += 360f
        pitch += (asin(nz) * rad - pitch) * k
        tx += (asin(nx) * rad - tx) * k
        ty += (asin(ny) * rad - ty) * k
        primed = true
        // "level" is relative to the nearest quarter turn, so the bar works in portrait and in landscape
        quarter = (roll / 90f).roundToInt() * 90f
        relRoll = roll - quarter
        val upright = abs(pitch) < 25f
        val flatMode = pitch > 70f
        val newBar = upright && abs(relRoll) < (if (barAligned) 1.6f else 1f)
        val newFlat = flatMode && hypot(tx, ty) < (if (flatAligned) 1.6f else 1f)
        if ((newBar && !barAligned && showBar) || (newFlat && !flatAligned && (showBar || showCross))) {
            onAligned?.invoke()
        }
        barAligned = newBar
        flatAligned = newFlat
        if (visibility == VISIBLE) invalidate()
    }

    private fun seg(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int) {
        line.strokeWidth = 3.6f * d
        line.color = Color.argb(70, 0, 0, 0)
        canvas.drawLine(x1, y1, x2, y2, line)
        line.strokeWidth = 1.8f * d
        line.color = color
        canvas.drawLine(x1, y1, x2, y2, line)
    }

    private fun plus(canvas: Canvas, x: Float, y: Float, half: Float, color: Int) {
        seg(canvas, x - half, y, x + half, y, color)
        seg(canvas, x, y - half, x, y + half, color)
    }

    private fun ring(canvas: Canvas, x: Float, y: Float, r: Float, color: Int) {
        line.strokeWidth = 3.6f * d
        line.color = Color.argb(70, 0, 0, 0)
        canvas.drawCircle(x, y, r, line)
        line.strokeWidth = 1.4f * d
        line.color = color
        canvas.drawCircle(x, y, r, line)
    }

    override fun onDraw(canvas: Canvas) {
        if (!showBar && !showCross) return
        val cx = width / 2f
        val cy = height / 2f
        if (pitch > 70f) {
            // overhead: fixed target and a moving plus
            val col = if (flatAligned) accent else white
            val ringCol = if (flatAligned) accent else dim
            ring(canvas, cx, cy, 24f * d, ringCol)
            plus(canvas, cx, cy, 14f * d, ringCol)
            val mx = if (flatAligned) 0f else (tx * 10f * d).coerceIn(-120f * d, 120f * d)
            val my = if (flatAligned) 0f else (-ty * 10f * d).coerceIn(-120f * d, 120f * d)
            plus(canvas, cx + mx, cy + my, 14f * d, col)
            return
        }
        if (showCross) plus(canvas, cx, cy, 12f * d, dim)
        if (showBar && abs(pitch) < 25f) {
            val col = if (barAligned) accent else white
            val ref = if (barAligned) accent else dim
            // fixed marks follow the phone's own edge, the moving bar follows the horizon
            canvas.save()
            canvas.rotate(-quarter, cx, cy)
            seg(canvas, cx - 98f * d, cy, cx - 78f * d, cy, ref)
            seg(canvas, cx + 78f * d, cy, cx + 98f * d, cy, ref)
            canvas.restore()
            canvas.save()
            canvas.rotate(-roll, cx, cy)
            seg(canvas, cx - 66f * d, cy, cx - 22f * d, cy, col)
            seg(canvas, cx + 22f * d, cy, cx + 66f * d, cy, col)
            canvas.restore()
        }
    }
}

// one frame of a burst: direct buffers of the YUV planes plus alignment data
private class BurstFrame(
    val w: Int,
    val h: Int,
    val y: java.nio.ByteBuffer,
    val u: java.nio.ByteBuffer,
    val v: java.nio.ByteBuffer,
    val yrs: Int,
    val urs: Int,
    val ups: Int,
    val vrs: Int,
    val vps: Int
) {
    constructor(img: Image) : this(
        img.width, img.height,
        img.planes[0].buffer, img.planes[1].buffer, img.planes[2].buffer,
        img.planes[0].rowStride, img.planes[1].rowStride, img.planes[1].pixelStride,
        img.planes[2].rowStride, img.planes[2].pixelStride
    )

    // a frame copied out of the camera as one NV21 array (V and U interleaved after the luma)
    constructor(nv: ByteArray, w: Int, h: Int) : this(
        w, h,
        java.nio.ByteBuffer.wrap(nv, 0, w * h).slice(),
        java.nio.ByteBuffer.wrap(nv, w * h + 1, w * h / 2 - 1).slice(),
        java.nio.ByteBuffer.wrap(nv, w * h, w * h / 2).slice(),
        w, w, 2, w, 2
    )
    var dx = 0
    var dy = 0
    var s2 = ByteArray(0)
    var s8 = ByteArray(0)
}

// Camera flip: two arrows chasing each other around a circle.
private class FlipIconView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.8f
    }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val head = Path()

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        canvas.scale(s, s)
        val r = 7.5f
        val box = RectF(12f - r, 12f - r, 12f + r, 12f + r)
        head.reset()
        head.moveTo(2.4f, 0f)
        head.lineTo(-2.6f, -3f)
        head.lineTo(-2.6f, 3f)
        head.close()
        for (k in 0..1) {
            canvas.save()
            if (k == 1) canvas.rotate(180f, 12f, 12f)
            canvas.drawArc(box, 205f, 120f, false, p)
            val a = Math.toRadians(325.0)
            val ex = 12f + r * cos(a).toFloat()
            val ey = 12f + r * sin(a).toFloat()
            canvas.save()
            canvas.translate(ex, ey)
            canvas.rotate(325f + 90f)
            canvas.drawPath(head, f)
            canvas.restore()
            canvas.restore()
        }
        canvas.restore()
    }
}
