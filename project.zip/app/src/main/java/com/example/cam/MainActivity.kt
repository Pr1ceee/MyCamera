package com.example.cam

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : Activity() {

    class Lens(val logicalId: String, val physicalId: String?, val chars: CameraCharacteristics)
    class VidOpt(val w: Int, val h: Int, val fps: Int, val bitrate: Int, val label: String)

    private val accent = Color.parseColor("#FFD60A")

    // camera state
    private lateinit var mgr: CameraManager
    private val lcCache = HashMap<String, CameraCharacteristics>()
    private var mainLens: Lens? = null
    private var ultraLens: Lens? = null
    private var frontLens: Lens? = null
    private var cur: Lens? = null
    private var front = false
    private var hiddenIds = listOf<String>()
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var opening = false
    private var previewSurface: Surface? = null
    private var reader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recording = false
    private var recStart = 0L
    private var videoUri: Uri? = null
    private var lastUri: Uri? = null
    private var curTemplate = CameraDevice.TEMPLATE_PREVIEW
    private var curTargets: List<Surface> = emptyList()
    private val thread = HandlerThread("cam").also { it.start() }
    private val bg = Handler(thread.looper)
    private val ui = Handler(Looper.getMainLooper())

    // settings state
    private var mode = 0 // 0 photo, 1 video, 2 pro
    private var flashMode = 0 // photo: 0 off, 1 auto, 2 on
    private var torch = false // video
    private var timerSec = 0
    private var hdr = false
    private var ratio43 = true
    private var vidIdx = 0
    private var vidLabel = "1080p 30"
    private var vidOpts: List<VidOpt> = emptyList()
    private var stab = 1 // 0 off, 1 standard, 2 preview
    private var ev = 0
    private var evStep = 0f
    private var evAccum = 0f
    private var zoom = 1f
    private var tapRegion: MeteringRectangle? = null
    private var isoProg = 0
    private var shutProg = 0
    private var focusProg = 0
    private var hasFlash = false
    private var hdrSupported = false
    private var counting = false
    private var focusActive = false
    private var fx = 0f
    private var fy = 0f
    private var previewSize = Size(1920, 1080)
    private var photoSize = Size(1920, 1080)
    private var zoomAnim: ValueAnimator? = null
    private var stageAnim: ValueAnimator? = null

    // ui
    private lateinit var stage: FrameLayout
    private lateinit var texture: TextureView
    private lateinit var grid: CamGrid
    private lateinit var flashOverlay: View
    private lateinit var focusBox: View
    private lateinit var focusLine: View
    private lateinit var sunIcon: CamIcon
    private lateinit var countdownTv: TextView
    private lateinit var zoomTv: TextView
    private lateinit var recTv: TextView
    private lateinit var flashIcon: CamIcon
    private lateinit var timerIcon: CamIcon
    private lateinit var chevron: CamIcon
    private lateinit var sheet: LinearLayout
    private lateinit var proSheet: LinearLayout
    private lateinit var zoomRow: LinearLayout
    private lateinit var modeBar: FrameLayout
    private lateinit var modeRow: LinearLayout
    private lateinit var shutter: CamShutter
    private lateinit var thumb: ImageView
    private lateinit var flipBtn: TextView
    private lateinit var ratioChip: TextView
    private lateinit var vidChip: TextView
    private lateinit var stabChip: TextView
    private lateinit var hdrChip: TextView
    private lateinit var hdrRow: LinearLayout
    private lateinit var gridChip: TextView
    private lateinit var evSeek: SeekBar
    private lateinit var evLabel: TextView
    private lateinit var evRow: LinearLayout
    private lateinit var isoSeek: SeekBar
    private lateinit var shutSeek: SeekBar
    private lateinit var focusSeek: SeekBar
    private lateinit var isoLabel: TextView
    private lateinit var shutLabel: TextView
    private lateinit var focusLabel: TextView
    private val tabs = HashMap<Int, TextView>()
    private val zoomChips = mutableListOf<Pair<TextView, Float>>()
    private val modeOrder = listOf(1, 0, 2) // display order: VIDEO, PHOTO, PRO

    private val stabNames = arrayOf("Off", "Standard", "Preview")

    private val hideZoom = Runnable { zoomTv.visibility = View.GONE }
    private val fadeInSafety = Runnable { fadeInStage() }
    private val hideFocus = Runnable {
        focusActive = false
        for (v in listOf<View>(focusBox, focusLine, sunIcon)) {
            v.animate().alpha(0f).setDuration(250).withEndAction {
                if (!focusActive) v.visibility = View.GONE
            }.start()
        }
    }
    private val recTick = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000
            recTv.text = String.format(Locale.US, "\u25CF %02d:%02d", s / 60, s % 60)
            ui.postDelayed(this, 500)
        }
    }

    // ================= lifecycle =================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        mgr = getSystemService(CAMERA_SERVICE) as CameraManager
        try { setupLenses() } catch (e: Exception) { toast("Camera setup failed: ${e.message}") }
        cur = mainLens
        buildUi()
        refreshCaps()
        buildZoomChips()
        refreshModeUi(false)
        if (!hasPerms()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasPerms()) tryOpen() else toast("Camera and microphone permissions are required")
    }

    override fun onResume() {
        super.onResume()
        tryOpen()
    }

    override fun onPause() {
        counting = false
        countdownTv.visibility = View.GONE
        if (recording) stopRecording(false)
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        thread.quitSafely()
        super.onDestroy()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if ((event?.repeatCount ?: 0) == 0) shutterPressed()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun hasPerms() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun haptic(type: Int) { window.decorView.performHapticFeedback(type) }

    // ================= camera discovery =================

    private fun lcOf(id: String): CameraCharacteristics = lcCache.getOrPut(id) { mgr.getCameraCharacteristics(id) }

    private fun zoomRangeOf(l: Lens): Range<Float> =
        lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) ?: Range(1f, 1f)

    private fun equiv(c: CameraCharacteristics): Double? {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return null
        val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        return f * 43.27 / hypot(s.width.toDouble(), s.height.toDouble())
    }

    private fun compat(c: CameraCharacteristics) =
        c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) == true

    private fun logicalWide(): Boolean {
        val m = mainLens ?: return false
        return zoomRangeOf(m).lower < 0.95f
    }

    private fun setupLenses() {
        val ids = mgr.cameraIdList.sortedBy { it.toIntOrNull() ?: 999 }
        val backs = mutableListOf<Lens>()
        for (id in ids) {
            val c = lcOf(id)
            if (!compat(c)) continue
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            if (facing == CameraCharacteristics.LENS_FACING_BACK) backs.add(Lens(id, null, c))
            else if (facing == CameraCharacteristics.LENS_FACING_FRONT && frontLens == null) frontLens = Lens(id, null, c)
        }
        // main camera = back camera whose zoom range goes lowest (logical multi-camera)
        mainLens = backs.minByOrNull { zoomRangeOf(it).lower }
        val main = mainLens ?: return
        if (!logicalWide()) {
            // fallback: look for a separate ultrawide lens, including IDs the phone doesn't list
            val mainEq = equiv(main.chars) ?: return
            val cands = mutableListOf<Lens>()
            for (b in backs) {
                if (b !== main) cands.add(b)
                for (pid in b.chars.physicalCameraIds) {
                    if (pid !in ids) cands.add(Lens(b.logicalId, pid, mgr.getCameraCharacteristics(pid)))
                }
            }
            val hidden = mutableListOf<String>()
            for (i in 2..9) {
                val id = i.toString()
                if (id in ids) continue
                try {
                    val c = mgr.getCameraCharacteristics(id)
                    if (compat(c) && c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK) {
                        lcCache[id] = c
                        cands.add(Lens(id, null, c))
                        hidden.add(id)
                    }
                } catch (e: Exception) {
                }
            }
            hiddenIds = hidden
            ultraLens = cands
                .filter { val e = equiv(it.chars); e != null && e < mainEq * 0.8 }
                .minByOrNull { equiv(it.chars)!! }
        }
    }

    private fun showInfo() {
        val sb = StringBuilder()
        for (id in mgr.cameraIdList) {
            val c = lcOf(id)
            val eq = equiv(c)?.let { String.format(Locale.US, "%.1f", it) }
            sb.append("ID ").append(id)
                .append(" facing=").append(c.get(CameraCharacteristics.LENS_FACING))
                .append(" zoom=").append(c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE))
                .append(" phys=").append(c.physicalCameraIds)
                .append(" mm=").append(eq).append("\n")
        }
        sb.append("\nUsing: ").append(cur?.logicalId).append(" / ").append(cur?.physicalId)
        sb.append("\nLogical wide: ").append(logicalWide())
        sb.append("\nHidden IDs responding: ").append(hiddenIds)
        sb.append("\nUltra fallback: ").append(ultraLens?.let { it.logicalId + "/" + it.physicalId })
        val m = mainLens
        if (m != null) {
            val lc = lcOf(m.logicalId)
            sb.append("\n\nAE fps ranges: ").append(
                lc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                    ?.joinToString(" ") { r -> "${r.lower}-${r.upper}" }
            )
            val mp = m.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            if (mp != null) {
                for ((w, h) in listOf(Pair(3840, 2160), Pair(1920, 1080), Pair(1280, 720))) {
                    val d = mp.getOutputMinFrameDuration(MediaRecorder::class.java, Size(w, h))
                    sb.append("\n").append(h).append("p max fps: ")
                        .append(if (d > 0L) (1e9 / d).roundToInt().toString() else "?")
                }
                val hs = mp.highSpeedVideoSizes
                sb.append("\nHigh-speed: ")
                if (hs.isEmpty()) sb.append("none")
                for (s in hs) {
                    sb.append(s.width).append("x").append(s.height).append(" ")
                    sb.append(mp.getHighSpeedVideoFpsRangesFor(s).joinToString(",", "[", "] ") { r -> "${r.lower}-${r.upper}" })
                }
            }
        }
        AlertDialog.Builder(this).setTitle("Camera info").setMessage(sb.toString())
            .setPositiveButton("OK", null).show()
    }

    // ================= sizes =================

    private fun pickSizes(l: Lens) {
        val map = l.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return
        val lc = lcOf(l.logicalId)
        val vs = map.getOutputSizes(MediaRecorder::class.java)?.toList() ?: emptyList()
        val ranges = lc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList()
        fun has(w: Int, h: Int) = vs.any { it.width == w && it.height == h }
        fun can60(w: Int, h: Int): Boolean {
            if (ranges.none { it.upper >= 60 }) return false
            val d = map.getOutputMinFrameDuration(MediaRecorder::class.java, Size(w, h))
            return d <= 0L || d <= 18_000_000L
        }
        val opts = mutableListOf<VidOpt>()
        if (has(1280, 720)) opts.add(VidOpt(1280, 720, 30, 10_000_000, "720p 30"))
        if (has(1920, 1080)) {
            opts.add(VidOpt(1920, 1080, 30, 16_000_000, "1080p 30"))
            if (can60(1920, 1080)) opts.add(VidOpt(1920, 1080, 60, 24_000_000, "1080p 60"))
        }
        if (has(3840, 2160)) {
            opts.add(VidOpt(3840, 2160, 24, 40_000_000, "4K 24"))
            opts.add(VidOpt(3840, 2160, 30, 50_000_000, "4K 30"))
            if (can60(3840, 2160)) opts.add(VidOpt(3840, 2160, 60, 80_000_000, "4K 60"))
        }
        if (opts.isEmpty()) {
            val b = vs.maxByOrNull { it.width * it.height } ?: Size(1280, 720)
            opts.add(VidOpt(b.width, b.height, 30, 12_000_000, "${b.height}p 30"))
        }
        vidOpts = opts
        val keep = opts.indexOfFirst { it.label == vidLabel }
        vidIdx = if (keep >= 0) keep else max(0, opts.indexOfFirst { it.label == "1080p 30" })
        vidLabel = opts[vidIdx].label
        vidChip.text = vidLabel

        val wantW = if (mode == 1 || !ratio43) 16 else 4
        val wantH = if (mode == 1 || !ratio43) 9 else 3
        val ps = map.getOutputSizes(SurfaceTexture::class.java)?.toList() ?: emptyList()
        previewSize = ps.filter { it.width * wantH == it.height * wantW && it.width <= 1920 }
            .maxByOrNull { it.width }
            ?: ps.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: Size(1280, 720)
        val js = map.getOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList()
        val fit = js.filter { it.width * wantH == it.height * wantW }
        photoSize = fit.filter { it.width.toLong() * it.height <= 13_000_000L }
            .maxByOrNull { it.width * it.height }
            ?: fit.minByOrNull { it.width * it.height }
            ?: js.maxByOrNull { it.width * it.height }
            ?: previewSize
    }

    private fun layoutStage() {
        val w = resources.displayMetrics.widthPixels
        val h = w * previewSize.width / previewSize.height
        val lp = stage.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w) { lp.width = w; stage.layoutParams = lp }
        if (lp.height == h) return
        stageAnim?.cancel()
        val a = ValueAnimator.ofInt(lp.height, h)
        a.duration = 320
        a.interpolator = DecelerateInterpolator(1.5f)
        a.addUpdateListener {
            val l2 = stage.layoutParams as FrameLayout.LayoutParams
            l2.height = it.animatedValue as Int
            stage.layoutParams = l2
        }
        a.start()
        stageAnim = a
    }

    // ================= camera lifecycle =================

    private fun tryOpen() {
        val l = cur ?: return
        if (!hasPerms() || !texture.isAvailable || device != null || opening) return
        pickSizes(l)
        opening = true
        try {
            mgr.openCamera(l.logicalId, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { opening = false; device = d; startPreview() }
                override fun onDisconnected(d: CameraDevice) { opening = false; d.close(); device = null }
                override fun onError(d: CameraDevice, e: Int) {
                    opening = false; d.close(); device = null; toast("Camera error $e")
                    runOnUiThread { fadeInStage() }
                }
            }, bg)
        } catch (e: Exception) {
            opening = false
            toast("Open failed: ${e.message}")
            fadeInStage()
        }
    }

    private fun closeCamera() {
        try { session?.close() } catch (e: Exception) {}
        session = null
        try { device?.close() } catch (e: Exception) {}
        device = null
        try { reader?.close() } catch (e: Exception) {}
        reader = null
    }

    private fun reopen() {
        closeCamera()
        refreshCaps()
        buildZoomChips()
        tryOpen()
    }

    private fun sensorOri() = cur?.chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

    private fun logIso(range: Range<Int>): Int {
        val lo = range.lower.toDouble()
        val hi = min(range.upper, 6400).toDouble()
        return (lo * (max(hi, lo) / lo).pow((isoProg - 1) / 99.0)).toInt()
    }

    private fun logExp(range: Range<Long>): Long {
        val lo = max(range.lower, 125_000L).toDouble()
        val hi = min(range.upper, 500_000_000L).toDouble()
        return (lo * (max(hi, lo) / lo).pow((shutProg - 1) / 99.0)).toLong()
    }

    private fun applyCommon(b: CaptureRequest.Builder) {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        val video = mode == 1

        b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)

        val minFocus = lc.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (mode == 2 && focusProg > 0 && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * (focusProg - 1) / 99f)
        } else {
            b.set(
                CaptureRequest.CONTROL_AF_MODE,
                if (video) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            tapRegion?.let { b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(it)) }
        }
        tapRegion?.let { b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(it)) }

        val manualExp = mode == 2 && (isoProg > 0 || shutProg > 0)
        if (manualExp) {
            val isoR = lc.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 100)
            val expR = lc.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 1_000_000L)
            val iso = if (isoProg > 0) logIso(isoR) else 200.coerceIn(isoR.lower, isoR.upper)
            val exp = if (shutProg > 0) logExp(expR) else 16_666_667L.coerceIn(expR.lower, expR.upper)
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp)
        } else {
            val ae = if (!video && hasFlash) {
                when (flashMode) {
                    1 -> CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH
                    2 -> CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH
                    else -> CaptureRequest.CONTROL_AE_MODE_ON
                }
            } else CaptureRequest.CONTROL_AE_MODE_ON
            b.set(CaptureRequest.CONTROL_AE_MODE, ae)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev)
        }

        if (video && torch && hasFlash) b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)

        if (mode == 0 && hdr && hdrSupported) {
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_USE_SCENE_MODE)
            b.set(CaptureRequest.CONTROL_SCENE_MODE, CameraMetadata.CONTROL_SCENE_MODE_HDR)
        }

        if (video) {
            val fps = vidOpts.getOrNull(vidIdx)?.fps ?: 30
            val ranges = lc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList()
            val target = ranges.filter { it.upper == fps }.maxByOrNull { it.lower }
                ?: ranges.filter { it.lower <= fps && it.upper >= fps }.minByOrNull { it.upper - it.lower }
            if (target != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, target)
        }

        val ois = lc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        val oisOn = stab != 0 && ois?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        b.set(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            if (oisOn) CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON
            else CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_OFF
        )
        val modes = lc.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf(0)
        val m = if (!video) 0 else when (stab) {
            2 -> if (modes.contains(2)) 2 else if (modes.contains(1)) 1 else 0
            1 -> if (modes.contains(1)) 1 else 0
            else -> 0
        }
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, m)
    }

    private fun buildRepeating(d: CameraDevice): CaptureRequest.Builder {
        val b = d.createCaptureRequest(curTemplate)
        curTargets.forEach { b.addTarget(it) }
        applyCommon(b)
        return b
    }

    private fun updateRepeating() {
        val d = device ?: return
        val s = session ?: return
        try {
            s.setRepeatingRequest(buildRepeating(d).build(), null, bg)
        } catch (e: Exception) {
        }
    }

    private fun makeSession(
        d: CameraDevice,
        outputs: List<Surface>,
        targets: List<Surface>,
        template: Int,
        onReady: () -> Unit
    ) {
        try { session?.close() } catch (e: Exception) {}
        session = null
        curTemplate = template
        curTargets = targets
        val phys = cur?.physicalId
        val outs = outputs.map { s ->
            OutputConfiguration(s).also { if (phys != null) it.setPhysicalCameraId(phys) }
        }
        val req = buildRepeating(d)
        val cfg = SessionConfiguration(
            SessionConfiguration.SESSION_REGULAR,
            outs,
            Executor { r -> bg.post(r) },
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        s.setRepeatingRequest(req.build(), null, bg)
                        onReady()
                    } catch (e: Exception) {
                        toast("Preview failed: ${e.message}")
                    }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    toast("Session failed. Try another stabilization or video setting.")
                    runOnUiThread { fadeInStage() }
                }
            }
        )
        cfg.sessionParameters = req.build()
        try {
            d.createCaptureSession(cfg)
        } catch (e: Exception) {
            toast("Session error: ${e.message}")
        }
    }

    private fun startPreview() {
        val d = device ?: return
        val st = texture.surfaceTexture ?: return
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        runOnUiThread { layoutStage() }
        previewSurface?.release()
        val ps = Surface(st)
        previewSurface = ps
        try { reader?.close() } catch (e: Exception) {}
        reader = null
        val outs = mutableListOf(ps)
        if (mode != 1) {
            val r = ImageReader.newInstance(photoSize.width, photoSize.height, ImageFormat.JPEG, 2)
            reader = r
            outs.add(r.surface)
        }
        makeSession(d, outs, listOf(ps), CameraDevice.TEMPLATE_PREVIEW) {
            runOnUiThread { fadeInStage() }
        }
    }

    private fun fadeOutStage() {
        stage.animate().cancel()
        stage.animate().alpha(0.15f).setDuration(140).start()
        ui.removeCallbacks(fadeInSafety)
        ui.postDelayed(fadeInSafety, 1800)
    }

    private fun fadeInStage() {
        ui.removeCallbacks(fadeInSafety)
        stage.animate().cancel()
        stage.animate().alpha(1f).setDuration(260).start()
    }

    // ================= shutter / timer =================

    private fun shutterPressed() {
        if (counting) {
            counting = false
            countdownTv.visibility = View.GONE
            return
        }
        if (mode == 1 && recording) {
            haptic(HapticFeedbackConstants.CONFIRM)
            stopRecording(true)
            return
        }
        if (timerSec > 0) {
            counting = true
            tick(timerSec)
        } else doShutter()
    }

    private fun tick(n: Int) {
        if (!counting) { countdownTv.visibility = View.GONE; return }
        if (n == 0) {
            counting = false
            countdownTv.visibility = View.GONE
            doShutter()
            return
        }
        countdownTv.text = n.toString()
        countdownTv.alpha = 0f
        countdownTv.scaleX = 1.4f
        countdownTv.scaleY = 1.4f
        countdownTv.visibility = View.VISIBLE
        countdownTv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).start()
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        ui.postDelayed({ tick(n - 1) }, 1000)
    }

    private fun doShutter() {
        haptic(HapticFeedbackConstants.CONFIRM)
        if (mode == 1) startRecording() else takePhoto()
    }

    // ================= photo =================

    private fun takePhoto() {
        val d = device ?: return
        val s = session ?: return
        val r = reader ?: return
        val ps = previewSurface ?: return
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage()
            if (img != null) {
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    savePhoto(bytes)
                } finally {
                    img.close()
                }
            }
        }, bg)
        if (hasFlash && flashMode != 0 && mode != 1) {
            try {
                val p = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                p.addTarget(ps)
                applyCommon(p)
                p.set(
                    CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER,
                    CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START
                )
                s.capture(p.build(), null, bg)
            } catch (e: Exception) {
            }
            bg.postDelayed({ captureStill() }, 800)
        } else {
            captureStill()
        }
    }

    private fun captureStill() {
        val d = device ?: return
        val s = session ?: return
        val r = reader ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(r.surface)
            applyCommon(b)
            b.set(CaptureRequest.JPEG_ORIENTATION, sensorOri())
            b.set(CaptureRequest.JPEG_QUALITY, 95.toByte())
            s.capture(b.build(), null, bg)
            runOnUiThread {
                flashOverlay.animate().cancel()
                flashOverlay.alpha = 0.75f
                flashOverlay.animate().alpha(0f).setDuration(170).start()
            }
        } catch (e: Exception) {
            toast("Capture failed: ${e.message}")
        }
    }

    private fun savePhoto(bytes: ByteArray) {
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MyCam")
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) { toast("Could not save photo"); return }
        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        setThumb(uri)
    }

    private fun setThumb(uri: Uri) {
        lastUri = uri
        bg.post {
            try {
                val bm = contentResolver.loadThumbnail(uri, Size(200, 200), null)
                runOnUiThread {
                    thumb.setImageBitmap(bm)
                    thumb.scaleX = 0.5f
                    thumb.scaleY = 0.5f
                    thumb.animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(OvershootInterpolator(2.2f)).start()
                }
            } catch (e: Exception) {
            }
        }
    }

    // ================= video =================

    private fun startRecording() {
        val d = device ?: return
        val ps = previewSurface ?: return
        val o = vidOpts.getOrNull(vidIdx) ?: return
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/MyCam")
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        val pfd = if (uri != null) contentResolver.openFileDescriptor(uri, "w") else null
        if (pfd == null) { toast("Could not create video file"); return }
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setOutputFile(pfd.fileDescriptor)
            r.setVideoEncodingBitRate(o.bitrate)
            r.setVideoFrameRate(o.fps)
            r.setVideoSize(o.w, o.h)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOrientationHint(sensorOri())
            r.prepare()
        } catch (e: Exception) {
            toast("Recorder error: ${e.message}")
            r.release()
            pfd.close()
            return
        }
        recorder = r
        recPfd = pfd
        videoUri = uri
        makeSession(d, listOf(ps, r.surface), listOf(ps, r.surface), CameraDevice.TEMPLATE_RECORD) {
            runOnUiThread {
                try {
                    r.start()
                    recording = true
                    recStart = SystemClock.elapsedRealtime()
                    recTv.alpha = 0f
                    recTv.visibility = View.VISIBLE
                    recTv.animate().alpha(1f).setDuration(250).start()
                    shutter.setState(true, true)
                    ui.post(recTick)
                } catch (e: Exception) {
                    toast("Start failed: ${e.message}")
                }
            }
        }
    }

    private fun stopRecording(restart: Boolean) {
        try { session?.stopRepeating() } catch (e: Exception) {}
        try { session?.abortCaptures() } catch (e: Exception) {}
        var saved = true
        try { recorder?.stop() } catch (e: RuntimeException) { saved = false; toast("Recording too short") }
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recording = false
        ui.removeCallbacks(recTick)
        recTv.visibility = View.GONE
        shutter.setState(mode == 1, false)
        if (saved) videoUri?.let { setThumb(it) }
        if (restart) startPreview()
    }

    // ================= zoom / focus =================

    private fun showZoom() {
        zoomTv.text = String.format(Locale.US, "%.1fx", zoom)
        zoomTv.visibility = View.VISIBLE
        ui.removeCallbacks(hideZoom)
        ui.postDelayed(hideZoom, 1200)
    }

    private fun animateZoom(target: Float) {
        zoomAnim?.cancel()
        val a = ValueAnimator.ofFloat(zoom, target)
        a.duration = 380
        a.interpolator = DecelerateInterpolator(1.5f)
        a.addUpdateListener {
            zoom = it.animatedValue as Float
            updateRepeating()
            refreshZoomChips()
            showZoom()
        }
        a.start()
        zoomAnim = a
    }

    private fun selectZoom(v: Float) {
        if (recording && !logicalWide()) return
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        tapRegion = null
        if (v < 0.95f && !logicalWide()) {
            val u = ultraLens
            if (u != null && cur !== u) { zoomAnim?.cancel(); cur = u; zoom = 1f; reopen() }
        } else {
            val c = cur ?: return
            val m = mainLens
            if (ultraLens != null && c === ultraLens && m != null && c !== m) {
                zoomAnim?.cancel()
                cur = m
                zoom = v
                reopen()
            } else {
                val r = zoomRangeOf(c)
                animateZoom(v.coerceIn(r.lower, r.upper))
            }
        }
        refreshZoomChips()
    }

    private fun buildZoomChips() {
        zoomRow.removeAllViews()
        zoomChips.clear()
        val m = mainLens
        if (front || m == null) { zoomRow.visibility = View.GONE; return }
        zoomRow.visibility = View.VISIBLE
        val r = zoomRangeOf(m)
        val vals = mutableListOf<Float>()
        if (r.lower < 0.95f) vals.add(r.lower) else if (ultraLens != null) vals.add(0.6f)
        vals.add(1f)
        if (r.upper >= 2f) vals.add(2f)
        for (v in vals) {
            val tv = TextView(this)
            tv.textSize = 13f
            tv.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            tv.gravity = Gravity.CENTER
            tv.setOnClickListener { selectZoom(v) }
            pressable(tv, 0.88f)
            val lp = LinearLayout.LayoutParams(dp(40), dp(40))
            lp.leftMargin = dp(2)
            lp.rightMargin = dp(2)
            zoomRow.addView(tv, lp)
            zoomChips.add(Pair(tv, v))
        }
        refreshZoomChips()
    }

    private fun refreshZoomChips() {
        for ((tv, v) in zoomChips) {
            val ultraChip = v < 0.95f
            val onUltra = ultraLens != null && cur === ultraLens
            val active = if (ultraChip && !logicalWide()) onUltra else (abs(zoom - v) < 0.06f && !onUltra)
            val label = if (v < 1f) String.format(Locale.US, "%.1f", v) else v.roundToInt().toString()
            tv.text = if (active) label + "x" else label
            if (tv.tag != active) {
                tv.tag = active
                tv.setTextColor(if (active) accent else Color.WHITE)
                tv.background = oval(if (active) Color.parseColor("#B0000000") else Color.TRANSPARENT)
                val s = if (active) 1.12f else 0.9f
                tv.animate().scaleX(s).scaleY(s).setDuration(200).start()
            }
        }
    }

    private fun evOffsetPx(): Float {
        val l = cur ?: return 0f
        val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: return 0f
        if (er.upper <= er.lower) return 0f
        val frac = (ev - er.lower).toFloat() / (er.upper - er.lower).toFloat()
        return (0.5f - frac) * dp(80)
    }

    private fun positionSun() {
        val right = fx + dp(52) + dp(24) < stage.width
        val sx = if (right) fx + dp(52) else fx - dp(52) - dp(22)
        sunIcon.x = sx
        sunIcon.y = fy - dp(11) + evOffsetPx()
        focusLine.x = sx + dp(11) - dp(1)
        focusLine.y = fy - dp(44)
    }

    private fun scheduleFocusHide() {
        ui.removeCallbacks(hideFocus)
        ui.postDelayed(hideFocus, 3500)
    }

    private fun dragEv(dy: Float) {
        val l = cur ?: return
        val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: return
        if (er.upper <= er.lower) return
        evAccum += dy
        val unit = dp(10).toFloat()
        val steps = (evAccum / unit).toInt()
        if (steps != 0) {
            evAccum -= steps * unit
            ev = (ev + steps).coerceIn(er.lower, er.upper)
            evSeek.progress = ev - er.lower
            updateEvLabel()
            updateRepeating()
            positionSun()
        }
        scheduleFocusHide()
    }

    private fun focusAt(x: Float, y: Float) {
        val l = cur ?: return
        val w = stage.width.toFloat()
        val h = stage.height.toFloat()
        if (w <= 0f || h <= 0f) return
        var vx = x / w
        val vy = y / h
        if (front) vx = 1f - vx
        val a = lcOf(l.logicalId).get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        val sx: Float
        val sy: Float
        when (sensorOri()) {
            90 -> { sx = vy; sy = 1f - vx }
            270 -> { sx = 1f - vy; sy = vx }
            180 -> { sx = 1f - vx; sy = 1f - vy }
            else -> { sx = vx; sy = vy }
        }
        val px = a.left + (sx * a.width()).toInt()
        val py = a.top + (sy * a.height()).toInt()
        val half = (min(a.width(), a.height()) * 0.08f).toInt()
        val rect = Rect(
            max(a.left, px - half), max(a.top, py - half),
            min(a.right - 1, px + half), min(a.bottom - 1, py + half)
        )
        tapRegion = MeteringRectangle(rect, MeteringRectangle.METERING_WEIGHT_MAX - 1)
        updateRepeating()
        haptic(HapticFeedbackConstants.CLOCK_TICK)

        fx = x
        fy = y
        focusActive = true
        evAccum = 0f
        val size = dp(76)
        focusBox.animate().cancel()
        focusBox.x = x - size / 2f
        focusBox.y = y - size / 2f
        focusBox.alpha = 1f
        focusBox.scaleX = 1.4f
        focusBox.scaleY = 1.4f
        focusBox.visibility = View.VISIBLE
        focusBox.animate().scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(DecelerateInterpolator(1.4f)).start()
        for (v in listOf<View>(focusLine, sunIcon)) {
            v.animate().cancel()
            v.alpha = 0f
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(220).start()
        }
        positionSun()
        scheduleFocusHide()
    }

    // ================= settings / state =================

    private fun refreshCaps() {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        hasFlash = lc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        flashIcon.visibility = if (hasFlash) View.VISIBLE else View.INVISIBLE
        hdrSupported = lc.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)
            ?.contains(CameraMetadata.CONTROL_SCENE_MODE_HDR) == true
        hdrRow.visibility = if (hdrSupported) View.VISIBLE else View.GONE
        val er = lc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = lc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        evRow.visibility = if (er.upper > er.lower) View.VISIBLE else View.GONE
        evSeek.max = er.upper - er.lower
        ev = ev.coerceIn(er.lower, er.upper)
        evSeek.progress = ev - er.lower
        updateEvLabel()
        updateProLabels()
        updateFlashChip()
    }

    private fun updateEvLabel() {
        evLabel.text = "Exposure  " + String.format(Locale.US, "%+.1f", ev * evStep)
    }

    private fun fmtShutter(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/" + (1.0 / s).roundToInt()
    }

    private fun updateProLabels() {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        val isoR = lc.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 100)
        val expR = lc.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 1_000_000L)
        isoLabel.text = if (isoProg == 0) "ISO  Auto" else "ISO  " + logIso(isoR)
        shutLabel.text = if (shutProg == 0) "Shutter  Auto" else "Shutter  " + fmtShutter(logExp(expR))
        focusLabel.text = if (focusProg == 0) "Focus  Auto" else "Focus  Manual"
    }

    private fun updateFlashChip() {
        val st = if (mode == 1) (if (torch) 2 else 0) else flashMode
        flashIcon.state = st
        flashIcon.tint = if (st != 0) accent else Color.WHITE
    }

    private fun animateVisibility(v: View, show: Boolean, animate: Boolean = true) {
        v.animate().cancel()
        v.tag = show
        if (!animate) {
            v.alpha = 1f
            v.translationY = 0f
            v.visibility = if (show) View.VISIBLE else View.GONE
            return
        }
        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.alpha = 0f
                v.translationY = dp(28).toFloat()
                v.visibility = View.VISIBLE
            }
            v.animate().alpha(1f).translationY(0f).setDuration(260)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        } else {
            v.animate().alpha(0f).translationY(dp(28).toFloat()).setDuration(200)
                .withEndAction { if (v.tag == false) v.visibility = View.GONE }.start()
        }
    }

    private fun toggleSheet() {
        val show = sheet.visibility != View.VISIBLE || sheet.tag == false
        animateVisibility(sheet, show)
        chevron.animate().rotation(if (show) 180f else 0f).setDuration(260).start()
        chevron.tint = if (show) accent else Color.WHITE
        haptic(HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun centerModeBar(animate: Boolean) {
        val tv = tabs[mode] ?: return
        if (modeBar.width == 0 || tv.width == 0) {
            modeBar.post { centerModeBar(false) }
            return
        }
        val target = modeBar.width / 2f - (tv.left + tv.width / 2f)
        if (animate) {
            modeRow.animate().translationX(target).setDuration(300)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        } else {
            modeRow.animate().cancel()
            modeRow.translationX = target
        }
    }

    private fun refreshModeUi(animate: Boolean) {
        for ((i, t) in tabs) {
            val sel = i == mode
            t.setTextColor(if (sel) accent else Color.WHITE)
            t.animate().alpha(if (sel) 1f else 0.6f).scaleX(if (sel) 1f else 0.88f)
                .scaleY(if (sel) 1f else 0.88f).setDuration(if (animate) 250L else 0L).start()
        }
        shutter.setState(mode == 1, recording)
        animateVisibility(proSheet, mode == 2, animate)
        centerModeBar(animate)
        updateFlashChip()
    }

    private fun setMode(m: Int) {
        if (recording || counting || m == mode) return
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        mode = m
        tapRegion = null
        refreshModeUi(true)
        val l = cur ?: return
        pickSizes(l)
        if (device != null) {
            fadeOutStage()
            startPreview()
        }
    }

    private fun swipeMode(dir: Int) {
        val pos = modeOrder.indexOf(mode)
        val np = (pos + dir).coerceIn(0, modeOrder.size - 1)
        if (np != pos) setMode(modeOrder[np])
    }

    private fun flipCamera() {
        if (recording) return
        val target = if (front) mainLens else frontLens
        if (target == null) { toast("No front camera found"); return }
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        flipBtn.animate().rotationBy(180f).setDuration(350).start()
        front = !front
        cur = target
        zoom = 1f
        tapRegion = null
        fadeOutStage()
        texture.scaleX = if (front) -1f else 1f
        reopen()
    }

    // ================= ui building =================

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun pressable(v: View, s: Float = 0.9f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(s).scaleY(s).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(240)
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun chip(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 14f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(7), dp(14), dp(7))
        t.background = rounded(Color.parseColor("#33FFFFFF"), dp(18).toFloat())
        pressable(t, 0.94f)
        return t
    }

    private fun settingRow(label: String, view: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(4), 0, dp(4))
        val l = TextView(this)
        l.text = label
        l.setTextColor(Color.parseColor("#C8FFFFFF"))
        l.textSize = 14f
        r.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(view)
        return r
    }

    private fun seekRow(label: TextView, seek: SeekBar): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        label.setTextColor(Color.WHITE)
        label.textSize = 13f
        r.addView(label, LinearLayout.LayoutParams(dp(120), -2))
        seek.progressTintList = ColorStateList.valueOf(accent)
        seek.thumbTintList = ColorStateList.valueOf(accent)
        r.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        return r
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val sw = resources.displayMetrics.widthPixels

        // ----- viewfinder -----
        stage = FrameLayout(this)
        stage.setBackgroundColor(Color.BLACK)
        stage.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(24).toFloat())
            }
        }
        stage.clipToOutline = true
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> stage.invalidateOutline() }

        texture = TextureView(this)
        stage.addView(texture, FrameLayout.LayoutParams(-1, -1))
        grid = CamGrid(this)
        grid.visibility = View.GONE
        stage.addView(grid, FrameLayout.LayoutParams(-1, -1))
        flashOverlay = View(this)
        flashOverlay.setBackgroundColor(Color.BLACK)
        flashOverlay.alpha = 0f
        stage.addView(flashOverlay, FrameLayout.LayoutParams(-1, -1))

        focusBox = View(this)
        val boxBg = GradientDrawable()
        boxBg.shape = GradientDrawable.RECTANGLE
        boxBg.setColor(Color.TRANSPARENT)
        boxBg.setStroke(dp(2), accent)
        focusBox.background = boxBg
        focusBox.visibility = View.GONE
        stage.addView(focusBox, FrameLayout.LayoutParams(dp(76), dp(76)))
        focusLine = View(this)
        focusLine.setBackgroundColor(Color.parseColor("#99FFD60A"))
        focusLine.visibility = View.GONE
        stage.addView(focusLine, FrameLayout.LayoutParams(dp(2), dp(88)))
        sunIcon = CamIcon(this, 3)
        sunIcon.tint = accent
        sunIcon.visibility = View.GONE
        stage.addView(sunIcon, FrameLayout.LayoutParams(dp(22), dp(22)))

        countdownTv = TextView(this)
        countdownTv.setTextColor(Color.WHITE)
        countdownTv.textSize = 96f
        countdownTv.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        countdownTv.visibility = View.GONE
        stage.addView(countdownTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        zoomTv = TextView(this)
        zoomTv.setTextColor(accent)
        zoomTv.textSize = 15f
        zoomTv.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        zoomTv.setPadding(dp(14), dp(5), dp(14), dp(5))
        zoomTv.background = rounded(Color.parseColor("#80000000"), dp(16).toFloat())
        zoomTv.visibility = View.GONE
        val zlp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        zlp.bottomMargin = dp(76)
        stage.addView(zoomTv, zlp)

        zoomRow = LinearLayout(this)
        zoomRow.orientation = LinearLayout.HORIZONTAL
        zoomRow.gravity = Gravity.CENTER
        zoomRow.setPadding(dp(4), dp(4), dp(4), dp(4))
        zoomRow.background = rounded(Color.parseColor("#66000000"), dp(30).toFloat())
        val zrp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        zrp.bottomMargin = dp(14)
        stage.addView(zoomRow, zrp)

        recTv = TextView(this)
        recTv.setTextColor(Color.WHITE)
        recTv.textSize = 14f
        recTv.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        recTv.setPadding(dp(12), dp(5), dp(12), dp(5))
        recTv.background = rounded(Color.parseColor("#CCFF3B30"), dp(14).toFloat())
        recTv.visibility = View.GONE
        val rlp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        rlp.topMargin = dp(12)
        stage.addView(recTv, rlp)

        val slp = FrameLayout.LayoutParams(sw, sw * 4 / 3, Gravity.TOP)
        slp.topMargin = dp(52)
        root.addView(stage, slp)

        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val c = cur ?: return true
                zoomAnim?.cancel()
                val r = zoomRangeOf(c)
                val lo = if (ultraLens != null && c === ultraLens) 1f else r.lower
                zoom = (zoom * d.scaleFactor).coerceIn(lo, r.upper)
                updateRepeating()
                refreshZoomChips()
                showZoom()
                return true
            }
        })
        val tapDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { focusAt(e.x, e.y); return true }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (focusActive && abs(dy) > abs(dx)) { dragEv(dy); return true }
                return false
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > 1200f && abs(vx) > abs(vy) * 1.5f) {
                    swipeMode(if (vx < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        stage.setOnTouchListener { _, ev ->
            scaleDet.onTouchEvent(ev)
            if (!scaleDet.isInProgress) tapDet.onTouchEvent(ev)
            true
        }

        // ----- top bar -----
        val topBar = FrameLayout(this)
        flashIcon = CamIcon(this, 0)
        timerIcon = CamIcon(this, 1)
        chevron = CamIcon(this, 2)
        fun slot(icon: CamIcon, gravity: Int, margin: Int): FrameLayout {
            val f = FrameLayout(this)
            f.addView(icon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            pressable(f, 0.85f)
            val lp = FrameLayout.LayoutParams(dp(48), dp(48), gravity or Gravity.CENTER_VERTICAL)
            lp.leftMargin = margin
            lp.rightMargin = margin
            topBar.addView(f, lp)
            return f
        }
        slot(flashIcon, Gravity.START, dp(12)).setOnClickListener {
            if (mode == 1) torch = !torch else flashMode = (flashMode + 1) % 3
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            updateFlashChip()
            updateRepeating()
        }
        slot(chevron, Gravity.CENTER_HORIZONTAL, 0).setOnClickListener { toggleSheet() }
        slot(timerIcon, Gravity.END, dp(12)).setOnClickListener {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            timerIcon.label = if (timerSec == 0) "" else timerSec.toString()
            timerIcon.tint = if (timerSec != 0) accent else Color.WHITE
            haptic(HapticFeedbackConstants.CLOCK_TICK)
        }
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP))

        // ----- bottom panel -----
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER_HORIZONTAL
        panel.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.TRANSPARENT, Color.parseColor("#E6000000"))
        )
        panel.setPadding(dp(12), dp(8), dp(12), dp(10))

        // settings sheet
        sheet = LinearLayout(this)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.background = rounded(Color.parseColor("#EE1C1C1E"), dp(26).toFloat())
        sheet.setPadding(dp(18), dp(10), dp(18), dp(10))
        sheet.visibility = View.GONE
        sheet.tag = false

        ratioChip = chip("4:3")
        ratioChip.setOnClickListener {
            ratio43 = !ratio43
            ratioChip.text = if (ratio43) "4:3" else "16:9"
            val l = cur
            if (l != null && !recording) {
                pickSizes(l)
                if (mode != 1 && device != null) { fadeOutStage(); startPreview() }
            }
        }
        vidChip = chip("1080p 30")
        vidChip.setOnClickListener {
            if (!recording && vidOpts.isNotEmpty()) {
                vidIdx = (vidIdx + 1) % vidOpts.size
                vidLabel = vidOpts[vidIdx].label
                vidChip.text = vidLabel
                updateRepeating()
            }
        }
        stabChip = chip("Standard")
        stabChip.setOnClickListener {
            if (!recording) {
                stab = (stab + 1) % 3
                stabChip.text = stabNames[stab]
                if (device != null) startPreview()
            }
        }
        hdrChip = chip("Off")
        hdrChip.setOnClickListener {
            hdr = !hdr
            hdrChip.text = if (hdr) "On" else "Off"
            hdrChip.setTextColor(if (hdr) accent else Color.WHITE)
            updateRepeating()
        }
        gridChip = chip("Off")
        gridChip.setOnClickListener {
            val on = grid.visibility != View.VISIBLE
            grid.visibility = if (on) View.VISIBLE else View.GONE
            gridChip.text = if (on) "On" else "Off"
            gridChip.setTextColor(if (on) accent else Color.WHITE)
        }
        val infoChip = chip("Show")
        infoChip.setOnClickListener { showInfo() }

        evLabel = TextView(this)
        evSeek = SeekBar(this)
        evSeek.setOnSeekBarChangeListener(seekListener { p ->
            val l = cur
            if (l != null) {
                val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                ev = p + (er?.lower ?: 0)
                updateEvLabel()
                updateRepeating()
            }
        })
        evRow = LinearLayout(this)
        evRow.orientation = LinearLayout.HORIZONTAL
        evRow.gravity = Gravity.CENTER_VERTICAL
        evLabel.setTextColor(Color.parseColor("#C8FFFFFF"))
        evLabel.textSize = 14f
        evSeek.progressTintList = ColorStateList.valueOf(accent)
        evSeek.thumbTintList = ColorStateList.valueOf(accent)
        evRow.addView(evLabel, LinearLayout.LayoutParams(dp(120), -2))
        evRow.addView(evSeek, LinearLayout.LayoutParams(0, -2, 1f))

        sheet.addView(settingRow("Photo ratio", ratioChip))
        sheet.addView(settingRow("Video quality", vidChip))
        sheet.addView(settingRow("Stabilization", stabChip))
        hdrRow = settingRow("HDR", hdrChip)
        sheet.addView(hdrRow)
        sheet.addView(settingRow("Grid", gridChip))
        sheet.addView(evRow)
        sheet.addView(settingRow("Camera info", infoChip))
        val shlp = LinearLayout.LayoutParams(-1, -2)
        shlp.bottomMargin = dp(8)
        panel.addView(sheet, shlp)

        // pro sheet
        proSheet = LinearLayout(this)
        proSheet.orientation = LinearLayout.VERTICAL
        proSheet.background = rounded(Color.parseColor("#EE1C1C1E"), dp(26).toFloat())
        proSheet.setPadding(dp(18), dp(8), dp(18), dp(8))
        proSheet.visibility = View.GONE
        proSheet.tag = false
        isoLabel = TextView(this)
        shutLabel = TextView(this)
        focusLabel = TextView(this)
        isoSeek = SeekBar(this)
        shutSeek = SeekBar(this)
        focusSeek = SeekBar(this)
        isoSeek.max = 100
        shutSeek.max = 100
        focusSeek.max = 100
        isoSeek.setOnSeekBarChangeListener(seekListener { p -> isoProg = p; updateProLabels(); updateRepeating() })
        shutSeek.setOnSeekBarChangeListener(seekListener { p -> shutProg = p; updateProLabels(); updateRepeating() })
        focusSeek.setOnSeekBarChangeListener(seekListener { p -> focusProg = p; updateProLabels(); updateRepeating() })
        proSheet.addView(seekRow(isoLabel, isoSeek))
        proSheet.addView(seekRow(shutLabel, shutSeek))
        proSheet.addView(seekRow(focusLabel, focusSeek))
        val plp = LinearLayout.LayoutParams(-1, -2)
        plp.bottomMargin = dp(8)
        panel.addView(proSheet, plp)

        // mode carousel (selected mode slides to the centre)
        modeBar = FrameLayout(this)
        modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        val names = mapOf(0 to "PHOTO", 1 to "VIDEO", 2 to "PRO")
        for (m in modeOrder) {
            val t = TextView(this)
            t.text = names[m]
            t.textSize = 13f
            t.letterSpacing = 0.08f
            t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            t.setPadding(dp(16), dp(10), dp(16), dp(10))
            t.setOnClickListener { setMode(m) }
            tabs[m] = t
            modeRow.addView(t)
        }
        modeBar.addView(modeRow, FrameLayout.LayoutParams(-2, -2))
        panel.addView(modeBar, LinearLayout.LayoutParams(-1, dp(44)))

        // control row: gallery | shutter | flip
        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER_VERTICAL

        thumb = ImageView(this)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.background = rounded(Color.parseColor("#33FFFFFF"), dp(10).toFloat())
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
            }
        }
        thumb.clipToOutline = true
        pressable(thumb, 0.9f)
        thumb.setOnClickListener {
            val u = lastUri
            try {
                if (u != null) {
                    val i = Intent(Intent.ACTION_VIEW, u)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(i)
                } else {
                    startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
                }
            } catch (e: Exception) {
                toast("No gallery app found")
            }
        }

        shutter = CamShutter(this)
        pressable(shutter, 0.9f)
        shutter.setOnClickListener { shutterPressed() }

        flipBtn = TextView(this)
        flipBtn.text = "\u27F3"
        flipBtn.setTextColor(Color.WHITE)
        flipBtn.textSize = 24f
        flipBtn.gravity = Gravity.CENTER
        flipBtn.background = oval(Color.parseColor("#33FFFFFF"))
        pressable(flipBtn, 0.9f)
        flipBtn.setOnClickListener { flipCamera() }

        fun cell(v: View, size: Int): FrameLayout {
            val f = FrameLayout(this)
            f.addView(v, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
            return f
        }
        controls.addView(cell(thumb, dp(52)), LinearLayout.LayoutParams(0, dp(92), 1f))
        controls.addView(cell(shutter, dp(84)), LinearLayout.LayoutParams(0, dp(92), 1f))
        controls.addView(cell(flipBtn, dp(52)), LinearLayout.LayoutParams(0, dp(92), 1f))
        panel.addView(controls, LinearLayout.LayoutParams(-1, -2))

        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { tryOpen() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }
}

private class CamShutter(c: Context) : View(c) {
    private var video = false
    private var morph = 0f // 0 = circle, 1 = rounded square (recording)
    private var red = 0f
    private var anim: ValueAnimator? = null
    private val d = c.resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 3.5f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val eval = ArgbEvaluator()

    fun setState(v: Boolean, r: Boolean) {
        video = v
        val m0 = morph
        val r0 = red
        val mt = if (r) 1f else 0f
        val rt = if (v) 1f else 0f
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 280
        a.interpolator = DecelerateInterpolator(1.5f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            morph = m0 + (mt - m0) * f
            red = r0 + (rt - r0) * f
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - ring.strokeWidth
        canvas.drawCircle(cx, cy, r, ring)
        fill.color = eval.evaluate(red, Color.WHITE, Color.parseColor("#FF3B30")) as Int
        val half = r * (0.82f + (0.42f - 0.82f) * morph)
        val corner = half + (half * 0.3f - half) * morph
        canvas.drawRoundRect(cx - half, cy - half, cx + half, cy + half, corner, corner, fill)
    }
}

private class CamGrid(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(110, 255, 255, 255)
        strokeWidth = 1.2f * c.resources.displayMetrics.density
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, p)
            canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, p)
        }
    }
}

// types: 0 flash, 1 timer, 2 chevron, 3 sun
private class CamIcon(c: Context, private val type: Int) : View(c) {
    var tint = Color.WHITE
        set(v) { field = v; invalidate() }
    var state = 0
        set(v) { field = v; invalidate() }
    var label = ""
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        canvas.scale(s, s)
        p.color = tint
        p.strokeWidth = 1.8f
        p.style = Paint.Style.STROKE
        tp.color = tint
        when (type) {
            0 -> {
                path.reset()
                path.moveTo(13f, 2.5f)
                path.lineTo(5.5f, 13f)
                path.lineTo(11f, 13f)
                path.lineTo(10f, 21.5f)
                path.lineTo(18.5f, 10.5f)
                path.lineTo(13f, 10.5f)
                path.close()
                p.style = if (state == 2) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
                canvas.drawPath(path, p)
                p.style = Paint.Style.STROKE
                if (state == 0) canvas.drawLine(4f, 4f, 20f, 20f, p)
                if (state == 1) {
                    tp.textSize = 9f
                    canvas.drawText("A", 19f, 21f, tp)
                }
            }
            1 -> {
                canvas.drawCircle(12f, 13.5f, 7.5f, p)
                canvas.drawLine(9.5f, 3f, 14.5f, 3f, p)
                if (label.isEmpty()) {
                    canvas.drawLine(12f, 13.5f, 12f, 9.5f, p)
                } else {
                    tp.textSize = 9f
                    canvas.drawText(label, 12f, 16.7f, tp)
                }
            }
            2 -> {
                path.reset()
                path.moveTo(5f, 9f)
                path.lineTo(12f, 16f)
                path.lineTo(19f, 9f)
                canvas.drawPath(path, p)
            }
            3 -> {
                canvas.drawCircle(12f, 12f, 4.2f, p)
                for (i in 0 until 8) {
                    canvas.drawLine(12f, 2.2f, 12f, 5f, p)
                    canvas.rotate(45f, 12f, 12f)
                }
            }
        }
        canvas.restore()
    }
}
