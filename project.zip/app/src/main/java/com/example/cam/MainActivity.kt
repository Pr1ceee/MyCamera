package com.example.cam

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ExifInterface
import android.media.ImageReader
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Choreographer
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

class MainActivity : Activity() {

    class Lens(val logicalId: String, val physicalId: String?, val chars: CameraCharacteristics)
    class VidOpt(
        val w: Int, val h: Int, val fps: Int, val bitrate: Int,
        val label: String, val short: String, val ok: Boolean
    )

    private val accent = Color.parseColor("#FFD60A")
    private val ios = PathInterpolator(0.22f, 1f, 0.36f, 1f)

    // camera state
    private lateinit var mgr: CameraManager
    private val lcCache = HashMap<String, CameraCharacteristics>()
    private var mainLens: Lens? = null
    private var ultraLens: Lens? = null
    private var frontLens: Lens? = null
    private var cur: Lens? = null
    private var front = false
    private var hiddenIds = listOf<String>()
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var opening = false
    private var configuring = false
    private var failCount = 0
    private var lastFailAt = 0L
    private var awaitFirstFrame = false
    @Volatile private var selfieRef: Bitmap? = null
    @Volatile private var selfieShot = false
    private var openRetries = 0
    private var sessionGen = 0
    private var staleReader: ImageReader? = null
    private var fpsProbing = false
    private var fpsCount = 0
    private var fpsFirstTs = 0L
    private var fps60Off = false
    private var photoOpts: List<Size> = emptyList()
    private var photoIdx = 0
    private var photoPrefMp = 12
    private val prefs by lazy { getSharedPreferences("mycam", MODE_PRIVATE) }
    private var pillAnim: ValueAnimator? = null
    private val glassViews = mutableListOf<View>()

    // A blurred RenderNode is cached as an offscreen layer and only redrawn when its content is
    // re-recorded, so the glass panels would keep showing the frame from when they were first
    // drawn. Invalidating them about 30 times a second keeps the blur live.
    private var glassPhase = false
    private val glassPump = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            glassPhase = !glassPhase
            if (glassPhase) {
                for (v in glassViews) if (v.visibility == View.VISIBLE && v.alpha > 0.01f) v.invalidate()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private var dialActive = false
    private var dialLastX = Float.NaN
    private val hideDial = Runnable {
        zoomDial.animate().alpha(0f).translationYBy(dp(20).toFloat()).setDuration(240).setInterpolator(ios)
            .withEndAction { if (!dialActive) zoomDial.visibility = View.GONE }.start()
        if (sheet.tag != true) zoomRow.animate().alpha(1f).setDuration(280).start()
    }
    private var pillBase = 0f
    private var pillSlide = 0f
    private var slideAnim: ValueAnimator? = null
    private var lensSwitching = false
    private var snapNear = false
    private var mirrorFront = true
    private var previewSurface: Surface? = null
    private var reader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recording = false
    private var recStart = 0L
    private var videoUri: Uri? = null
    private var lastUri: Uri? = null
    private var curTemplate = CameraDevice.TEMPLATE_PREVIEW
    private var curTargets: List<Surface> = emptyList()
    private val thread = HandlerThread("cam").also { it.start() }
    private val bg = Handler(thread.looper)
    private val ui = Handler(Looper.getMainLooper())

    // settings state
    private var mode = 0 // 0 photo, 1 video, 2 pro
    private var flashMode = 0 // photo: 0 off, 1 auto, 2 on
    private var torch = false // video
    private var timerSec = 0
    private var hdr = false
    private var ratio43 = true
    private var vidIdx = 0
    private var vidLabel = "1080p 30"
    private var vidOpts: List<VidOpt> = emptyList()
    private val stabNames = arrayOf("Off", "Optical", "Standard", "Preview")
    private var stab = 2 // 0 off, 1 optical, 2 standard (optical + electronic), 3 preview stabilization
    private val stabCap = HashMap<String, Int>()
    private var ev = 0
    private var evStep = 0f
    private var evAccum = 0f
    private var zoom = 1f
    private var tapRegion: MeteringRectangle? = null
    private var isoProg = 0
    private var shutProg = 0
    private var focusProg = 0
    private var hasFlash = false
    private var hdrSupported = false
    private var counting = false
    private var focusActive = false
    private var fx = 0f
    private var fy = 0f
    private var previewSize = Size(1920, 1080)
    private var photoSize = Size(1920, 1080)
    private var zoomAnim: ValueAnimator? = null
    private var stageAnim: ValueAnimator? = null
    private var blurNow = 0f
    private var blurAnim: ValueAnimator? = null

    // ui
    private lateinit var stage: FrameLayout
    private lateinit var rootView: FrameLayout
    private lateinit var panelView: LinearLayout
    private lateinit var texture: TextureView
    private lateinit var grid: CamGrid
    private lateinit var flashOverlay: View
    private lateinit var focusBox: View
    private lateinit var focusLine: View
    private lateinit var sunIcon: CamIcon
    private lateinit var countdownTv: TextView
    private lateinit var recTv: TextView
    private lateinit var topBar: FrameLayout
    private lateinit var topScrim: View
    private lateinit var flashIcon: CamIcon
    private lateinit var timerIcon: CamIcon
    private lateinit var chevron: CamIcon
    private lateinit var sheetHost: LinearLayout
    private lateinit var sheet: LinearLayout
    private lateinit var proSheet: LinearLayout
    private lateinit var zoomRow: LinearLayout
    private lateinit var zoomGlass: GlassLinear
    private lateinit var zoomDial: ZoomDial
    private lateinit var modeBar: FrameLayout
    private lateinit var modeRow: LinearLayout
    private lateinit var shutter: CamShutter
    private lateinit var thumb: ImageView
    private lateinit var thumbCell: FrameLayout
    private lateinit var flipCell: FrameLayout
    private lateinit var flipBtn: TextView
    private lateinit var ratioSeg: SegControl
    private lateinit var vidSeg: SegControl
    private lateinit var photoSeg: SegControl
    private lateinit var mirrorSeg: SegControl
    private lateinit var ratioRow: LinearLayout
    private lateinit var photoRow: LinearLayout
    private lateinit var vidRow: LinearLayout
    private lateinit var stabSeg: SegControl
    private lateinit var hdrSeg: SegControl
    private lateinit var gridSeg: SegControl
    private lateinit var hdrRow: LinearLayout
    private lateinit var evSeek: SeekBar
    private lateinit var evLabel: TextView
    private lateinit var evRow: LinearLayout
    private lateinit var isoSeek: SeekBar
    private lateinit var shutSeek: SeekBar
    private lateinit var focusSeek: SeekBar
    private lateinit var isoLabel: TextView
    private lateinit var shutLabel: TextView
    private lateinit var focusLabel: TextView
    private val tabs = HashMap<Int, TextView>()
    private val zoomChips = mutableListOf<Pair<TextView, Float>>()
    private val modeOrder = listOf(1, 0, 2) // display order: VIDEO, PHOTO, PRO

    private val fadeInSafety = Runnable { fadeInStage() }
    private val hideFocus = Runnable {
        focusActive = false
        for (v in listOf<View>(focusBox, focusLine, sunIcon)) {
            v.animate().alpha(0f).setDuration(250).withEndAction {
                if (!focusActive) v.visibility = View.GONE
            }.start()
        }
    }
    private val recTick = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000
            recTv.text = String.format(Locale.US, "\u25CF %02d:%02d", s / 60, s % 60)
            ui.postDelayed(this, 500)
        }
    }

    // ================= lifecycle =================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        mgr = getSystemService(CAMERA_SERVICE) as CameraManager
        fps60Off = prefs.getBoolean("fps60_off", false)
        mirrorFront = prefs.getBoolean("mirror_front", true)
        try { setupLenses() } catch (e: Exception) { toast("Camera setup failed: ${e.message}") }
        cur = mainLens
        buildUi()
        refreshCaps()
        buildZoomChips()
        refreshModeUi(false)
        if (!hasPerms()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasPerms()) tryOpen() else toast("Camera and microphone permissions are required")
    }

    override fun onResume() {
        super.onResume()
        // coming back from the gallery: reveal the viewfinder once the first frame arrives
        if (device == null && hasPerms()) fadeOutStage()
        tryOpen()
        loadLatestThumb()
        Choreographer.getInstance().removeFrameCallback(glassPump)
        Choreographer.getInstance().postFrameCallback(glassPump)
    }

    // the thumbnail shows the newest photo or video, also after restarting the app
    private fun loadLatestThumb() {
        bg.post {
            val u = GalleryView.latestUri(this)
            if (u != null && u != lastUri) setThumb(u)
        }
    }

    override fun onPause() {
        Choreographer.getInstance().removeFrameCallback(glassPump)
        if (dialActive) {
            dialActive = false
            zoomGlass.dialMode = false
        }
        ui.removeCallbacks(hideDial)
        zoomDial.visibility = View.GONE
        zoomRow.alpha = if (sheet.tag == true) 0f else 1f
        counting = false
        countdownTv.visibility = View.GONE
        if (recording) stopRecording(false)
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        thread.quitSafely()
        super.onDestroy()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if ((event?.repeatCount ?: 0) == 0) shutterPressed()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun hasPerms() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun haptic(type: Int) { window.decorView.performHapticFeedback(type) }

    // ================= camera discovery =================

    private fun lcOf(id: String): CameraCharacteristics = lcCache.getOrPut(id) { mgr.getCameraCharacteristics(id) }

    private fun zoomRangeOf(l: Lens): Range<Float> =
        lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) ?: Range(1f, 1f)

    private fun equiv(c: CameraCharacteristics): Double? {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return null
        val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        return f * 43.27 / hypot(s.width.toDouble(), s.height.toDouble())
    }

    private fun compat(c: CameraCharacteristics) =
        c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) == true

    private fun logicalWide(): Boolean {
        val m = mainLens ?: return false
        return zoomRangeOf(m).lower < 0.95f
    }

    private fun setupLenses() {
        val ids = mgr.cameraIdList.sortedBy { it.toIntOrNull() ?: 999 }
        val backs = mutableListOf<Lens>()
        for (id in ids) {
            val c = lcOf(id)
            if (!compat(c)) continue
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            if (facing == CameraCharacteristics.LENS_FACING_BACK) backs.add(Lens(id, null, c))
            else if (facing == CameraCharacteristics.LENS_FACING_FRONT && frontLens == null) frontLens = Lens(id, null, c)
        }
        mainLens = backs.minByOrNull { zoomRangeOf(it).lower }
        val main = mainLens ?: return
        if (!logicalWide()) {
            val mainEq = equiv(main.chars) ?: return
            val cands = mutableListOf<Lens>()
            for (b in backs) {
                if (b !== main) cands.add(b)
                for (pid in b.chars.physicalCameraIds) {
                    if (pid !in ids) cands.add(Lens(b.logicalId, pid, mgr.getCameraCharacteristics(pid)))
                }
            }
            val hidden = mutableListOf<String>()
            for (i in 2..9) {
                val id = i.toString()
                if (id in ids) continue
                try {
                    val c = mgr.getCameraCharacteristics(id)
                    if (compat(c) && c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK) {
                        lcCache[id] = c
                        cands.add(Lens(id, null, c))
                        hidden.add(id)
                    }
                } catch (e: Exception) {
                }
            }
            hiddenIds = hidden
            ultraLens = cands
                .filter { val e = equiv(it.chars); e != null && e < mainEq * 0.8 }
                .minByOrNull { equiv(it.chars)!! }
        }
    }

    private fun showInfo() {
        val sb = StringBuilder()
        for (id in mgr.cameraIdList) {
            val c = lcOf(id)
            val eq = equiv(c)?.let { String.format(Locale.US, "%.1f", it) }
            sb.append("ID ").append(id)
                .append(" facing=").append(c.get(CameraCharacteristics.LENS_FACING))
                .append(" zoom=").append(c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE))
                .append(" phys=").append(c.physicalCameraIds)
                .append(" mm=").append(eq).append("\n")
        }
        sb.append("\nUsing: ").append(cur?.logicalId).append(" / ").append(cur?.physicalId)
        sb.append("\nLogical wide: ").append(logicalWide())
        sb.append("\nHidden IDs responding: ").append(hiddenIds)
        sb.append("\nUltra fallback: ").append(ultraLens?.let { it.logicalId + "/" + it.physicalId })
        sb.append("\nStabilization limits: ").append(stabCap)
        sb.append("\n60 fps blocked: ").append(fps60Off)
        val mlc = mainLens?.let { lcOf(it.logicalId) }
        if (mlc != null) {
            val rk = mlc.availableCaptureRequestKeys.map { it.name }.filter { !it.startsWith("android.") }
            val sk = (mlc.availableSessionKeys ?: emptyList()).map { it.name }.filter { !it.startsWith("android.") }
            sb.append("\nVendor request keys: ").append(if (rk.isEmpty()) "none" else rk.joinToString(", "))
            sb.append("\nVendor session keys: ").append(if (sk.isEmpty()) "none" else sk.joinToString(", "))
        }
        val m = mainLens
        if (m != null) {
            val lc = lcOf(m.logicalId)
            sb.append("\n\nAE fps ranges: ").append(
                lc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                    ?.joinToString(" ") { r -> "${r.lower}-${r.upper}" }
            )
            val mp = m.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            if (mp != null) {
                for ((w, h) in listOf(Pair(3840, 2160), Pair(1920, 1080), Pair(1280, 720))) {
                    val d = mp.getOutputMinFrameDuration(MediaRecorder::class.java, Size(w, h))
                    sb.append("\n").append(h).append("p max fps: ")
                        .append(if (d > 0L) (1e9 / d).roundToInt().toString() else "?")
                }
                val hs = mp.highSpeedVideoSizes
                sb.append("\nHigh-speed: ")
                if (hs.isEmpty()) sb.append("none")
                for (s in hs) {
                    sb.append(s.width).append("x").append(s.height).append(" ")
                    sb.append(mp.getHighSpeedVideoFpsRangesFor(s).joinToString(",", "[", "] ") { r -> "${r.lower}-${r.upper}" })
                }
            }
        }
        AlertDialog.Builder(this).setTitle("Camera info").setMessage(sb.toString())
            .setNeutralButton("Reset limits") { _, _ ->
                stabCap.clear()
                val ed = prefs.edit()
                for (k in prefs.all.keys) if (k.startsWith("cap_") || k == "fps60_off") ed.remove(k)
                ed.apply()
                fps60Off = false
                cur?.let { pickSizes(it) }
                updateStabUi()
                toast("Limits reset")
            }
            .setPositiveButton("OK", null).show()
    }

    // ================= sizes =================

    private fun megapixels(sz: Size) = max(1, (sz.width.toLong() * sz.height / 1_000_000L).toInt())

    private fun pickSizes(l: Lens) {
        val map = l.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return
        val vs = map.getOutputSizes(MediaRecorder::class.java)?.toList() ?: emptyList()
        fun has(w: Int, h: Int) = vs.any { it.width == w && it.height == h }
        val dot = "\u00B7"
        // the full list is always shown; options this lens can't do are dimmed
        var all = listOf(
            VidOpt(1280, 720, 30, 10_000_000, "720p 30", "720${dot}30", has(1280, 720)),
            VidOpt(1920, 1080, 30, 16_000_000, "1080p 30", "1080${dot}30", has(1920, 1080)),
            VidOpt(1920, 1080, 60, 24_000_000, "1080p 60", "1080${dot}60", has(1920, 1080) && !fps60Off),
            VidOpt(3840, 2160, 24, 40_000_000, "4K 24", "4K${dot}24", has(3840, 2160)),
            VidOpt(3840, 2160, 30, 50_000_000, "4K 30", "4K${dot}30", has(3840, 2160))
        )
        if (all.none { it.ok }) {
            val bs = vs.maxByOrNull { it.width * it.height } ?: Size(1280, 720)
            all = listOf(VidOpt(bs.width, bs.height, 30, 12_000_000, "${bs.height}p 30", "${bs.height}${dot}30", true))
        }
        vidOpts = all
        var idx = all.indexOfFirst { it.label == vidLabel && it.ok }
        if (idx < 0) idx = all.indexOfFirst { it.label == "1080p 30" && it.ok }
        if (idx < 0) idx = max(0, all.indexOfFirst { it.ok })
        vidIdx = idx
        vidLabel = all[idx].label
        vidSeg.setOptions(all.map { it.short }, idx)
        vidSeg.setDimmed(all.indices.filter { !all[it].ok }.toSet())

        val wantW = if (mode == 1 || !ratio43) 16 else 4
        val wantH = if (mode == 1 || !ratio43) 9 else 3
        val ps = map.getOutputSizes(SurfaceTexture::class.java)?.toList() ?: emptyList()
        previewSize = ps.filter { it.width * wantH == it.height * wantW && it.width <= 1920 }
            .maxByOrNull { it.width }
            ?: ps.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: Size(1280, 720)

        // photo resolutions for this aspect ratio: the largest, about 12 MP, and a small one
        val js = map.getOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList()
        val fit = js.filter { it.width * wantH == it.height * wantW }.sortedBy { it.width * it.height }
        val cands = mutableListOf<Size>()
        fit.lastOrNull()?.let { cands.add(it) }
        fit.lastOrNull { it.width.toLong() * it.height <= 13_000_000L }?.let { if (it !in cands) cands.add(it) }
        fit.lastOrNull { it.width.toLong() * it.height <= 4_500_000L }?.let { if (it !in cands) cands.add(it) }
        var popts = cands.sortedBy { it.width * it.height }
        if (popts.isEmpty()) popts = listOf(js.maxByOrNull { it.width * it.height } ?: previewSize)
        photoOpts = popts
        var pi = 0
        var bestD = Int.MAX_VALUE
        popts.forEachIndexed { i, sz ->
            val dd = abs(megapixels(sz) - photoPrefMp)
            if (dd < bestD) { bestD = dd; pi = i }
        }
        photoIdx = pi
        photoSize = popts[pi]
        photoSeg.setOptions(popts.map { megapixels(it).toString() + " MP" }, pi)
    }

    // Viewfinder geometry: 4:3 sits below the top bar, 16:9 grows upward under it
    private fun layoutStage() {
        val w = resources.displayMetrics.widthPixels
        val h = w * previewSize.width / previewSize.height
        val wide = previewSize.width * 9 == previewSize.height * 16
        val top = if (wide) dp(10) else dp(52)
        val lp = stage.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w) { lp.width = w; stage.layoutParams = lp }
        topScrim.animate().alpha(if (wide) 1f else 0f).setDuration(300).start()
        if (lp.height == h && lp.topMargin == top) return
        stageAnim?.cancel()
        val h0 = lp.height
        val t0 = lp.topMargin
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 360
        a.interpolator = ios
        a.addUpdateListener {
            val f = it.animatedValue as Float
            val l2 = stage.layoutParams as FrameLayout.LayoutParams
            l2.height = (h0 + (h - h0) * f).toInt()
            l2.topMargin = (t0 + (top - t0) * f).toInt()
            stage.layoutParams = l2
            positionZoomPill(false)
        }
        a.start()
        stageAnim = a
    }

    // ================= camera lifecycle =================

    private fun scheduleOpenRetry(): Boolean {
        if (openRetries >= 10) return false
        openRetries++
        ui.postDelayed({ tryOpen() }, 350)
        return true
    }

    private fun tryOpen() {
        val l = cur ?: return
        if (!hasPerms() || !texture.isAvailable || device != null || opening) return
        pickSizes(l)
        opening = true
        try {
            mgr.openCamera(l.logicalId, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    opening = false
                    openRetries = 0
                    device = d
                    startPreview()
                }
                override fun onDisconnected(d: CameraDevice) {
                    opening = false
                    try { d.close() } catch (x: Exception) {}
                    if (device === d) device = null
                }
                override fun onError(d: CameraDevice, e: Int) {
                    val wasOpening = opening
                    opening = false
                    try { d.close() } catch (x: Exception) {}
                    if (device === d) device = null
                    if (configuring) {
                        handleSessionFailure("camera error $e", true)
                    } else if (wasOpening && scheduleOpenRetry()) {
                        // the camera was still busy: retry quietly
                    } else if (SystemClock.elapsedRealtime() - lastFailAt > 1500) {
                        toast("Camera error $e")
                        runOnUiThread { fadeInStage() }
                    }
                }
            }, bg)
        } catch (e: Exception) {
            opening = false
            if (!scheduleOpenRetry()) {
                toast("Open failed: ${e.message}")
                fadeInStage()
            }
        }
    }

    private fun closeCamera() {
        try { session?.close() } catch (e: Exception) {}
        session = null
        try { device?.close() } catch (e: Exception) {}
        device = null
        try { reader?.close() } catch (e: Exception) {}
        reader = null
        closeStaleReader()
    }

    private fun closeStaleReader() {
        try { staleReader?.close() } catch (e: Exception) {}
        staleReader = null
    }

    private fun reopen(rebuildChips: Boolean = true) {
        openRetries = 0
        closeCamera()
        refreshCaps()
        if (rebuildChips) buildZoomChips()
        tryOpen()
    }

    private fun capKey() = (cur?.logicalId ?: "") + (if (mode == 1) "/v" else "/p")

    // the ultrawide's video session rejects electronic stabilization on this phone,
    // so it starts at "Optical" instead of failing first and learning it the slow way
    private fun defaultCap() = if (mode == 1 && ultraLens != null && cur === ultraLens) 1 else 3

    private fun stabCapNow(): Int {
        val key = capKey()
        return stabCap.getOrPut(key) { prefs.getInt("cap_$key", defaultCap()) }
    }

    private fun effStab() = min(stab, stabCapNow())

    private fun updateStabUi() {
        val cap = stabCapNow()
        stabSeg.setDimFrom(cap + 1)
        stabSeg.select(min(stab, cap), true)
    }

    // A session that fails to configure steps stabilization down (and remembers it),
    // then falls back to the main lens. The camera is only reopened if the device itself died.
    private fun handleSessionFailure(msg: String, deviceDead: Boolean) {
        runOnUiThread {
            if (!configuring) return@runOnUiThread
            configuring = false
            lastFailAt = SystemClock.elapsedRealtime()
            if (recorder != null && !recording) abortRecorder()
            val eff = effStab()
            val key = capKey()
            failCount++
            openRetries = 0
            if (deviceDead) {
                closeCamera()
            } else {
                try { session?.close() } catch (e: Exception) {}
                session = null
            }
            if (mode == 1 && (vidOpts.getOrNull(vidIdx)?.fps ?: 30) >= 50) {
                failCount = 0
                disable60()
                if (deviceDead) ui.postDelayed({ tryOpen() }, 300) else startPreview()
                return@runOnUiThread
            }
            if (eff > 0 && failCount <= 4) {
                stabCap[key] = eff - 1
                prefs.edit().putInt("cap_$key", eff - 1).apply()
                updateStabUi()
                toast("${stabNames[eff]} stabilization isn't supported here. Using ${stabNames[eff - 1]}.")
                if (deviceDead) ui.postDelayed({ tryOpen() }, 300) else startPreview()
            } else if (!front && mainLens != null && cur !== mainLens) {
                toast("That mode isn't supported on this lens. Back to 1x.")
                cur = mainLens
                zoom = 1f
                failCount = 0
                reopen()
            } else {
                toast("Camera failed: $msg")
                fadeInStage()
            }
        }
    }

    private fun sensorOri() = cur?.chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

    private fun logIso(range: Range<Int>): Int {
        val lo = range.lower.toDouble()
        val hi = min(range.upper, 6400).toDouble()
        return (lo * (max(hi, lo) / lo).pow((isoProg - 1) / 99.0)).toInt()
    }

    private fun logExp(range: Range<Long>): Long {
        val lo = max(range.lower, 125_000L).toDouble()
        val hi = min(range.upper, 500_000_000L).toDouble()
        return (lo * (max(hi, lo) / lo).pow((shutProg - 1) / 99.0)).toLong()
    }

    private fun applyCommon(b: CaptureRequest.Builder) {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        val video = mode == 1

        b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)

        val minFocus = lc.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (mode == 2 && focusProg > 0 && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * (focusProg - 1) / 99f)
        } else {
            b.set(
                CaptureRequest.CONTROL_AF_MODE,
                if (video) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            tapRegion?.let { b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(it)) }
        }
        tapRegion?.let { b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(it)) }

        val manualExp = mode == 2 && (isoProg > 0 || shutProg > 0)
        if (manualExp) {
            val isoR = lc.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 100)
            val expR = lc.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 1_000_000L)
            val iso = if (isoProg > 0) logIso(isoR) else 200.coerceIn(isoR.lower, isoR.upper)
            val exp = if (shutProg > 0) logExp(expR) else 16_666_667L.coerceIn(expR.lower, expR.upper)
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp)
        } else {
            val ae = if (!video && hasFlash) {
                when (flashMode) {
                    1 -> CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH
                    2 -> CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH
                    else -> CaptureRequest.CONTROL_AE_MODE_ON
                }
            } else CaptureRequest.CONTROL_AE_MODE_ON
            b.set(CaptureRequest.CONTROL_AE_MODE, ae)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev)
        }

        if (video && torch && hasFlash) b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)

        if (mode == 0 && hdr && hdrSupported) {
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_USE_SCENE_MODE)
            b.set(CaptureRequest.CONTROL_SCENE_MODE, CameraMetadata.CONTROL_SCENE_MODE_HDR)
        }

        if (video) {
            val fps = vidOpts.getOrNull(vidIdx)?.fps ?: 30
            val ranges = lc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList()
            val target = ranges.filter { it.upper == fps }.maxByOrNull { it.lower }
                ?: ranges.filter { it.lower <= fps && it.upper >= fps }.minByOrNull { it.upper - it.lower }
            if (target != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, target)
        }

        // stabilization: 1 = optical, 2 = optical + electronic, 3 = preview stabilization
        val eff = effStab()
        val ois = lc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        val oisOn = eff >= 1 && ois?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        b.set(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            if (oisOn) CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON
            else CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_OFF
        )
        val modes = lc.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf(0)
        val m = if (!video) 0 else when (eff) {
            3 -> if (modes.contains(2)) 2 else if (modes.contains(1)) 1 else 0
            2 -> if (modes.contains(1)) 1 else 0
            else -> 0
        }
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, m)
    }

    private fun buildRepeating(d: CameraDevice): CaptureRequest.Builder {
        val b = d.createCaptureRequest(curTemplate)
        curTargets.forEach { b.addTarget(it) }
        applyCommon(b)
        return b
    }

    // Measures the real frame rate when a 60 fps option is active: if the phone quietly stays
    // at 30 (or rejects it), 60 is switched off instead of recording a fake 60 fps clip.
    private val fpsCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            if (!fpsProbing) return
            val ts = res.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
            if (fpsCount == 0) fpsFirstTs = ts
            fpsCount++
            val dt = ts - fpsFirstTs
            if (dt >= 1_500_000_000L && fpsCount > 5) {
                fpsProbing = false
                val fps = (fpsCount - 1) * 1e9 / dt
                runOnUiThread { onFpsMeasured(fps) }
            }
        }
    }

    private fun startFpsProbe() {
        val o = vidOpts.getOrNull(vidIdx)
        fpsProbing = mode == 1 && !recording && o != null && o.fps >= 50
        fpsCount = 0
    }

    private fun onFpsMeasured(fps: Double) {
        val o = vidOpts.getOrNull(vidIdx) ?: return
        if (mode != 1 || recording || o.fps < 50) return
        if (fps < 45.0) disable60()
    }

    private fun disable60() {
        fps60Off = true
        prefs.edit().putBoolean("fps60_off", true).apply()
        vidLabel = "1080p 30"
        cur?.let { pickSizes(it) }
        toast("60 fps isn't available through this phone's camera API. Using 1080p 30.")
        updateRepeating()
    }

    private fun updateRepeating() {
        val d = device ?: return
        val s = session ?: return
        try {
            s.setRepeatingRequest(buildRepeating(d).build(), if (fpsProbing) fpsCb else null, bg)
        } catch (e: Exception) {
        }
    }

    private fun makeSession(
        d: CameraDevice,
        outputs: List<Surface>,
        targets: List<Surface>,
        template: Int,
        onReady: () -> Unit
    ) {
        val gen = ++sessionGen
        session = null
        curTemplate = template
        curTargets = targets
        configuring = true
        val phys = cur?.physicalId
        val outs = outputs.map { s ->
            OutputConfiguration(s).also { if (phys != null) it.setPhysicalCameraId(phys) }
        }
        val req = try {
            buildRepeating(d)
        } catch (e: Exception) {
            handleSessionFailure(e.message ?: "request error", false)
            return
        }
        val cfg = SessionConfiguration(
            SessionConfiguration.SESSION_REGULAR,
            outs,
            Executor { r -> bg.post(r) },
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (gen != sessionGen) {
                        try { s.close() } catch (e: Exception) {}
                        return
                    }
                    configuring = false
                    failCount = 0
                    session = s
                    try {
                        s.setRepeatingRequest(req.build(), if (fpsProbing) fpsCb else null, bg)
                        onReady()
                    } catch (e: Exception) {
                        toast("Preview failed: ${e.message}")
                    }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    if (gen != sessionGen) return
                    handleSessionFailure("configuration failed", false)
                }
            }
        )
        cfg.sessionParameters = req.build()
        try {
            d.createCaptureSession(cfg)
        } catch (e: Exception) {
            handleSessionFailure(e.message ?: "session error", e is CameraAccessException)
        }
    }

    private fun startPreview() {
        val d = device ?: return
        val st = texture.surfaceTexture ?: return
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        runOnUiThread { layoutStage() }
        // One Surface per SurfaceTexture: re-creating it while the old session still holds the
        // SurfaceTexture is what froze the preview when switching 4:3 / 16:9
        val ps = previewSurface?.takeIf { it.isValid } ?: Surface(st).also { previewSurface = it }
        val outs = mutableListOf(ps)
        val oldReader = reader
        var newReader: ImageReader? = null
        if (mode != 1) {
            val nr = ImageReader.newInstance(photoSize.width, photoSize.height, ImageFormat.JPEG, 2)
            newReader = nr
            outs.add(nr.surface)
        }
        reader = newReader
        closeStaleReader()
        staleReader = oldReader
        // the stage stays hidden until the new camera's first frame arrives
        awaitFirstFrame = true
        startFpsProbe()
        makeSession(d, outs, listOf(ps), CameraDevice.TEMPLATE_PREVIEW) {
            closeStaleReader()
            updateRepeating()
        }
    }

    // ================= transitions =================

    private fun animateBlur(to: Float, dur: Long) {
        if (Build.VERSION.SDK_INT < 31) return
        blurAnim?.cancel()
        val a = ValueAnimator.ofFloat(blurNow, to)
        a.duration = dur
        a.addUpdateListener {
            blurNow = it.animatedValue as Float
            try {
                stage.setRenderEffect(
                    if (blurNow < 0.5f) null
                    else RenderEffect.createBlurEffect(blurNow, blurNow, Shader.TileMode.CLAMP)
                )
            } catch (e: Exception) {
            }
        }
        a.start()
        blurAnim = a
    }

    private fun fadeOutStage(flip: Boolean = false) {
        stage.animate().cancel()
        val a = stage.animate().alpha(if (flip) 0f else 0.3f)
            .setDuration(if (flip) 220L else 150L).setInterpolator(ios)
        if (flip) a.rotationY(80f)
        a.start()
        animateBlur(24f, 180L)
        ui.removeCallbacks(fadeInSafety)
        ui.postDelayed(fadeInSafety, 2500)
    }

    private fun fadeInStage() {
        lensSwitching = false
        ui.removeCallbacks(fadeInSafety)
        stage.animate().cancel()
        if (stage.rotationY > 1f) stage.rotationY = -80f
        stage.animate().alpha(1f).rotationY(0f).setDuration(340).setInterpolator(ios).start()
        animateBlur(0f, 300L)
    }

    private fun fadeView(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).translationY(0f).setDuration(280).setInterpolator(ios).start()
        } else {
            v.animate().alpha(0f).translationY(dp(12).toFloat()).setDuration(200).setInterpolator(ios)
                .withEndAction { if (recording) v.visibility = View.INVISIBLE }.start()
        }
    }

    // iPhone-style: while recording only the zoom pill and stop button stay on screen
    private fun setChromeHidden(hide: Boolean) {
        fadeView(modeBar, !hide)
        fadeView(thumbCell, !hide)
        fadeView(flipCell, !hide)
        if (hide) {
            animateVisibility(sheet, false)
            fadePill(true)
            animateVisibility(proSheet, false)
            chevron.animate().rotation(0f).setDuration(200).start()
            chevron.tint = Color.WHITE
        } else {
            animateVisibility(proSheet, mode == 2)
        }
    }

    // ================= shutter / timer =================

    private fun shutterPressed() {
        if (counting) {
            counting = false
            countdownTv.visibility = View.GONE
            return
        }
        if (mode == 1 && recording) {
            haptic(HapticFeedbackConstants.CONFIRM)
            stopRecording(true)
            return
        }
        if (timerSec > 0) {
            counting = true
            tick(timerSec)
        } else doShutter()
    }

    private fun tick(n: Int) {
        if (!counting) { countdownTv.visibility = View.GONE; return }
        if (n == 0) {
            counting = false
            countdownTv.visibility = View.GONE
            doShutter()
            return
        }
        countdownTv.text = n.toString()
        countdownTv.alpha = 0f
        countdownTv.scaleX = 1.4f
        countdownTv.scaleY = 1.4f
        countdownTv.visibility = View.VISIBLE
        countdownTv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(ios).start()
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        ui.postDelayed({ tick(n - 1) }, 1000)
    }

    private fun doShutter() {
        haptic(HapticFeedbackConstants.CONFIRM)
        if (mode == 1) startRecording() else takePhoto()
    }

    // ================= photo =================

    private fun takePhoto() {
        val d = device ?: return
        val s = session ?: return
        val r = reader ?: return
        val ps = previewSurface ?: return
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage()
            if (img != null) {
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    savePhoto(bytes)
                } finally {
                    img.close()
                }
            }
        }, bg)
        if (hasFlash && flashMode != 0 && mode != 1) {
            try {
                val p = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                p.addTarget(ps)
                applyCommon(p)
                p.set(
                    CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER,
                    CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START
                )
                s.capture(p.build(), null, bg)
            } catch (e: Exception) {
            }
            bg.postDelayed({ captureStill() }, 800)
        } else {
            captureStill()
        }
    }

    private fun captureStill() {
        val d = device ?: return
        val s = session ?: return
        val r = reader ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(r.surface)
            applyCommon(b)
            b.set(CaptureRequest.JPEG_ORIENTATION, sensorOri())
            b.set(CaptureRequest.JPEG_QUALITY, 95.toByte())
            val isFront = front
            selfieShot = isFront
            if (isFront) {
                // what the preview shows right now, to compare with the JPEG that comes back
                runOnUiThread {
                    selfieRef = try { texture.getBitmap(48, 64) } catch (e: Exception) { null }
                }
            }
            s.capture(b.build(), null, bg)
            runOnUiThread {
                flashOverlay.animate().cancel()
                flashOverlay.alpha = 0.75f
                flashOverlay.animate().alpha(0f).setDuration(170).start()
            }
        } catch (e: Exception) {
            toast("Capture failed: ${e.message}")
        }
    }

    private fun savePhoto(bytes0: ByteArray) {
        var bytes = bytes0
        if (selfieShot) {
            selfieShot = false
            try {
                bytes = fixSelfieMirror(bytes0)
            } catch (e: Throwable) {
            }
            selfieRef = null
        }
        val cv = ContentValues()
        cv.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MyCam")
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) { toast("Could not save photo"); return }
        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        setThumb(uri)
    }

    // ---- front photos follow the "Mirror front camera" setting ----
    // This phone's camera can deliver selfies already mirrored, so instead of guessing, the JPEG is
    // compared with the live preview captured at the same moment and flipped only when needed:
    // setting on = the photo looks like the mirrored preview, off = like the plain (true) view.
    private fun fixSelfieMirror(src: ByteArray): ByteArray {
        val ref = selfieRef
        var matches = false // does the JPEG show the scene the way the plain preview does?
        if (ref != null) {
            val small = decodeSmall(src)
            if (small != null) {
                val p = lum(ref)
                val a = lum(small)
                val cn = ncc(a, p)
                val cf = ncc(flipLum(a), p)
                if (abs(cn - cf) > 0.04f) matches = cn > cf
            }
        }
        val flip = if (mirrorFront) matches else !matches
        return if (flip) flipJpeg(src) else src
    }

    private fun decodeSmall(src: ByteArray): Bitmap? = try {
        val bm = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(src))) { d, _, _ ->
            d.setTargetSampleSize(8)
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        Bitmap.createScaledBitmap(bm, 48, 64, true)
    } catch (e: Exception) {
        null
    }

    private fun lum(bm: Bitmap): FloatArray {
        val px = IntArray(48 * 64)
        bm.getPixels(px, 0, 48, 0, 0, 48, 64)
        val out = FloatArray(48 * 64)
        for (i in px.indices) {
            val c = px[i]
            out[i] = 0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF)
        }
        return out
    }

    private fun flipLum(a: FloatArray): FloatArray {
        val o = FloatArray(a.size)
        for (y in 0 until 64) for (x in 0 until 48) o[y * 48 + x] = a[y * 48 + (47 - x)]
        return o
    }

    private fun ncc(a: FloatArray, b: FloatArray): Float {
        var ma = 0f
        var mb = 0f
        for (i in a.indices) {
            ma += a[i]
            mb += b[i]
        }
        ma /= a.size
        mb /= b.size
        var sab = 0f
        var saa = 0f
        var sbb = 0f
        for (i in a.indices) {
            val x = a[i] - ma
            val y = b[i] - mb
            sab += x * y
            saa += x * x
            sbb += y * y
        }
        val den = kotlin.math.sqrt(saa * sbb)
        return if (den > 1e-3f) sab / den else 0f
    }

    // mirror the picture left-right (EXIF rotation is applied by the decoder, so the result is upright)
    private fun flipJpeg(src: ByteArray): ByteArray {
        val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(src))) { d, _, _ ->
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        val m = Matrix()
        m.preScale(-1f, 1f)
        val flipped = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, false)
        bmp.recycle()
        val bos = ByteArrayOutputStream(src.size + 65536)
        flipped.compress(Bitmap.CompressFormat.JPEG, 95, bos)
        flipped.recycle()
        return copyExif(src, bos.toByteArray())
    }

    // keep the capture details (time, exposure, ...) of the original in the flipped file
    private fun copyExif(orig: ByteArray, flipped: ByteArray): ByteArray {
        return try {
            val a = File.createTempFile("orig", ".jpg", cacheDir)
            val b = File.createTempFile("flip", ".jpg", cacheDir)
            try {
                a.writeBytes(orig)
                b.writeBytes(flipped)
                val from = ExifInterface(a.absolutePath)
                val to = ExifInterface(b.absolutePath)
                for (t in listOf(
                    "DateTime", "DateTimeOriginal", "DateTimeDigitized", "Make", "Model", "FNumber",
                    "ExposureTime", "FocalLength", "Flash", "WhiteBalance", "PhotographicSensitivity"
                )) {
                    val v = from.getAttribute(t)
                    if (v != null) to.setAttribute(t, v)
                }
                to.setAttribute("Orientation", "1")
                to.saveAttributes()
                b.readBytes()
            } finally {
                a.delete()
                b.delete()
            }
        } catch (e: Exception) {
            flipped
        }
    }

    private fun setThumb(uri: Uri) {
        lastUri = uri
        bg.post {
            try {
                val bm = contentResolver.loadThumbnail(uri, Size(200, 200), null)
                runOnUiThread {
                    thumb.setImageBitmap(bm)
                    thumb.scaleX = 0.5f
                    thumb.scaleY = 0.5f
                    thumb.animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(OvershootInterpolator(2.2f)).start()
                }
            } catch (e: Exception) {
            }
        }
    }

    // ================= video =================

    private fun abortRecorder() {
        try { recorder?.reset() } catch (e: Exception) {}
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        videoUri?.let { try { contentResolver.delete(it, null, null) } catch (e: Exception) {} }
        videoUri = null
        recording = false
        ui.removeCallbacks(recTick)
        recTv.visibility = View.GONE
        shutter.setState(mode == 1, false)
        setChromeHidden(false)
    }

    private fun startRecording() {
        fpsProbing = false
        val d = device ?: return
        val ps = previewSurface ?: return
        val o = vidOpts.getOrNull(vidIdx) ?: return
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/MyCam")
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        val pfd = if (uri != null) contentResolver.openFileDescriptor(uri, "w") else null
        if (pfd == null) { toast("Could not create video file"); return }
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setOutputFile(pfd.fileDescriptor)
            r.setVideoEncodingBitRate(o.bitrate)
            r.setVideoFrameRate(o.fps)
            r.setVideoSize(o.w, o.h)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOrientationHint(sensorOri())
            r.prepare()
        } catch (e: Exception) {
            toast("Recorder error: ${e.message}")
            r.release()
            pfd.close()
            if (uri != null) try { contentResolver.delete(uri, null, null) } catch (x: Exception) {}
            return
        }
        recorder = r
        recPfd = pfd
        videoUri = uri
        makeSession(d, listOf(ps, r.surface), listOf(ps, r.surface), CameraDevice.TEMPLATE_RECORD) {
            runOnUiThread {
                try {
                    r.start()
                    recording = true
                    recStart = SystemClock.elapsedRealtime()
                    recTv.alpha = 0f
                    recTv.visibility = View.VISIBLE
                    recTv.animate().alpha(1f).setDuration(250).start()
                    shutter.setState(true, true)
                    setChromeHidden(true)
                    ui.post(recTick)
                } catch (e: Exception) {
                    toast("Start failed: ${e.message}")
                    abortRecorder()
                }
            }
        }
    }

    private fun stopRecording(restart: Boolean) {
        try { session?.stopRepeating() } catch (e: Exception) {}
        try { session?.abortCaptures() } catch (e: Exception) {}
        var saved = true
        try { recorder?.stop() } catch (e: RuntimeException) { saved = false; toast("Recording too short") }
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recording = false
        ui.removeCallbacks(recTick)
        recTv.visibility = View.GONE
        shutter.setState(mode == 1, false)
        setChromeHidden(false)
        if (saved) videoUri?.let { setThumb(it) }
        if (restart) startPreview()
    }

    // ================= zoom / focus =================

    private fun displayZoom(): Float =
        if (ultraLens != null && cur === ultraLens) 0.6f * zoom else zoom

    private fun fmtZ(z: Float): String {
        val s = String.format(Locale.US, "%.1f", z)
        return if (s.endsWith(".0")) s.dropLast(2) else s
    }

    private fun animateZoom(target: Float) {
        zoomAnim?.cancel()
        val a = ValueAnimator.ofFloat(zoom, target)
        a.duration = 380
        a.interpolator = ios
        a.addUpdateListener {
            zoom = it.animatedValue as Float
            updateRepeating()
            refreshZoomChips()
        }
        a.start()
        zoomAnim = a
    }

    // Hold the zoom pill: a dial replaces it and sliding along it zooms in small steps.
    private fun startDial() {
        if (front || zoomChips.isEmpty() || sheet.tag == true || dialActive) return
        val m = mainLens
        zoomDial.minV = if (ultraLens != null && !logicalWide()) 0.6f else (m?.let { zoomRangeOf(it).lower } ?: 1f)
        zoomDial.maxV = m?.let { zoomRangeOf(it).upper } ?: 10f
        zoomDial.value = displayZoom()
        dialActive = true
        dialLastX = Float.NaN
        zoomGlass.dialMode = true
        ui.removeCallbacks(hideDial)
        haptic(HapticFeedbackConstants.LONG_PRESS)
        val ty = zoomRow.bottom + zoomRow.translationY - dp(150) + dp(10)
        zoomDial.animate().cancel()
        zoomDial.alpha = 0f
        zoomDial.y = ty + dp(24)
        zoomDial.visibility = View.VISIBLE
        zoomDial.animate().alpha(1f).y(ty).setDuration(300).setInterpolator(ios).start()
        zoomRow.animate().cancel()
        zoomRow.animate().alpha(0f).setDuration(140).start()
    }

    private fun dialTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (!dialLastX.isNaN()) {
                    val dx = ev.rawX - dialLastX
                    val cz = displayZoom()
                    val target = exp(ln(cz) - dx / zoomDial.pxPerLn).coerceIn(zoomDial.minV, zoomDial.maxV)
                    pinchZoom(target / cz)
                    zoomDial.value = displayZoom()
                }
                dialLastX = ev.rawX
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endDial()
        }
    }

    private fun endDial() {
        if (!dialActive) return
        dialActive = false
        zoomGlass.dialMode = false
        ui.removeCallbacks(hideDial)
        ui.postDelayed(hideDial, 800)
    }

    // Pinching is one continuous zoom from 0.6x to 10x. The ultrawide covers 0.6x-1x, the main
    // lens everything above; 2x is a crop of the main sensor (there is no separate 2x lens),
    // so it gets a tick and a gentle snap instead of a lens switch.
    private fun pinchZoom(factor: Float) {
        val c = cur ?: return
        val m = mainLens
        val u = ultraLens
        val onUltra = u != null && c === u
        val r = zoomRangeOf(c)
        if (front || m == null || u == null || logicalWide()) {
            zoom = (zoom * factor).coerceIn(r.lower, r.upper)
            updateRepeating()
            refreshZoomChips()
            return
        }
        val mr = zoomRangeOf(m)
        val ur = zoomRangeOf(u)
        var vz = (displayZoom() * factor).coerceIn(0.6f * ur.lower, mr.upper)
        if (abs(vz - 2f) < 0.05f) {
            if (!snapNear) {
                snapNear = true
                haptic(HapticFeedbackConstants.CLOCK_TICK)
            }
            vz = 2f
        } else {
            snapNear = false
        }
        val ultraZoom = (vz / 0.6f).coerceIn(ur.lower, ur.upper)
        val mainZoom = vz.coerceIn(mr.lower, mr.upper)
        if (recording) {
            // lenses can't be swapped while recording: keep zooming on the current one
            zoom = if (onUltra) ultraZoom else mainZoom
            updateRepeating()
            refreshZoomChips()
            return
        }
        val wantUltra = if (onUltra) vz < 1f else vz < 0.98f
        if (wantUltra != onUltra) {
            if (!lensSwitching) switchLens(if (wantUltra) u else m, if (wantUltra) ultraZoom else mainZoom)
            return
        }
        zoom = if (onUltra) ultraZoom else mainZoom
        updateRepeating()
        refreshZoomChips()
    }

    private fun switchLens(target: Lens, newZoom: Float) {
        lensSwitching = true
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        tapRegion = null
        zoomAnim?.cancel()
        cur = target
        zoom = newZoom
        fadeOutStage()
        reopen(false)
        refreshZoomChips()
    }

    private fun selectZoom(v: Float) {
        if (recording && !logicalWide()) return
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        tapRegion = null
        if (v < 0.95f && !logicalWide()) {
            val u = ultraLens
            if (u != null && cur !== u) {
                zoomAnim?.cancel()
                cur = u
                zoom = 1f
                fadeOutStage()
                reopen()
            }
        } else {
            val c = cur ?: return
            val m = mainLens
            if (ultraLens != null && c === ultraLens && m != null && c !== m) {
                zoomAnim?.cancel()
                cur = m
                zoom = v
                fadeOutStage()
                reopen()
            } else {
                val r = zoomRangeOf(c)
                animateZoom(v.coerceIn(r.lower, r.upper))
            }
        }
        refreshZoomChips()
    }

    private fun buildZoomChips() {
        zoomRow.removeAllViews()
        zoomChips.clear()
        val m = mainLens
        if (front || m == null) { zoomRow.visibility = View.GONE; return }
        val sheetOpen = sheet.tag == true
        zoomRow.visibility = if (sheetOpen) View.INVISIBLE else View.VISIBLE
        zoomRow.alpha = if (sheetOpen) 0f else 1f
        slideAnim?.cancel()
        pillSlide = if (sheetOpen) pillDist() else 0f
        applyPillY()
        val r = zoomRangeOf(m)
        val vals = mutableListOf<Float>()
        if (r.lower < 0.95f) vals.add(r.lower) else if (ultraLens != null) vals.add(0.6f)
        vals.add(1f)
        if (r.upper >= 2f) vals.add(2f)
        for (v in vals) {
            val tv = TextView(this)
            tv.textSize = 12.5f
            tv.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            tv.gravity = Gravity.CENTER
            tv.setOnClickListener { selectZoom(v) }
            pressable(tv, 0.88f)
            val lp = LinearLayout.LayoutParams(dp(42), dp(42))
            lp.leftMargin = dp(2)
            lp.rightMargin = dp(2)
            zoomRow.addView(tv, lp)
            zoomChips.add(Pair(tv, v))
        }
        refreshZoomChips()
    }

    // the active button shows the live zoom factor, like the iPhone camera
    private fun refreshZoomChips() {
        if (zoomChips.isEmpty()) return
        val dz = displayZoom()
        var activeIdx = 0
        for ((i, pr) in zoomChips.withIndex()) {
            if (dz >= pr.second - 0.04f) activeIdx = i
        }
        for ((i, pr) in zoomChips.withIndex()) {
            val tv = pr.first
            val v = pr.second
            val active = i == activeIdx
            tv.text = if (active) fmtZ(dz) + "\u00D7" else if (v < 1f) fmtZ(v).removePrefix("0") else fmtZ(v)
            if (tv.tag != active) {
                tv.tag = active
                tv.setTextColor(if (active) accent else Color.WHITE)
                tv.background = oval(if (active) Color.parseColor("#B0000000") else Color.TRANSPARENT)
                val s = if (active) 1.1f else 0.86f
                tv.animate().scaleX(s).scaleY(s).setDuration(220).setInterpolator(ios).start()
            }
        }
    }

    // Inside the viewfinder (14dp above its bottom edge) when the viewfinder ends above the controls,
    // as in 4:3; above the mode row when the viewfinder runs behind them, as in 16:9 and video.
    private fun applyPillY() {
        zoomRow.translationY = pillBase + pillSlide
    }

    private fun positionZoomPill(animate: Boolean) {
        val rootH = rootView.height
        val panelH = panelView.height
        if (rootH == 0 || panelH == 0) return
        val lp = stage.layoutParams as FrameLayout.LayoutParams
        val stageBottom = lp.topMargin + lp.height
        val layoutBottom = rootH - panelH - dp(6)
        val proH = if (proSheet.tag == true && proSheet.visibility == View.VISIBLE) proSheet.height + dp(8) else 0
        val baseBottom = layoutBottom - proH
        val desired = min(baseBottom, stageBottom - dp(14))
        val target = (desired - layoutBottom).toFloat()
        pillAnim?.cancel()
        if (!animate || abs(target - pillBase) < 1f) {
            pillBase = target
            applyPillY()
            return
        }
        val a = ValueAnimator.ofFloat(pillBase, target)
        a.duration = 320
        a.interpolator = ios
        a.addUpdateListener {
            pillBase = it.animatedValue as Float
            applyPillY()
        }
        a.start()
        pillAnim = a
    }

    private fun pillDist() = dp(48).toFloat()

    // The pill drops out of the way when the menu opens. Once the menu has mostly gone it rises
    // back from the bottom with a soft spring. Nothing else moves the pill meanwhile: its resting
    // position ignores the settings sheet.
    private fun fadePill(show: Boolean) {
        if (front || zoomChips.isEmpty()) return
        slideAnim?.cancel()
        val dist = pillDist()
        if (show) zoomRow.visibility = View.VISIBLE
        val a = ValueAnimator.ofFloat(pillSlide, if (show) 0f else dist)
        if (show) {
            a.startDelay = 140
            a.duration = 560L
            a.interpolator = OvershootInterpolator(0.9f)
        } else {
            a.duration = 220L
            a.interpolator = DecelerateInterpolator(1.4f)
        }
        a.addUpdateListener {
            pillSlide = it.animatedValue as Float
            zoomRow.alpha = ((1f - pillSlide / dist) * 1.8f).coerceIn(0f, 1f)
            applyPillY()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (!show && sheet.tag == true) zoomRow.visibility = View.INVISIBLE
            }
        })
        a.start()
        slideAnim = a
    }

    private fun evOffsetPx(): Float {
        val l = cur ?: return 0f
        val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: return 0f
        if (er.upper <= er.lower) return 0f
        val frac = (ev - er.lower).toFloat() / (er.upper - er.lower).toFloat()
        return (0.5f - frac) * dp(80)
    }

    private fun positionSun() {
        val right = fx + dp(52) + dp(24) < stage.width
        val sx = if (right) fx + dp(52) else fx - dp(52) - dp(22)
        sunIcon.x = sx
        sunIcon.y = fy - dp(11) + evOffsetPx()
        focusLine.x = sx + dp(11) - dp(1)
        focusLine.y = fy - dp(44)
    }

    private fun scheduleFocusHide() {
        ui.removeCallbacks(hideFocus)
        ui.postDelayed(hideFocus, 3500)
    }

    private fun dragEv(dy: Float) {
        val l = cur ?: return
        val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: return
        if (er.upper <= er.lower) return
        evAccum += dy
        val unit = dp(10).toFloat()
        val steps = (evAccum / unit).toInt()
        if (steps != 0) {
            evAccum -= steps * unit
            ev = (ev + steps).coerceIn(er.lower, er.upper)
            evSeek.progress = ev - er.lower
            updateEvLabel()
            updateRepeating()
            positionSun()
        }
        scheduleFocusHide()
    }

    private fun focusAt(x: Float, y: Float) {
        val l = cur ?: return
        val w = stage.width.toFloat()
        val h = stage.height.toFloat()
        if (w <= 0f || h <= 0f) return
        var vx = x / w
        val vy = y / h
        if (front && mirrorFront) vx = 1f - vx
        val a = lcOf(l.logicalId).get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        val sx: Float
        val sy: Float
        when (sensorOri()) {
            90 -> { sx = vy; sy = 1f - vx }
            270 -> { sx = 1f - vy; sy = vx }
            180 -> { sx = 1f - vx; sy = 1f - vy }
            else -> { sx = vx; sy = vy }
        }
        val px = a.left + (sx * a.width()).toInt()
        val py = a.top + (sy * a.height()).toInt()
        val half = (min(a.width(), a.height()) * 0.08f).toInt()
        val rect = Rect(
            max(a.left, px - half), max(a.top, py - half),
            min(a.right - 1, px + half), min(a.bottom - 1, py + half)
        )
        tapRegion = MeteringRectangle(rect, MeteringRectangle.METERING_WEIGHT_MAX - 1)
        updateRepeating()
        haptic(HapticFeedbackConstants.CLOCK_TICK)

        fx = x
        fy = y
        focusActive = true
        evAccum = 0f
        val size = dp(76)
        focusBox.animate().cancel()
        focusBox.x = x - size / 2f
        focusBox.y = y - size / 2f
        focusBox.alpha = 1f
        focusBox.scaleX = 1.4f
        focusBox.scaleY = 1.4f
        focusBox.visibility = View.VISIBLE
        focusBox.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(ios).start()
        for (v in listOf<View>(focusLine, sunIcon)) {
            v.animate().cancel()
            v.alpha = 0f
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(220).start()
        }
        positionSun()
        scheduleFocusHide()
    }

    // ================= settings / state =================

    private fun refreshCaps() {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        hasFlash = lc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        flashIcon.visibility = if (hasFlash) View.VISIBLE else View.INVISIBLE
        hdrSupported = lc.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)
            ?.contains(CameraMetadata.CONTROL_SCENE_MODE_HDR) == true
        updateSheetRows()
        val er = lc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = lc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        evRow.visibility = if (er.upper > er.lower) View.VISIBLE else View.GONE
        evSeek.max = er.upper - er.lower
        ev = ev.coerceIn(er.lower, er.upper)
        evSeek.progress = ev - er.lower
        updateEvLabel()
        updateProLabels()
        updateFlashChip()
        updateStabUi()
    }

    // photo settings in photo/pro, video quality in video
    private fun updateSheetRows() {
        val video = mode == 1
        ratioRow.visibility = if (video) View.GONE else View.VISIBLE
        photoRow.visibility = if (video) View.GONE else View.VISIBLE
        vidRow.visibility = if (video) View.VISIBLE else View.GONE
        hdrRow.visibility = if (hdrSupported && !video) View.VISIBLE else View.GONE
    }

    private fun updateEvLabel() {
        evLabel.text = "Exposure  " + String.format(Locale.US, "%+.1f", ev * evStep)
    }

    private fun fmtShutter(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/" + (1.0 / s).roundToInt()
    }

    private fun updateProLabels() {
        val l = cur ?: return
        val lc = lcOf(l.logicalId)
        val isoR = lc.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 100)
        val expR = lc.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 1_000_000L)
        isoLabel.text = if (isoProg == 0) "ISO  Auto" else "ISO  " + logIso(isoR)
        shutLabel.text = if (shutProg == 0) "Shutter  Auto" else "Shutter  " + fmtShutter(logExp(expR))
        focusLabel.text = if (focusProg == 0) "Focus  Auto" else "Focus  Manual"
    }

    private fun updateFlashChip() {
        val st = if (mode == 1) (if (torch) 2 else 0) else flashMode
        flashIcon.state = st
        flashIcon.tint = if (st != 0) accent else Color.WHITE
    }

    private fun animateVisibility(v: View, show: Boolean, animate: Boolean = true) {
        v.animate().cancel()
        v.tag = show
        if (!animate) {
            v.alpha = 1f
            v.translationY = 0f
            v.scaleX = 1f
            v.scaleY = 1f
            v.visibility = if (show) View.VISIBLE else View.GONE
            return
        }
        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.alpha = 0f
                v.translationY = dp(28).toFloat()
                v.scaleX = 0.94f
                v.scaleY = 0.94f
                v.visibility = View.VISIBLE
            }
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(340)
                .setInterpolator(ios).start()
        } else {
            v.animate().alpha(0f).translationY(dp(28).toFloat()).scaleX(0.96f).scaleY(0.96f)
                .setDuration(220).setInterpolator(ios)
                .withEndAction { if (v.tag == false) v.visibility = View.GONE }.start()
        }
    }

    private fun toggleSheet() {
        if (recording) return
        val show = sheet.visibility != View.VISIBLE || sheet.tag == false
        animateVisibility(sheet, show)
        fadePill(!show)
        chevron.animate().rotation(if (show) 180f else 0f).setDuration(280).setInterpolator(ios).start()
        chevron.tint = if (show) accent else Color.WHITE
        haptic(HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun centerModeBar(animate: Boolean) {
        val tv = tabs[mode] ?: return
        if (modeBar.width == 0 || tv.width == 0) {
            modeBar.post { centerModeBar(false) }
            return
        }
        val target = modeBar.width / 2f - (tv.left + tv.width / 2f)
        if (animate) {
            modeRow.animate().translationX(target).setDuration(320).setInterpolator(ios).start()
        } else {
            modeRow.animate().cancel()
            modeRow.translationX = target
        }
    }

    private fun refreshModeUi(animate: Boolean) {
        for ((i, t) in tabs) {
            val sel = i == mode
            t.setTextColor(if (sel) accent else Color.WHITE)
            t.animate().alpha(if (sel) 1f else 0.6f).scaleX(if (sel) 1f else 0.88f)
                .scaleY(if (sel) 1f else 0.88f).setDuration(if (animate) 260L else 0L).start()
        }
        shutter.setState(mode == 1, recording)
        animateVisibility(proSheet, mode == 2, animate)
        centerModeBar(animate)
        updateFlashChip()
        updateStabUi()
        updateSheetRows()
    }

    private fun setMode(m: Int) {
        if (recording || counting || m == mode) return
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        mode = m
        tapRegion = null
        refreshModeUi(true)
        val l = cur ?: return
        pickSizes(l)
        if (device != null) {
            fadeOutStage()
            startPreview()
        }
    }

    private fun swipeMode(dir: Int) {
        val pos = modeOrder.indexOf(mode)
        val np = (pos + dir).coerceIn(0, modeOrder.size - 1)
        if (np != pos) setMode(modeOrder[np])
    }

    // mirroring is applied when the new camera's first frame arrives, so no stale frame flips
    private fun flipCamera() {
        if (recording) return
        val target = if (front) mainLens else frontLens
        if (target == null) { toast("No front camera found"); return }
        haptic(HapticFeedbackConstants.CLOCK_TICK)
        flipBtn.animate().rotationBy(180f).setDuration(380).setInterpolator(ios).start()
        front = !front
        cur = target
        zoom = 1f
        tapRegion = null
        fadeOutStage(true)
        reopen()
    }

    // ================= ui building =================

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun pressable(v: View, s: Float = 0.9f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(s).scaleY(s).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun chip(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(16), dp(7), dp(16), dp(7))
        t.background = rounded(Color.parseColor("#33FFFFFF"), dp(14).toFloat())
        pressable(t, 0.94f)
        return t
    }

    private fun labelText(t: String): TextView {
        val l = TextView(this)
        l.text = t
        l.setTextColor(Color.parseColor("#C8FFFFFF"))
        l.textSize = 13f
        return l
    }

    private fun inlineRow(label: String, v: View, widthDp: Int): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(5), 0, dp(5))
        r.addView(labelText(label), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(v, LinearLayout.LayoutParams(dp(widthDp), -2))
        return r
    }

    private fun stackRow(label: String, v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(0, dp(5), 0, dp(5))
        r.addView(labelText(label))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(6)
        r.addView(v, lp)
        return r
    }

    private fun seekRow(label: TextView, seek: SeekBar): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        label.setTextColor(Color.WHITE)
        label.textSize = 13f
        r.addView(label, LinearLayout.LayoutParams(dp(120), -2))
        seek.progressTintList = ColorStateList.valueOf(accent)
        seek.thumbTintList = ColorStateList.valueOf(accent)
        r.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        return r
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val sw = resources.displayMetrics.widthPixels

        // ----- viewfinder -----
        stage = FrameLayout(this)
        stage.setBackgroundColor(Color.BLACK)
        stage.cameraDistance = 9000f * resources.displayMetrics.density
        stage.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(24).toFloat())
            }
        }
        stage.clipToOutline = true
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> stage.invalidateOutline() }

        texture = TextureView(this)
        stage.addView(texture, FrameLayout.LayoutParams(-1, -1))
        GlassSource.live = texture
        GlassSource.anchor = stage
        grid = CamGrid(this)
        grid.visibility = View.GONE
        stage.addView(grid, FrameLayout.LayoutParams(-1, -1))
        flashOverlay = View(this)
        flashOverlay.setBackgroundColor(Color.BLACK)
        flashOverlay.alpha = 0f
        stage.addView(flashOverlay, FrameLayout.LayoutParams(-1, -1))

        focusBox = View(this)
        val boxBg = GradientDrawable()
        boxBg.shape = GradientDrawable.RECTANGLE
        boxBg.setColor(Color.TRANSPARENT)
        boxBg.setStroke(dp(2), accent)
        focusBox.background = boxBg
        focusBox.visibility = View.GONE
        stage.addView(focusBox, FrameLayout.LayoutParams(dp(76), dp(76)))
        focusLine = View(this)
        focusLine.setBackgroundColor(Color.parseColor("#99FFD60A"))
        focusLine.visibility = View.GONE
        stage.addView(focusLine, FrameLayout.LayoutParams(dp(2), dp(88)))
        sunIcon = CamIcon(this, 3)
        sunIcon.tint = accent
        sunIcon.visibility = View.GONE
        stage.addView(sunIcon, FrameLayout.LayoutParams(dp(22), dp(22)))

        countdownTv = TextView(this)
        countdownTv.setTextColor(Color.WHITE)
        countdownTv.textSize = 96f
        countdownTv.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        countdownTv.visibility = View.GONE
        stage.addView(countdownTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        recTv = TextView(this)
        recTv.setTextColor(Color.WHITE)
        recTv.textSize = 14f
        recTv.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        recTv.setPadding(dp(12), dp(5), dp(12), dp(5))
        recTv.background = rounded(Color.parseColor("#CCFF3B30"), dp(14).toFloat())
        recTv.visibility = View.GONE
        val rlp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        rlp.topMargin = dp(56)
        stage.addView(recTv, rlp)

        val slp = FrameLayout.LayoutParams(sw, sw * 4 / 3, Gravity.TOP)
        slp.topMargin = dp(52)
        root.addView(stage, slp)

        topScrim = View(this)
        topScrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#99000000"), Color.TRANSPARENT)
        )
        topScrim.alpha = 0f
        root.addView(topScrim, FrameLayout.LayoutParams(-1, dp(120), Gravity.TOP))

        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoomAnim?.cancel()
                pinchZoom(d.scaleFactor)
                return true
            }
        })
        val tapDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (sheet.visibility == View.VISIBLE && sheet.tag == true) {
                    toggleSheet()
                } else {
                    focusAt(e.x, e.y)
                }
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (focusActive && abs(dy) > abs(dx)) { dragEv(dy); return true }
                return false
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > 1200f && abs(vx) > abs(vy) * 1.5f) {
                    swipeMode(if (vx < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        stage.setOnTouchListener { _, ev ->
            scaleDet.onTouchEvent(ev)
            if (!scaleDet.isInProgress) tapDet.onTouchEvent(ev)
            true
        }

        // ----- top bar -----
        topBar = FrameLayout(this)
        flashIcon = CamIcon(this, 0)
        timerIcon = CamIcon(this, 1)
        chevron = CamIcon(this, 2)
        fun slot(icon: CamIcon, gravity: Int, margin: Int): FrameLayout {
            val f = FrameLayout(this)
            f.addView(icon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            pressable(f, 0.85f)
            val lp = FrameLayout.LayoutParams(dp(48), dp(48), gravity or Gravity.CENTER_VERTICAL)
            lp.leftMargin = margin
            lp.rightMargin = margin
            topBar.addView(f, lp)
            return f
        }
        slot(flashIcon, Gravity.START, dp(12)).setOnClickListener {
            if (mode == 1) torch = !torch else flashMode = (flashMode + 1) % 3
            haptic(HapticFeedbackConstants.CLOCK_TICK)
            updateFlashChip()
            updateRepeating()
        }
        slot(chevron, Gravity.CENTER_HORIZONTAL, 0).setOnClickListener { toggleSheet() }
        slot(timerIcon, Gravity.END, dp(12)).setOnClickListener {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            timerIcon.label = if (timerSec == 0) "" else timerSec.toString()
            timerIcon.tint = if (timerSec != 0) accent else Color.WHITE
            haptic(HapticFeedbackConstants.CLOCK_TICK)
        }
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP))

        // ----- settings sheet (floats above the bottom controls) -----
        sheetHost = LinearLayout(this)
        sheetHost.orientation = LinearLayout.VERTICAL
        sheetHost.setPadding(dp(12), 0, dp(12), 0)

        sheet = GlassLinear(this, 28f, Color.parseColor("#A60C0C0E"))
        sheet.orientation = LinearLayout.VERTICAL
        sheet.setPadding(dp(18), dp(10), dp(18), dp(10))
        sheet.visibility = View.GONE
        sheet.tag = false
        sheet.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            v.pivotX = (r - l) / 2f
            v.pivotY = (b - t).toFloat()
        }
        glassViews.add(sheet)
        val grabber = View(this)
        grabber.background = rounded(Color.parseColor("#59FFFFFF"), dp(2).toFloat())
        val glp = LinearLayout.LayoutParams(dp(36), dp(4))
        glp.gravity = Gravity.CENTER_HORIZONTAL
        glp.bottomMargin = dp(8)
        sheet.addView(grabber, glp)

        ratioSeg = SegControl(this, accent) { i ->
            ratio43 = i == 0
            val l = cur
            if (l != null && !recording) {
                pickSizes(l)
                if (mode != 1 && device != null) { fadeOutStage(); startPreview() }
            }
        }
        ratioSeg.setOptions(listOf("4:3", "16:9"), 0)

        photoSeg = SegControl(this, accent) { i ->
            if (!recording && i < photoOpts.size) {
                photoIdx = i
                photoSize = photoOpts[i]
                photoPrefMp = megapixels(photoSize)
                if (mode != 1 && device != null) startPreview()
            }
        }
        photoSeg.setOptions(listOf("12 MP"), 0)

        vidSeg = SegControl(this, accent) { i ->
            val o = vidOpts.getOrNull(i)
            if (!recording && o != null && o.ok) {
                vidIdx = i
                vidLabel = o.label
                startFpsProbe()
                updateRepeating()
            } else {
                vidSeg.select(vidIdx)
            }
        }
        vidSeg.onBlocked = { i ->
            val o = vidOpts.getOrNull(i)
            toast(
                if (o != null && o.fps >= 50 && fps60Off) "60 fps isn't available through this phone's camera API"
                else (o?.label ?: "That option") + " isn't available on this lens"
            )
        }
        vidSeg.setOptions(listOf("1080\u00B730"), 0)

        stabSeg = SegControl(this, accent) { i ->
            if (!recording) {
                stab = i
                updateStabUi()
                if (device != null) startPreview()
            }
        }
        stabSeg.onBlocked = { i ->
            if (!recording) {
                val key = capKey()
                stabCap[key] = 3
                prefs.edit().putInt("cap_$key", 3).apply()
                stab = i
                toast("Trying ${stabNames[i]}...")
                updateStabUi()
                if (device != null) startPreview()
            }
        }
        stabSeg.setOptions(stabNames.toList(), 2)

        hdrSeg = SegControl(this, accent) { i ->
            hdr = i == 1
            updateRepeating()
        }
        hdrSeg.setOptions(listOf("Off", "On"), 0)

        gridSeg = SegControl(this, accent) { i ->
            grid.visibility = if (i == 1) View.VISIBLE else View.GONE
        }
        gridSeg.setOptions(listOf("Off", "On"), 0)

        mirrorSeg = SegControl(this, accent) { i ->
            mirrorFront = i == 1
            prefs.edit().putBoolean("mirror_front", mirrorFront).apply()
            if (front) texture.scaleX = if (mirrorFront) -1f else 1f
        }
        mirrorSeg.setOptions(listOf("Off", "On"), if (mirrorFront) 1 else 0)

        evLabel = TextView(this)
        evSeek = SeekBar(this)
        evSeek.setOnSeekBarChangeListener(seekListener { p ->
            val l = cur
            if (l != null) {
                val er = lcOf(l.logicalId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                ev = p + (er?.lower ?: 0)
                updateEvLabel()
                updateRepeating()
            }
        })
        evRow = LinearLayout(this)
        evRow.orientation = LinearLayout.HORIZONTAL
        evRow.gravity = Gravity.CENTER_VERTICAL
        evRow.setPadding(0, dp(5), 0, dp(5))
        evLabel.setTextColor(Color.parseColor("#C8FFFFFF"))
        evLabel.textSize = 13f
        evSeek.progressTintList = ColorStateList.valueOf(accent)
        evSeek.thumbTintList = ColorStateList.valueOf(accent)
        evRow.addView(evLabel, LinearLayout.LayoutParams(dp(120), -2))
        evRow.addView(evSeek, LinearLayout.LayoutParams(0, -2, 1f))

        val infoChip = chip("Show")
        infoChip.setOnClickListener { showInfo() }

        ratioRow = inlineRow("Photo ratio", ratioSeg, 150)
        photoRow = stackRow("Photo resolution", photoSeg)
        vidRow = stackRow("Video quality", vidSeg)
        sheet.addView(ratioRow)
        sheet.addView(photoRow)
        sheet.addView(vidRow)
        sheet.addView(stackRow("Stabilization", stabSeg))
        hdrRow = inlineRow("HDR", hdrSeg, 150)
        sheet.addView(hdrRow)
        sheet.addView(inlineRow("Grid", gridSeg, 150))
        sheet.addView(inlineRow("Mirror front camera", mirrorSeg, 150))
        sheet.addView(evRow)
        sheet.addView(inlineRow("Camera info", infoChip, 90))
        val shlp = LinearLayout.LayoutParams(-1, -2)
        shlp.bottomMargin = dp(8)
        sheetHost.addView(sheet, shlp)

        proSheet = GlassLinear(this, 28f, Color.parseColor("#A60C0C0E"))
        proSheet.orientation = LinearLayout.VERTICAL
        proSheet.setPadding(dp(18), dp(8), dp(18), dp(8))
        proSheet.visibility = View.GONE
        proSheet.tag = false
        proSheet.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            v.pivotX = (r - l) / 2f
            v.pivotY = (b - t).toFloat()
        }
        glassViews.add(proSheet)
        isoLabel = TextView(this)
        shutLabel = TextView(this)
        focusLabel = TextView(this)
        isoSeek = SeekBar(this)
        shutSeek = SeekBar(this)
        focusSeek = SeekBar(this)
        isoSeek.max = 100
        shutSeek.max = 100
        focusSeek.max = 100
        isoSeek.setOnSeekBarChangeListener(seekListener { p -> isoProg = p; updateProLabels(); updateRepeating() })
        shutSeek.setOnSeekBarChangeListener(seekListener { p -> shutProg = p; updateProLabels(); updateRepeating() })
        focusSeek.setOnSeekBarChangeListener(seekListener { p -> focusProg = p; updateProLabels(); updateRepeating() })
        proSheet.addView(seekRow(isoLabel, isoSeek))
        proSheet.addView(seekRow(shutLabel, shutSeek))
        proSheet.addView(seekRow(focusLabel, focusSeek))
        val plp = LinearLayout.LayoutParams(-1, -2)
        plp.bottomMargin = dp(8)
        sheetHost.addView(proSheet, plp)

        // ----- bottom panel: zoom pill, mode carousel, shutter row -----
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER_HORIZONTAL
        panel.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.TRANSPARENT, Color.parseColor("#E6000000"))
        )
        panel.setPadding(dp(12), dp(8), dp(12), dp(10))

        // the zoom pill floats above the panel and follows the viewfinder edge (see positionZoomPill)
        zoomGlass = GlassLinear(this, 30f, Color.parseColor("#52000000"))
        zoomRow = zoomGlass
        zoomRow.orientation = LinearLayout.HORIZONTAL
        zoomRow.gravity = Gravity.CENTER
        zoomRow.setPadding(dp(4), dp(4), dp(4), dp(4))
        glassViews.add(zoomRow)
        zoomGlass.onLongPressed = { startDial() }
        zoomGlass.onDialTouch = { ev -> dialTouch(ev) }

        modeBar = FrameLayout(this)
        modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        val names = mapOf(0 to "PHOTO", 1 to "VIDEO", 2 to "PRO")
        for (m in modeOrder) {
            val t = TextView(this)
            t.text = names[m]
            t.textSize = 13f
            t.letterSpacing = 0.08f
            t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            t.setPadding(dp(16), dp(10), dp(16), dp(10))
            t.setOnClickListener { setMode(m) }
            tabs[m] = t
            modeRow.addView(t)
        }
        modeBar.addView(modeRow, FrameLayout.LayoutParams(-2, -2))
        panel.addView(modeBar, LinearLayout.LayoutParams(-1, dp(44)))

        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER_VERTICAL

        thumb = ImageView(this)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.background = rounded(Color.parseColor("#33FFFFFF"), dp(10).toFloat())
        val thumbEdge = GradientDrawable()
        thumbEdge.shape = GradientDrawable.RECTANGLE
        thumbEdge.setColor(Color.TRANSPARENT)
        thumbEdge.cornerRadius = dp(10).toFloat()
        thumbEdge.setStroke(dp(1), Color.parseColor("#59FFFFFF"))
        thumb.foreground = thumbEdge
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
            }
        }
        thumb.clipToOutline = true
        pressable(thumb, 0.9f)
        thumb.setOnClickListener {
            if (!recording && !counting) {
                startActivity(Intent(this, GalleryActivity::class.java))
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax)
            }
        }

        shutter = CamShutter(this)
        pressable(shutter, 0.9f)
        shutter.setOnClickListener { shutterPressed() }

        flipBtn = TextView(this)
        flipBtn.text = "\u27F3"
        flipBtn.setTextColor(Color.WHITE)
        flipBtn.textSize = 24f
        flipBtn.gravity = Gravity.CENTER
        val flipBg = GradientDrawable()
        flipBg.shape = GradientDrawable.OVAL
        flipBg.setColor(Color.parseColor("#2EFFFFFF"))
        flipBg.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        flipBtn.background = flipBg
        pressable(flipBtn, 0.9f)
        flipBtn.setOnClickListener { flipCamera() }

        fun cell(v: View, size: Int): FrameLayout {
            val f = FrameLayout(this)
            f.addView(v, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
            return f
        }
        thumbCell = cell(thumb, dp(52))
        flipCell = cell(flipBtn, dp(52))
        controls.addView(thumbCell, LinearLayout.LayoutParams(0, dp(92), 1f))
        controls.addView(cell(shutter, dp(84)), LinearLayout.LayoutParams(0, dp(92), 1f))
        controls.addView(flipCell, LinearLayout.LayoutParams(0, dp(92), 1f))
        panel.addView(controls, LinearLayout.LayoutParams(-1, -2))

        rootView = root
        panelView = panel
        root.addView(sheetHost, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(zoomRow, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        zoomDial = ZoomDial(this, accent)
        zoomDial.visibility = View.GONE
        zoomDial.onTick = { haptic(HapticFeedbackConstants.CLOCK_TICK) }
        root.addView(zoomDial, FrameLayout.LayoutParams(-1, dp(150), Gravity.TOP))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        panel.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val nm = (b - t) + dp(4)
            val lp = sheetHost.layoutParams as FrameLayout.LayoutParams
            if (lp.bottomMargin != nm) {
                lp.bottomMargin = nm
                sheetHost.layoutParams = lp
            }
            val zp = zoomRow.layoutParams as FrameLayout.LayoutParams
            val zm = (b - t) + dp(6)
            if (zp.bottomMargin != zm) {
                zp.bottomMargin = zm
                zoomRow.layoutParams = zp
            }
            positionZoomPill(false)
        }
        sheetHost.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> positionZoomPill(true) }
        setContentView(root)

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) {
                try { previewSurface?.release() } catch (e: Exception) {}
                previewSurface = Surface(s)
                tryOpen()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean {
                try { previewSurface?.release() } catch (e: Exception) {}
                previewSurface = null
                return true
            }
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {
                if (awaitFirstFrame) {
                    awaitFirstFrame = false
                    texture.scaleX = if (front && mirrorFront) -1f else 1f
                    fadeInStage()
                }
            }
        }
    }
}

// Frosted glass: the live camera layer itself, blurred on the GPU every frame (no snapshots), then a
// dark tint, a soft sheen and a hairline edge.
private object GlassSource {
    var live: View? = null // the camera preview (TextureView)
    var anchor: View? = null // its parent, which is not mirrored: where the preview sits on screen
}

private class GlassPainter(private val d: Float, radiusDp: Float, private val tint: Int) {
    private val radius = radiusDp * d
    private val path = Path()
    private val rect = RectF()
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)
    private val anchorLoc = IntArray(2)
    private var w = 0f
    private var h = 0f
    private var node: RenderNode? = null
    private var fx: RenderEffect? = null

    fun onSize(width: Int, height: Int) {
        w = width.toFloat()
        h = height.toFloat()
        rect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        tintPaint.color = tint
        sheenPaint.shader = LinearGradient(
            0f, 0f, 0f, h, Color.argb(30, 255, 255, 255), Color.argb(4, 255, 255, 255), Shader.TileMode.CLAMP
        )
        borderPaint.style = Paint.Style.STROKE
        borderPaint.strokeWidth = d
        borderPaint.shader = LinearGradient(
            0f, 0f, w, h, Color.argb(120, 255, 255, 255), Color.argb(22, 255, 255, 255), Shader.TileMode.CLAMP
        )
    }

    fun drawBackdrop(canvas: Canvas, v: View) {
        if (w <= 0f || h <= 0f) return
        canvas.save()
        canvas.clipPath(path)
        canvas.drawColor(Color.BLACK)
        val tex = GlassSource.live
        val anchor = GlassSource.anchor
        if (Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated &&
            tex != null && anchor != null && tex.width > 0 && tex.height > 0
        ) {
            try {
                val sigma = 20f * d
                val m = sigma * 2.5f // extra context around the panel so its edges blur correctly
                val n = node ?: RenderNode("glass").also { node = it }
                if (fx == null) {
                    val blur = RenderEffect.createBlurEffect(sigma, sigma, Shader.TileMode.CLAMP)
                    val cm = ColorMatrix()
                    cm.setSaturation(1.5f)
                    fx = RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm), blur)
                }
                n.setPosition((-m).toInt(), (-m).toInt(), (w + m).toInt(), (h + m).toInt())
                n.setRenderEffect(fx)
                val rc = n.beginRecording()
                try {
                    v.getLocationInWindow(loc)
                    anchor.getLocationInWindow(anchorLoc)
                    rc.translate(m + (anchorLoc[0] - loc[0]), m + (anchorLoc[1] - loc[1]))
                    if (tex.scaleX < 0f) rc.scale(-1f, 1f, tex.width / 2f, tex.height / 2f)
                    tex.draw(rc)
                } finally {
                    n.endRecording()
                }
                canvas.drawRenderNode(n)
            } catch (e: Exception) {
            }
        }
        canvas.drawRect(rect, tintPaint)
        canvas.drawRect(rect, sheenPaint)
        canvas.restore()
    }

    fun drawBorder(canvas: Canvas) {
        if (w <= 0f || h <= 0f) return
        val inset = borderPaint.strokeWidth / 2f
        canvas.drawRoundRect(inset, inset, w - inset, h - inset, radius - inset, radius - inset, borderPaint)
    }
}

private class GlassLinear(c: Context, radiusDp: Float, tint: Int) : LinearLayout(c) {
    private val gp = GlassPainter(c.resources.displayMetrics.density, radiusDp, tint)
    var dialMode = false
    var onLongPressed: (() -> Unit)? = null
    var onDialTouch: ((MotionEvent) -> Unit)? = null
    private val detector = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onLongPress(e: MotionEvent) {
            onLongPressed?.invoke()
        }
    })

    init {
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        gp.onSize(w, h)
    }

    override fun dispatchDraw(canvas: Canvas) {
        gp.drawBackdrop(canvas, this)
        super.dispatchDraw(canvas)
        gp.drawBorder(canvas)
    }

    // once the dial is up, this panel takes over the finger from the zoom buttons
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (onLongPressed != null) detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (dialMode) return true
        return super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (dialMode) {
            onDialTouch?.invoke(ev)
            return true
        }
        return super.onTouchEvent(ev)
    }
}

// The zoom dial: tick marks on a wide arc that slide under a fixed yellow marker.
private class ZoomDial(c: Context, private val accent: Int) : View(c) {
    var value = 1f
        set(v) {
            field = v
            val idx = nearestIndex(v)
            if (idx != lastIdx) {
                if (lastIdx != -1) onTick?.invoke()
                lastIdx = idx
            }
            invalidate()
        }
    var minV = 0.6f
    var maxV = 10f
    var onTick: (() -> Unit)? = null
    private var lastIdx = -1
    private val d = c.resources.displayMetrics.density
    val pxPerLn = 240f * d
    private val majors = floatArrayOf(0.6f, 1f, 2f, 3f, 5f, 10f)
    private val ticks = floatArrayOf(
        0.6f, 0.7f, 0.8f, 0.9f, 1f, 1.2f, 1.4f, 1.6f, 1.8f, 2f, 2.5f, 3f, 3.5f, 4f, 5f, 6f, 7f, 8f, 9f, 10f
    )
    private val ringPath = Path()
    private val capsule = RectF()
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#80000000") }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        color = Color.argb(70, 255, 255, 255)
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.6f * d
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        textSize = 11f * d
    }
    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2.5f * d
        color = accent
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        textSize = 15f * d
        color = accent
    }
    private val capsulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#99000000") }

    private fun nearestIndex(v: Float): Int {
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in ticks.indices) {
            val dd = abs(ln(ticks[i]) - ln(v))
            if (dd < bd) {
                bd = dd
                best = i
            }
        }
        return best
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val r = w * 0.78f
        val cx = w / 2f
        val topY = 46f * d
        val cy = topY + r
        val band = 46f * d
        ringPath.reset()
        ringPath.addCircle(cx, cy, r, Path.Direction.CW)
        ringPath.addCircle(cx, cy, r - band, Path.Direction.CCW)
        canvas.drawPath(ringPath, bandPaint)
        canvas.drawCircle(cx, cy, r - edgePaint.strokeWidth / 2f, edgePaint)

        val lnV = ln(value)
        for (t in ticks) {
            if (t < minV - 0.001f || t > maxV + 0.001f) continue
            val ang = (ln(t) - lnV) * (pxPerLn / r)
            if (abs(ang) > 0.95f) continue
            val major = majors.any { abs(it - t) < 0.001f }
            val len = (if (major) 16f else 9f) * d
            val s = sin(ang)
            val co = cos(ang)
            val sx = cx + r * s
            if (sx < -10f || sx > w + 10f) continue
            val q = abs(ang) / 0.95f
            val a = (1f - q * q).coerceIn(0f, 1f)
            tickPaint.color = Color.argb((235 * a).toInt(), 255, 255, 255)
            canvas.drawLine(sx, cy - r * co, cx + (r - len) * s, cy - (r - len) * co, tickPaint)
            if (major) {
                textPaint.color = Color.argb((230 * a).toInt(), 255, 255, 255)
                val label = if (t < 1f) ".6" else t.roundToInt().toString()
                val lr = r - len - 13f * d
                canvas.drawText(label, cx + lr * s, cy - lr * co + 4f * d, textPaint)
            }
        }
        canvas.drawLine(cx, topY - 8f * d, cx, topY + 24f * d, markPaint)
        capsule.set(cx - 32f * d, topY - 42f * d, cx + 32f * d, topY - 14f * d)
        canvas.drawRoundRect(capsule, 14f * d, 14f * d, capsulePaint)
        canvas.drawText(String.format(Locale.US, "%.1f\u00D7", value), cx, topY - 22f * d, valuePaint)
    }
}

// iOS-style segmented control with a sliding highlight
private class SegControl(
    c: Context,
    private val accent: Int,
    private val onSelect: (Int) -> Unit
) : FrameLayout(c) {
    var onBlocked: ((Int) -> Unit)? = null
    private val d = c.resources.displayMetrics.density
    private val hi = View(c)
    private val row = LinearLayout(c)
    private val items = mutableListOf<TextView>()
    private var sel = 0
    private var dimmed: Set<Int> = emptySet()
    private val pad = (3 * d).toInt()

    init {
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#26FFFFFF"))
        bg.cornerRadius = 12 * d
        background = bg
        setPadding(pad, pad, pad, pad)
        val hb = GradientDrawable()
        hb.setColor(Color.parseColor("#4DFFFFFF"))
        hb.cornerRadius = 10 * d
        hi.background = hb
        addView(hi, FrameLayout.LayoutParams(0, 0))
        row.orientation = LinearLayout.HORIZONTAL
        addView(row, FrameLayout.LayoutParams(-1, -2))
    }

    fun setOptions(opts: List<String>, selected: Int) {
        row.removeAllViews()
        items.clear()
        opts.forEachIndexed { i, s ->
            val t = TextView(context)
            t.text = s
            t.textSize = 12.5f
            t.gravity = Gravity.CENTER
            t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            t.setPadding((4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt())
            t.setOnClickListener {
                if (i in dimmed) {
                    onBlocked?.invoke(i)
                } else {
                    select(i, true)
                    onSelect(i)
                }
            }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            items.add(t)
        }
        sel = selected.coerceIn(0, max(0, opts.size - 1))
        applyStyle()
        moveHi(false)
    }

    fun select(i: Int, animate: Boolean = true) {
        sel = i
        applyStyle()
        moveHi(animate)
    }

    fun setDimmed(set: Set<Int>) {
        dimmed = set
        applyStyle()
    }

    fun setDimFrom(n: Int) {
        setDimmed((n until items.size).toSet())
    }

    private fun applyStyle() {
        items.forEachIndexed { idx, t ->
            t.setTextColor(if (idx == sel) accent else Color.WHITE)
            t.alpha = if (idx in dimmed) 0.35f else 1f
        }
    }

    private fun moveHi(animate: Boolean) {
        if (items.isEmpty() || width == 0) return
        val w = (width - 2 * pad) / items.size
        val lp = hi.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != height - 2 * pad) {
            lp.width = w
            lp.height = height - 2 * pad
            hi.layoutParams = lp
        }
        val x = (sel * w).toFloat()
        if (animate) {
            hi.animate().translationX(x).setDuration(280)
                .setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f)).start()
        } else {
            hi.animate().cancel()
            hi.translationX = x
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        post { moveHi(false) }
    }
}

private class CamShutter(c: Context) : View(c) {
    private var video = false
    private var morph = 0f // 0 = circle, 1 = rounded square (recording)
    private var red = 0f
    private var anim: ValueAnimator? = null
    private val d = c.resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 3.5f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val eval = ArgbEvaluator()

    fun setState(v: Boolean, r: Boolean) {
        video = v
        val m0 = morph
        val r0 = red
        val mt = if (r) 1f else 0f
        val rt = if (v) 1f else 0f
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 300
        a.interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            morph = m0 + (mt - m0) * f
            red = r0 + (rt - r0) * f
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - ring.strokeWidth
        canvas.drawCircle(cx, cy, r, ring)
        fill.color = eval.evaluate(red, Color.WHITE, Color.parseColor("#FF3B30")) as Int
        val half = r * (0.82f + (0.42f - 0.82f) * morph)
        val corner = half + (half * 0.3f - half) * morph
        canvas.drawRoundRect(cx - half, cy - half, cx + half, cy + half, corner, corner, fill)
    }
}

private class CamGrid(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(110, 255, 255, 255)
        strokeWidth = 1.2f * c.resources.displayMetrics.density
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, p)
            canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, p)
        }
    }
}

// types: 0 flash, 1 timer, 2 chevron, 3 sun
private class CamIcon(c: Context, private val type: Int) : View(c) {
    var tint = Color.WHITE
        set(v) { field = v; invalidate() }
    var state = 0
        set(v) { field = v; invalidate() }
    var label = ""
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        canvas.scale(s, s)
        p.color = tint
        p.strokeWidth = 1.8f
        p.style = Paint.Style.STROKE
        tp.color = tint
        when (type) {
            0 -> {
                path.reset()
                path.moveTo(13f, 2.5f)
                path.lineTo(5.5f, 13f)
                path.lineTo(11f, 13f)
                path.lineTo(10f, 21.5f)
                path.lineTo(18.5f, 10.5f)
                path.lineTo(13f, 10.5f)
                path.close()
                p.style = if (state == 2) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
                canvas.drawPath(path, p)
                p.style = Paint.Style.STROKE
                if (state == 0) canvas.drawLine(4f, 4f, 20f, 20f, p)
                if (state == 1) {
                    tp.textSize = 9f
                    canvas.drawText("A", 19f, 21f, tp)
                }
            }
            1 -> {
                canvas.drawCircle(12f, 13.5f, 7.5f, p)
                canvas.drawLine(9.5f, 3f, 14.5f, 3f, p)
                if (label.isEmpty()) {
                    canvas.drawLine(12f, 13.5f, 12f, 9.5f, p)
                } else {
                    tp.textSize = 9f
                    canvas.drawText(label, 12f, 16.7f, tp)
                }
            }
            2 -> {
                path.reset()
                path.moveTo(5f, 9f)
                path.lineTo(12f, 16f)
                path.lineTo(19f, 9f)
                canvas.drawPath(path, p)
            }
            3 -> {
                canvas.drawCircle(12f, 12f, 4.2f, p)
                for (i in 0 until 8) {
                    canvas.drawLine(12f, 2.2f, 12f, 5f, p)
                    canvas.rotate(45f, 12f, 12f)
                }
            }
        }
        canvas.restore()
    }
}
