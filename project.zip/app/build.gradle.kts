plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.cam"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.mycam"
        minSdk = 30
        targetSdk = 34
        versionCode = 12
        versionName = "12.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
